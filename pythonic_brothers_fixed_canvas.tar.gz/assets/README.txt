Pythonic Brothers in the Clouds - 固定Canvas版

【変更内容】
- ゲーム内部の解像度は1280x720のまま
- PygbagのブラウザCanvasをCSSでも1280x720pxに固定
- Canvasをブラウザ画面の中央に配置
- ブラウザ領域に合わせた自動拡大・縮小を抑止
- ゲームの操作・対戦処理は変更していません

【実行方法】
このフォルダの1つ上の階層でコマンドプロンプトを開き、
次を実行してください。

py -m pygbag Pythonic_Brothers_fixed_canvas

起動後、http://localhost:8000 で確認してください。

※ ブラウザの表示領域が1280x720pxより小さい場合、画面の一部が見切れることがあります。
  これは「拡大縮小しない」設定による仕様です。
