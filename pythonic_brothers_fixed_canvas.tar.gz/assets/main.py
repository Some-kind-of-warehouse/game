"""
Pythonic Brothers in the Clouds  v18
実行方法:  pip install pygame  →  python Pythonic_Brothers_in_the_Clouds_ver_18.py

【操作】
            P1            P2
  移動      A / D         ← / →
  ジャンプ  W (2段OK)     ↑
  下りる    S             ↓        (浮き足場から下りる)
  攻撃      F             /
  必殺技    G             .        (ピリオド)
  ガード    H             ,        (カンマ)

  ★ 攻撃 + ジャンプキー = 上攻撃   /  攻撃 + 下キー = 下攻撃
  ★ 空中で下攻撃 = メテオ！ 当たった相手は真下に叩き落とされ、
     しばらくジャンプも復帰技も使えない
  ★ 必殺技 = キャラごとに違う(飛び道具・罠・カウンター・突進 など)
  ★ 必殺技 + ジャンプキー = 「復帰技」(空中で1回だけ。着地か崖つかまりで回復)
  ★ ガード: 地上でボタンを押している間シールドが出る。0になるとガードブレイク！
  ★ 回避: ガードを押したまま  左右キー = ロール(横に転がる)
                              下キー   = その場回避      どちらも回避中は無敵
  ★ 崖つかまり: 空中でステージの端に近づくと、自動で崖につかまる。つかまり中は
        ステージ側のキーを押し直す = 崖のぼり   ジャンプ = 崖ジャンプ
        攻撃 = 崖のぼり攻撃   下キー or 反対側 = 手を離す
        (つかまってしばらくは無敵。長くつかまっていると落ちる)
  ★ P = 一時停止   R = リスタート(勝敗が決まった後)   ESC = メニューに戻る / 終了

【メニュー】
  対戦モード → キャラ選択(RANDOMあり) → ステージ選択(RANDOMあり)。
  「I」キーでアイテムのON/OFFを切り替えられる(モード選択画面・ステージ選択画面)。

【v18 の新キャラ3体】 (これまでにない仕組みを、1体に1つずつ)
  RAVEN   : 「呪い」。必殺技の弾が当たると、約4秒後に爆発する呪いがつく(14%+強い打ち上げ・ガード不可)。
            解く方法は「呪い主に攻撃を当てる」だけ。呪い中のRAVENは速い。 復帰技=ステージを通り抜けて上がる
  NEBULA  : 「ポータル」。必殺技 1回目=入口 / 2回目=出口 / 3回目=全部消す。相手も弾も通り抜けられる
  GRANITE : 「溜め攻撃」。横/上攻撃はボタンを押し続けるとためられて、離すと出る(満タンで約2倍)。
            溜め中は動けない(ガードで中止)。 復帰技=必殺技ボタンを押している間ためて、離すと跳ぶ
  ※ v18 から、攻撃/必殺技ボタンを「押し続けている」状態も読み取る(溜め用)

【v16 の変更】
  ・COBALT / OPAL の「ATK:」表示が必殺技の説明になっていたので、通常攻撃の説明に直した
      COBALT = 軽い連打(SWIFT) / アーマー付きの重い一撃(HEAVY)   OPAL = ふつうの中距離パンチ
  ・キャラ選択画面: キャラが増えてRANDOMが3段目にはみ出していたので、列数と幅を自動で決めて2段に収めた
  ・新キャラ IVORY(スペーシングランサー): 他のキャラにない「間合い」の戦い方
      通常攻撃(横) = 槍の先端(白く光る部分)で当てるとダメージ1.7倍・ふっとび1.3倍。懐に入られると0.6倍で弱い
      必殺技=スキップショット(後ろへバク転しながら槍を撃つ。空中だとバク転は小さい)
      復帰技=スカイランス(まっすぐ上へ突き上げてから、好きな横向きへ槍で突っ込む。上→横の2段)

【v15 の変更】
  ・SCARLET の シャドウストライク: 撃つと数フレーム「消えて」、行き先に赤い枠(予告の影)が出る。
      行き先は撃った瞬間に決まるので、相手は枠から離れる / ガード / ロールでかわせる。
      消えている間はSCARLETは無防備。出現後の隙も長くした(射程 380→340、再使用待ち 120→150)
  ・JADE の連続ジャブ: 硬直ののびを短くし(18→14 など)、攻撃後の隙を長くした(18→22 など)。
      さらに、続けて当たるほど硬直ののびが減り(1発ごとに-5)、3発目以降は短い無敵で抜けられる。
      → 2〜3回つなげることはできるが、ハメ殺しはできない
  ・新キャラ OPAL(コピー屋): 必殺技「コピーキャット」は、相手の必殺技(飛び道具/突進/カウンター/つかみ/瞑想)を
      そのまま使う。相手に合わせて戦い方が変わる。体の色も相手の色とまざる。
      復帰技「エコーリープ」= 跳んだ少しあとに、もう一度ふき上がる(2回目は好きな向きに出せる)

【v14 の新キャラ6体】 (通常攻撃・必殺技・復帰技が、すべて既存キャラと違う)
  AMBER  : 大振りのバットで飛び道具を打ち返す / 必殺技=ライジングファストボール(飛ぶほど加速して痛くなる)
           復帰技=スラッガースイング(狙う角度が往復する。もう一度 上+必殺技 で好きな角度で発射)
  JADE   : ジャブ後の硬直が長く、連続で当てやすい / 必殺技=瞑想(動かず集中。最後まで続くと%が回復、攻撃を受けると中断)
           復帰技=ワールアセント(らせんを描いて、まわりを攻撃しながら上昇)
  AZURE  : 平手打ちが相手を真横に強く押す / 必殺技=ガイザー(予告の波紋のあと、足元から噴き上げて真上へ打ち上げる)
           復帰技=タイダルサーフ(少し浮いてから波に乗る。横方向にいちばん遠くまで戻れる)
  SCARLET: 相手の背後から当てるとダメージ・ふっとびアップ / 必殺技=シャドウストライク(相手の背後へ瞬間移動して斬る。地上か崖の近くだけ)
           復帰技=クナイジップ(好きな方向にクナイを投げて、壁や足場の手前まで瞬間移動)
  MOSS   : 当てた相手は足がからまって歩けなくなる(ジャンプはできる) / 必殺技=イバラのわな(踏むと約1.5秒、地上で動けない)
           復帰技=ビーンスターク(真上に豆の木の足場を4段のばす。高く戻れる)
  COBALT : 必殺技でスタンス切替。SWIFT=速くて軽い連打 / HEAVY=遅いけどアーマー付きの重い一撃
           復帰技=スタンスライズ(SWIFT=無敵ダッシュ / HEAVY=アーマー付き上昇パンチ)

【v10 の新要素】
  ・新キャラ4体
      OLIVE : 細長い射撃 + 連射(反動で少し下がる) / 復帰技=ジェットパック(下向きの炎で攻撃しながら上昇)
      LILAC : 必殺技=入れ替えオーブ(当たった相手と位置が入れ替わる！) / 復帰技=ブリンクステップ
      SAND  : 必殺技=タイムフィールド(中の相手は遅くなり、自分は速くなる) / 復帰技=巻き戻し(最後に立っていた場所へ戻る)
      RUST  : 自分の%が高いほど攻撃が強い(50%以上で赤い枠) / 必殺技=ワールウィンド / 復帰技=ホーミング突進
  ・追加キャラ4体(ver.10 後半)
      EMBER : ファイアボールが当たると相手が「燃える」(しばらく%がじわじわ増える) / 復帰技=フェニックスバースト(斜め上に炎上昇 → 最後に爆発)
      UMBER : 重くて遅いゴーレム。強攻撃はアーマーつき / 必殺技=前後に出る衝撃波(ジャンプでよけられる) / 復帰技=ストーンピラー(アーマー+回転攻撃で上昇 → 足場が残る。足場に乗っても復帰技は回復しない)
      SILVER: 最速キャラ。3連ジャブ / 必殺技=相手をすり抜ける無敵ダッシュ(空中では着地するまで1回だけ) / 復帰技=スカイステップ(空中で3回、8方向に短くダッシュ)
      CORAL : 必殺技=トーテム設置(自動で弾を撃つ砲台。殴ると壊せる) / 復帰技=無敵の泡で浮かぶ
      PLUM  : 必殺技=ジョーカーダート(当たると、約4割で左右の操作が逆になる「混乱」。約1.8秒) / 復帰技=ジャックホップ(3回はねて上昇)
      ONYX  : 必殺技=コマンドグラブ(ガードを貫通する投げ) / 復帰技=グラップルリール(ロープで崖か相手の所へ飛ぶ。届かないと不発)
      TOPAZ : 必殺技=コイルボール(床や壁ではずむ弾) / 復帰技=スプリングキック(空中にばねを出して跳ね上がり、上昇中は蹴り上げの攻撃判定つき)
  ・新ステージ5つ
      TRIPLE ISLES(すき間のある3つの島) / THE CAGE(左右に高い壁) / MOON BASE(低重力)
      THUNDER PEAK(予告つきの落雷) / CONVEYOR(ベルトコンベアの床。ときどき向きが逆になる)
  ・新アイテム4つ
      B=バリア(受けるダメージ半分・飛ばされにくい・シールド全回復)  W=ウィング(ふわふわ + ジャンプ+2回)
      !=ボム(取ると爆発して自分が飛ぶ…罠！)  F=フロスト(相手を冷やして遅くする)
  ・キャラ選択は14列、ステージ選択は2段になった(ステージ選択でも W/S・↑/↓ の上下移動OK)

【v9 の新要素】
  ・キャラ選択画面で W / S (P2は ↑ / ↓) を使って、上下の段にも移動できる
  ・新キャラ GOLD : 攻撃が20%の確率で「大当たり」(ダメージ2倍・ふっとび1.4倍)
                    復帰技はギャンブル！ 高く飛べるか、ちょっとしか飛べないか運しだい(ジャックポットあり)
  ・新キャラ PEACH: 風船で浮かんでゆっくり上昇 → 最後にパンッと破裂して攻撃

【v8 の復帰技(上+必殺技)】 すべてのキャラで動きがちがう！
  ・8方向ダッシュ2連(NAVY) ・溜めて狙い撃ち突進(STEEL) ・助走が高さになる跳び(BROWN)
  ・氷の階段を作る(ICE) ・プロペラで浮かぶ(LIME) ・遅れて崖へワープ(INDIGO)
  ・ムチで弧を描いて飛び移る(TEAL)   ※ 方向キーを押しながら出すと、その向きに動く

【v7 のキャラ個性】
  MAGENTA : 地雷が2個出ているとき必殺技をもう一度 = 全部の地雷を起爆
            (v14) 相手の弾・爆発・近接攻撃が地雷に触れても爆発する
  MINT    : 風(サイクロン)が相手を押し続ける
  CRIMSON : 噛みつき・コウモリが当たると回復(そのかわり軽い)
  STEEL   : ガードが割れにくく回復も速い。縦に長い斬り
  BROWN   : 走っているほど攻撃が強い(勢いボーナス)
  ICE     : 攻撃を当てると相手が「冷え」て遅くなる。冷えた相手は長く凍る
  LIME(新): ブーメラン(行きと帰りで2回当たる)
  INDIGO(新): ブラックホールと引き寄せ攻撃
  NAVY(新): 離れた場所に落ちる雷
  TEAL(新): 超ロングリーチのムチと、引き寄せるロープ

【アイテム】 (ONのとき、ときどき空から降ってくる。触ると取れる)
  H=回復(%を減らす)  P=パワー(攻撃が強くなる)  S=スピード  *=スター(しばらく無敵)
  B=バリア  W=ウィング  !=ボム(罠)  F=フロスト(相手を遅くする)   ← v10 の新アイテム
"""
import asyncio
import copy
import math
import random
import sys

import pygame

# ---------- 基本設定（いじると遊び心地が変わる） ----------
W, H = 1280, 720
FPS = 60
MAX_FALL = 15        # 落下の最高速度
METEOR_FALL = 29     # メテオを受けているときの落下の最高速度
CHUTE_FALL = 3.0     # パラシュート中の落下の最高速度
FRICTION = 0.82      # 地面での減速
AIR_DRAG = 0.97      # 空中での減速
STOCKS = 3           # 残機
DODGE_FRAMES = 18    # 回避の長さ（この間は無敵）
DODGE_SPEED = 7.0    # ロールの速さ
DODGE_CD = 40        # 回避の連発を防ぐ待ち時間
LEDGE_HANG = 240     # 崖につかまっていられる最大時間
MINE_SHOT_DETONATE = True    # 相手の飛び道具・爆発が触れた地雷を爆発させる
MINE_MELEE_DETONATE = True   # 相手の近接攻撃が触れた地雷も爆発させる(Falseで飛び道具だけ)

P1_KEYS = dict(left=pygame.K_a, right=pygame.K_d, jump=pygame.K_w, down=pygame.K_s,
               attack=pygame.K_f, special=pygame.K_g, guard=pygame.K_h)
P2_KEYS = dict(left=pygame.K_LEFT, right=pygame.K_RIGHT, jump=pygame.K_UP, down=pygame.K_DOWN,
               attack=pygame.K_SLASH, special=pygame.K_PERIOD, guard=pygame.K_COMMA)
PAUSE_KEY = pygame.K_p
ITEM_KEY = pygame.K_i
JADE_DECAY = 5          # JADE: 続けて当たるごとに、硬直ののびが減る量(フレーム)
SELECT_ROWS = 2       # キャラ選択画面の段数(キャラが増えても、この段数に収まるよう列数を自動で決める)
STATIC_KINDS = ("zone", "turret", "spring", "geyser", "snare", "portal")   # 置いておく系の技(動かない)
HEX_DEFAULT = dict(frames=240, dmg=14, kb=1.5)   # 呪い(RAVEN)の標準設定(RAVEN以外が呪いの弾を撃った時用)
PORTAL_CD = 40       # ポータルを通ったあと、もう一度通れるようになるまで(フレーム)

# ======================================================================
#  ステージ（ここに足せばステージが増やせる）
#  main    = 下からも横からも通れない大きな床（崖つかまりもできる）
#  solids  = ほかの「通れない四角」（塔・壁・天井など。崖つかまりもできる）
#  thin    = 下からすり抜けられる足場
#  movers  = 動く足場。i=thinの何番目か / ax="x"か"y" / amp=動く幅 / spd=速さ / ph=ずれ
#  blast   = 死亡ライン（この四角の外に出たらアウト）
# ======================================================================
R = pygame.Rect
STAGES = [
    dict(name="BATTLE FIELD", desc="Standard stage", note="3 platforms",
         main=R(240, 480, 800, 30),
         thin=[R(320, 370, 210, 12), R(750, 370, 210, 12), R(535, 260, 210, 12)],
         blast=R(-350, -450, 1980, 1550)),
    dict(name="FINAL FIELD", desc="Flat. Pure duel", note="No platforms",
         main=R(240, 480, 800, 30), thin=[],
         blast=R(-350, -450, 1980, 1550)),
    dict(name="TINY ISLAND", desc="Small! Easy to KO", note="1 platform",
         main=R(440, 480, 400, 30),
         thin=[R(540, 340, 200, 12)],
         blast=R(-40, -300, 1360, 1150)),
    dict(name="GRAND PLAINS", desc="Huge! Run & chase", note="5 platforms",
         main=R(60, 480, 1160, 30),
         thin=[R(150, 370, 200, 12), R(540, 370, 200, 12), R(930, 370, 200, 12),
               R(340, 260, 200, 12), R(740, 260, 200, 12)],
         blast=R(-500, -450, 2280, 1600)),
    dict(name="SKY TOWER", desc="Tall. Many floors", note="6 platforms",
         main=R(400, 540, 480, 30),
         thin=[R(330, 430, 180, 12), R(770, 430, 180, 12), R(550, 320, 180, 12),
               R(330, 210, 180, 12), R(770, 210, 180, 12), R(550, 100, 180, 12)],
         blast=R(-350, -600, 1980, 1750)),
    dict(name="WINDMILL", desc="Platforms slide around", note="3 moving floors",
         main=R(290, 500, 700, 30),
         thin=[R(330, 390, 170, 12), R(780, 390, 170, 12), R(555, 270, 170, 12)],
         movers=[dict(i=0, ax="x", amp=150, spd=0.018, ph=0.0),
                 dict(i=1, ax="x", amp=150, spd=0.018, ph=3.14159),
                 dict(i=2, ax="y", amp=50, spd=0.03, ph=0.0)],
         blast=R(-350, -450, 1980, 1550)),
    dict(name="ELEVATOR", desc="Lifts go up and down", note="4 moving floors",
         main=R(440, 520, 400, 30),
         thin=[R(250, 420, 170, 12), R(860, 420, 170, 12),
               R(555, 300, 170, 12), R(555, 160, 170, 12)],
         movers=[dict(i=0, ax="y", amp=110, spd=0.025, ph=0.0),
                 dict(i=1, ax="y", amp=110, spd=0.025, ph=3.14159),
                 dict(i=2, ax="x", amp=110, spd=0.02, ph=0.0),
                 dict(i=3, ax="x", amp=110, spd=0.02, ph=3.14159)],
         blast=R(-350, -600, 1980, 1750)),
    dict(name="FORTRESS", desc="Towers, walls, ceiling", note="Solid blocks",
         main=R(190, 480, 900, 30),
         solids=[R(330, 400, 90, 80), R(860, 400, 90, 80), R(560, 190, 160, 40)],
         thin=[R(470, 330, 340, 12)],
         blast=R(-300, -450, 1880, 1550)),
    # ---------------- ここから v10 の新ステージ ----------------
    # grav=重力の倍率  hazard=落雷  belt=床が動く(speed=速さ period=向きが変わる間隔)  bg=背景色
    dict(name="TRIPLE ISLES", desc="Jump across gaps", note="Floating islands",
         main=R(500, 500, 280, 30),
         solids=[R(150, 440, 230, 40), R(900, 440, 230, 40)],
         thin=[R(540, 350, 200, 12)],
         blast=R(-350, -500, 1980, 1650)),
    dict(name="THE CAGE", desc="Walls on both sides", note="Tall walls",
         main=R(240, 500, 800, 30),
         solids=[R(190, 310, 50, 220), R(1040, 310, 50, 220)],
         thin=[R(300, 390, 180, 12), R(800, 390, 180, 12), R(550, 280, 180, 12)],
         blast=R(-300, -450, 1880, 1550)),
    dict(name="MOON BASE", desc="Low gravity", note="Gravity x0.55",
         main=R(350, 500, 580, 30),
         thin=[R(330, 380, 170, 12), R(780, 380, 170, 12), R(555, 260, 170, 12)],
         grav=0.55, bg=(16, 18, 38),
         blast=R(-350, -750, 1980, 1900)),
    dict(name="THUNDER PEAK", desc="Dodge the storm", note="Lightning strikes!",
         main=R(260, 490, 760, 30),
         thin=[R(330, 375, 180, 12), R(770, 375, 180, 12), R(550, 265, 180, 12)],
         hazard=dict(kind="thunder", every=(150, 270), warn=55), bg=(44, 40, 62),
         blast=R(-350, -450, 1980, 1550)),
    dict(name="CONVEYOR", desc="The floor moves", note="Belt reverses!",
         main=R(260, 500, 760, 30),
         thin=[R(300, 390, 170, 12), R(810, 390, 170, 12), R(555, 285, 170, 12)],
         belt=dict(speed=1.6, period=360), bg=(42, 36, 42),
         blast=R(-350, -450, 1980, 1550)),
]

MAIN = SOLID = THIN = BLAST = None
STAGE_GRAV = 1.0     # ステージの重力の倍率
STAGE_BG = (30, 34, 50)
BELT = None          # ベルトコンベア
HAZARD = None        # 落雷
BOLTS = []           # 落ちる予定/落ちている雷
MOVERS = []          # 動く足場
NOREFRESH = []       # 乗っても復帰技が回復しない足場(ストーンピラー)
TEMPS = []           # 一時的に出現する足場 [rect, 残り時間]
LEDGE_OWNER = {}     # 崖 → つかまっている人


def set_stage(st):
    """ステージを切り替える（床の位置などをまとめて入れ替える）"""
    global MAIN, SOLID, THIN, BLAST, MOVERS, TEMPS, LEDGE_OWNER
    global STAGE_GRAV, STAGE_BG, BELT, HAZARD
    MAIN = st["main"]
    SOLID = [MAIN] + list(st.get("solids", []))
    THIN = [r.copy() for r in st["thin"]]            # 動く足場で書き換えるのでコピー
    BLAST = st["blast"]
    MOVERS = [dict(rect=THIN[m["i"]], bx=THIN[m["i"]].x, by=THIN[m["i"]].y,
                   ax=m["ax"], amp=m["amp"], spd=m["spd"], ph=m["ph"])
              for m in st.get("movers", [])]
    TEMPS = []
    LEDGE_OWNER = {}
    STAGE_GRAV = st.get("grav", 1.0)
    STAGE_BG = st.get("bg", (30, 34, 50))
    BELT = st.get("belt")
    HAZARD = st.get("hazard")
    BOLTS.clear()
    NOREFRESH.clear()


set_stage(STAGES[0])


# ======================================================================
#  キャラクターのデータ（ここを書き換える/足すだけでキャラが増やせる）
# ======================================================================
def mv(reach, dmg, kb, active, cd, gap=0, delay=0, hits=1, every=3,
       tall=0, lunge=0.0, armor=False, chill=0, pull=False, burn=0,
       reflect=False, stun=0, flat=False, root=0):
    """通常攻撃1つ分のデータ
    reach=攻撃判定の長さ  dmg=ダメージ  kb=吹っ飛ばし力  active=判定が出ている時間  cd=攻撃後の隙
    gap=体から判定までの距離(離れた所に出る)  delay=発生までの溜め時間
    hits/every=多段ヒットの回数と間隔(最後の1発だけ吹っ飛ばす)
    tall=判定の高さ(0なら標準)  lunge=攻撃で前に踏み込む勢い  armor=攻撃中は怯まない
    chill=当てた相手を「冷え」させる時間(動きが遅くなる)  pull=横攻撃で相手を自分の方へ引き寄せる
    burn=当てた相手を「燃焼」させる時間(40フレームごとに%が1増える)
    --- v14 ---
    reflect=この攻撃の判定が、相手の飛び道具を打ち返す  stun=当てた相手の硬直を、この分だけ長くする
    flat=横攻撃で、相手を真横に強く押す(上には飛ばない)  root=当てた相手の足をからめて、地上で歩けなくする時間"""
    return dict(reach=reach, dmg=dmg, kb=kb, active=active, cd=cd, gap=gap, delay=delay,
                hits=hits, every=every, tall=tall, lunge=lunge, armor=armor,
                chill=chill, pull=pull, burn=burn,
                reflect=reflect, stun=stun, flat=flat, root=root)


def proj(name, speed, w, h, dmg, kb, life, cd, color, vy=0.0, grav=0.0, spread=None,
         kind="normal", fuse=0, blast=0, pierce=False, wave=0.0, freeze=False,
         persist=False, arm=0, boomerang=0, pull=False, rehit=0, chill=0, drop=None,
         swap=False, ahead=0, recoil=0.0, burn=0, low=False, both=False, confuse=0, confuse_chance=1.0,
         accel=0.0, ramp=0, hop=0.0, hex=False):
    """飛び道具の必殺技。spread=(...)で縦方向の角度違いを複数同時に撃てる。
    kind='bomb'  = 地面に落ちて、時間がたつか敵が触れると爆発する
    pierce=貫通  wave=波打つ  freeze=当たると(35%、冷え中は55%で)凍って動けない。空中では一瞬だけ
    persist=置きっぱなしの罠(最大2個まで。2個出ている時にもう一度押すと起爆)
    arm=設置してから有効になるまでの時間
    boomerang=この時間で行って戻ってくる  pull=当たった相手を撃った人の方へ引っ張る
    rehit=貫通弾が同じ相手に何フレームおきに当たり直すか  chill=当てた相手を冷えさせる時間
    drop=(前方への距離, 高さ) 指定すると、その場所の上空から真下に落ちる
    --- v10 ---
    swap=当たった相手と位置が入れ替わる  ahead=kind='zone'を前方どれだけ先に置くか
    recoil=撃った時に後ろへ下がる勢い  kind='zone'=置いておく「場」(中の相手は遅くなる)
    burn=当てた相手を燃焼させる時間  low=足元の高さで地面を這う  both=前と後ろの両方に出る
    confuse=当てた相手の左右の操作を逆にする時間  confuse_chance=混乱する確率
    kind='spring'=踏むと高く跳ね上がるばね  kind='ball'=床や壁ではずむ弾
    kind='turret'=置いておく砲台(自動で弾を撃つ。相手の攻撃で壊れる)
    --- v14 ---
    accel=毎フレーム加速する量  ramp=飛んだ時間がこの間隔たつごとに、ダメージが+1(最大+8)
    kind='geyser'=置いておく間欠泉(最初は予告だけ。そのあと噴き上げて、当たった相手を真上へ打ち上げる)
    kind='snare'=置いておくわな(踏んだ相手は、しばらく地上で歩けなくなる)
    --- v16 ---
    hop=撃った瞬間に上へ跳ぶ勢い(recoilと合わせて、後ろへバク転しながら撃つ。空中では小さくなる)
    --- v18 ---
    hex=当たった相手に「呪い」をかける(約4秒後に爆発。呪い主に攻撃を当てれば解ける)"""
    return dict(name=name, mode="shoot", speed=speed, w=w, h=h, dmg=dmg, kb=kb, life=life,
                cd=cd, color=color, vy=vy, grav=grav, spread=spread or (vy,), kind=kind,
                fuse=fuse, blast=blast, pierce=pierce, wave=wave, freeze=freeze,
                persist=persist, arm=arm, boomerang=boomerang, pull=pull, rehit=rehit,
                chill=chill, drop=drop, swap=swap, ahead=ahead, recoil=recoil,
                burn=burn, low=low, both=both, confuse=confuse, confuse_chance=confuse_chance,
                accel=accel, ramp=ramp, hop=hop, hex=hex)


def spec(name, mode, cd, **kw):
    """飛び道具ではない必殺技。mode='counter'(カウンター構え) / 'rush'(突進)"""
    return dict(name=name, mode=mode, cd=cd, **kw)


def upsp(name, kind, **params):
    """復帰技（上必殺技）
    rise=上昇パンチ  spin=回転上昇  dash=ダッシュ  boost=ふわっと上昇  warp=ワープ
    charge=斜め突進  chute=パラシュート  rocket=溜めてから高く上昇  hook=崖にロープ
    flight=自由に飛べる  wings=ジャンプ回数を増やす  plat=足場を作る
    --- v8 ---
    quick=8方向ダッシュ2連(途中で向きを変えられる)  launch=溜めながら狙って突進(アーマー)
    vault=走る勢いが高さになる  stairs=氷の階段を3段作る  copter=プロペラで上昇しながら攻撃
    rift=少し溜めてから近い崖へワープ(溜め中は無防備)  swing=ムチで弧を描いて崖へ
    --- v9 ---
    gamble=運しだいで上昇の高さが変わる(たまにジャックポット)
    balloon=風船でゆっくり浮かび、最後に破裂して周りを攻撃
    --- v10 ---
    jet=下向きの炎で攻撃しながら上昇  blink=斜め上/真上へ瞬間移動
    rewind=最後に立っていた場所へ戻る  homing=ステージの端(か相手)へ自動で狙って突進
    bubble=無敵の泡でゆっくり浮かぶ(攻撃はできない。左右には動ける)
    phoenix=炎をまとって斜め上に上昇し、最後に爆発  pillar=石柱で上昇して、足場を残す
    airstep=空中で何度か短く8方向ダッシュ  pogo=何度かはねて上昇
    reel=ロープで崖(か相手)の所まで飛ぶ  springhop=空中にばねを出して、はねて戻る
    --- v14 ---
    cannon=角度が往復する間にもう一度押して発射(押さなくても自動で発射。狙う間はバットで飛び道具を打ち返す)
    spiral=らせんを描いて上昇し、まわりを攻撃  surf=少し浮いてから波に乗って横へ長く進む
    kunai=好きな方向にクナイを投げて、壁や足場の手前まで瞬間移動  stalk=真上に豆の木の足場を何段かのばす
    twin=スタンスで中身が変わる(SWIFT=無敵ダッシュ / HEAVY=アーマー付き上昇)
    --- v15 ---
    echo=跳んだ少しあとに、もう一度ふき上がる(2回目は方向キーで向きを選べる)
    --- v16 ---
    valk=まっすぐ上へ突き上げてから、好きな横向きへ槍で突っ込む(上→横の2段)
    --- v18 ---
    phase=ステージを通り抜けて上がる(真下からでも戻れる)  gate=近くの崖へ出入口のポータルを開いて移動(ポータルが残る)
    chargejump=必殺技ボタンを押している間ためて、離すと跳ぶ(長く押すほど高い)"""
    return dict(name=name, kind=kind, **params)


CHARS = [
    dict(name="RED", desc="Balanced", trait="Balanced punches", color=(225, 70, 70), w=40, h=60,
         accel=0.9, run=6.0, jump=12.0, jumps=2, gravity=0.60, weight=1.00,
         side=mv(55, 8, 1.0, 10, 28, lunge=1.5), up=mv(55, 7, 1.0, 10, 30),
         down=mv(50, 7, 1.0, 10, 32),
         neutral=proj("Fireball", 8, 28, 28, 6, 1.0, 80, 45, (255, 140, 40)),
         up_sp=upsp("Rising Punch", "rise", vy=16, frames=16, dmg=11, kb=1.1)),
    dict(name="BLUE", desc="Fast & Light", trait="2-hit quick jabs", color=(70, 120, 235),
         w=34, h=54, accel=1.2, run=8.0, jump=12.5, jumps=2, gravity=0.60, weight=0.85,
         side=mv(46, 3, 0.8, 8, 14, hits=2, every=3, lunge=3.0),
         up=mv(46, 4, 0.85, 8, 16, hits=2, every=3),
         down=mv(44, 6, 0.9, 8, 22),
         neutral=proj("Wave Shot", 14, 34, 14, 4, 0.7, 50, 25, (120, 210, 255)),
         up_sp=upsp("Phantom Dash", "dash", vx=17, vy=3, vyup=13, iframes=14)),
    dict(name="GREEN", desc="Slow Tank", trait="Armored slow smash", color=(70, 185, 95),
         w=52, h=72, accel=0.60, run=4.2, jump=10.5, jumps=2, gravity=0.62, weight=1.45,
         side=mv(60, 13, 1.4, 12, 44, delay=5, armor=True),
         up=mv(58, 12, 1.3, 12, 44, delay=5, armor=True),
         down=mv(58, 13, 1.5, 12, 48),
         neutral=proj("Boulder", 5, 42, 42, 14, 1.5, 150, 80, (150, 120, 85), vy=-7, grav=0.3),
         up_sp=upsp("Armor Spin", "spin", vy=11.5, frames=30, dmg=12, kb=1.2,
                    hits=1, every=3, armor=True)),
    dict(name="YELLOW", desc="Floaty Jumper", trait="Long-lasting swing", color=(235, 200, 60),
         w=38, h=58, accel=0.85, run=5.5, jump=13.5, jumps=3, gravity=0.48, weight=0.95,
         side=mv(52, 6, 0.95, 16, 26), up=mv(58, 7, 1.0, 12, 26),
         down=mv(52, 7, 1.0, 10, 28),
         neutral=proj("Triple Star", 8, 20, 20, 3, 0.6, 55, 50, (255, 240, 120),
                      spread=(-2.5, 0.0, 2.5)),
         up_sp=upsp("Glide Boost", "boost", vy=14, vx=5, glide=30)),
    dict(name="PURPLE", desc="Long-Range Mage", trait="Magic hits far away",
         color=(165, 95, 215), w=36, h=58, accel=0.8, run=5.2, jump=12.0, jumps=2,
         gravity=0.55, weight=0.80,
         side=mv(60, 6, 0.9, 12, 32, gap=55, delay=6),
         up=mv(60, 6, 0.9, 12, 34, gap=45, delay=6),
         down=mv(56, 7, 1.15, 12, 38, gap=35, delay=6),
         neutral=proj("Dark Orb", 4.5, 34, 34, 9, 1.2, 140, 70, (190, 110, 240)),
         up_sp=upsp("Warp", "warp", dist=240)),
    dict(name="ORANGE", desc="Quick Brawler", trait="5-hit flurry", color=(240, 140, 50),
         w=42, h=62, accel=1.0, run=6.5, jump=11.5, jumps=2, gravity=0.62, weight=1.10,
         side=mv(42, 2, 0.9, 12, 14, hits=5, every=2, lunge=2.0),
         up=mv(46, 3, 1.1, 10, 20, hits=3, every=3),
         down=mv(42, 9, 1.3, 8, 30),
         neutral=proj("Shock Wave", 7, 40, 20, 5, 0.9, 22, 30, (255, 170, 80)),
         up_sp=upsp("Fire Charge", "charge", vx=11, vy=8, frames=18, dmg=12, kb=1.3, reach=55)),
    dict(name="PINK", desc="Airy Fairy", trait="Light fast taps", color=(240, 130, 190),
         w=32, h=50, accel=1.0, run=6.0, jump=13.0, jumps=4, gravity=0.40, weight=0.70,
         side=mv(44, 5, 0.7, 8, 16), up=mv(46, 5, 0.75, 8, 18), down=mv(44, 6, 0.9, 8, 24),
         neutral=proj("Bubble", 4, 30, 30, 4, 0.8, 120, 40, (255, 190, 225), vy=-1.0, grav=-0.02),
         up_sp=upsp("Parachute", "chute", vy=6, glide=100)),
    dict(name="CYAN", desc="Swordsman", trait="Long lunging sword", color=(70, 205, 215),
         w=40, h=64, accel=0.8, run=5.6, jump=12.0, jumps=2, gravity=0.60, weight=1.05,
         side=mv(84, 9, 1.05, 14, 34, lunge=3.0), up=mv(76, 9, 1.1, 12, 36),
         down=mv(66, 8, 1.2, 12, 38),
         neutral=proj("Slash Wave", 11, 46, 22, 6, 0.9, 60, 55, (150, 240, 250)),
         up_sp=upsp("Tornado Slash", "spin", vy=12, frames=30, dmg=3, kb=1.1,
                    hits=4, every=7, armor=False)),
    dict(name="WHITE", desc="Bomber", trait="Delayed big blast", color=(220, 220, 235),
         w=44, h=66, accel=0.80, run=5.4, jump=12.0, jumps=2, gravity=0.60, weight=1.10,
         side=mv(76, 13, 1.45, 10, 46, gap=8, delay=10, tall=100),
         up=mv(70, 11, 1.3, 10, 44, gap=6, delay=8),
         down=mv(60, 11, 1.4, 12, 44, delay=6),
         neutral=proj("Time Bomb", 4, 36, 36, 12, 1.5, 200, 80, (90, 90, 100), vy=-6, grav=0.35,
                      kind="bomb", fuse=55, blast=150),
         up_sp=upsp("Rocket Blast", "rocket", charge=12, vy=20, frames=14, dmg=13, kb=1.4)),
    dict(name="DARK", desc="Spike Assassin", trait="Lunging stabs + meteor",
         color=(110, 110, 150), w=34, h=56, accel=1.15, run=7.5, jump=12.5, jumps=2,
         gravity=0.58, weight=0.90,
         side=mv(44, 6, 0.9, 7, 12, lunge=7.0), up=mv(44, 6, 0.95, 8, 18),
         down=mv(62, 9, 1.8, 10, 40),
         neutral=proj("Dagger", 12, 30, 10, 5, 0.8, 55, 22, (200, 200, 230)),
         up_sp=upsp("Shadow Hook", "hook", range=430, speed=24)),
    # ---------------- ここから v6 の新キャラ ----------------
    dict(name="MAGENTA", desc="Trapper", trait="Pokes; 2 mines: SP=BOOM", color=(210, 50, 160),
         w=38, h=60, accel=0.85, run=5.6, jump=12.0, jumps=2, gravity=0.60, weight=1.00,
         side=mv(44, 5, 0.8, 8, 18), up=mv(50, 6, 1.1, 10, 26), down=mv(48, 7, 1.0, 10, 30),
         neutral=proj("Mine / Detonate", 1.5, 26, 26, 9, 1.2, 700, 70, (210, 50, 160), vy=-3, grav=0.4,
                      kind="bomb", fuse=600, blast=110, persist=True, arm=25),
         up_sp=upsp("Summon Floor", "plat", life=150, cd=240)),
    dict(name="MINT", desc="Wind Master", trait="Gusts; wind keeps pushing", color=(110, 230, 180),
         w=34, h=56, accel=1.0, run=6.4, jump=12.5, jumps=2, gravity=0.50, weight=0.80,
         side=mv(70, 3, 1.7, 10, 26, tall=90), up=mv(62, 3, 1.5, 10, 28),
         down=mv(56, 6, 1.2, 12, 34),
         neutral=proj("Cyclone", 3.5, 60, 84, 1, 0.5, 90, 70, (140, 240, 200), pierce=True, rehit=10),
         up_sp=upsp("Tailwind", "wings", vy=9, vx=6, jumps=2)),
    dict(name="CRIMSON", desc="Vampire", trait="Bites heal; fragile", color=(150, 25, 55),
         w=38, h=60, accel=1.0, run=6.5, jump=12.5, jumps=2, gravity=0.58, weight=0.85,
         leech=0.5,
         side=mv(40, 5, 0.8, 8, 22, hits=2, every=3, lunge=5.0), up=mv(50, 6, 1.0, 10, 26),
         down=mv(50, 8, 1.3, 10, 34),
         neutral=proj("Bat Swarm", 6, 30, 22, 4, 0.8, 90, 40, (170, 40, 70),
                      spread=(-1.5, 1.5), wave=14),
         up_sp=upsp("Bat Flight", "flight", frames=45, speed=5.5)),
    dict(name="STEEL", desc="Counter Master", trait="Tall swing, tough guard",
         color=(150, 170, 190), w=40, h=62, accel=0.85, run=5.4, jump=11.5, jumps=2,
         gravity=0.60, weight=1.15,
         guard_taken=0.5, guard_drain=0.12, shield_regen=0.7,
         side=mv(50, 9, 1.1, 10, 36, delay=6, tall=130), up=mv(56, 8, 1.05, 10, 34),
         down=mv(52, 8, 1.2, 10, 36),
         neutral=spec("Counter", "counter", 80, frames=26),
         up_sp=upsp("Iron Launch", "launch", charge=20, speed=17, frames=14, dmg=10, kb=1.2)),
    dict(name="BROWN", desc="Rushdown Ram", trait="Faster = harder hits", color=(165, 115, 70),
         w=46, h=62, accel=0.9, run=7.0, jump=11.5, jumps=2, gravity=0.62, weight=1.20, momentum=4,
         side=mv(48, 7, 1.1, 10, 30, lunge=9.0), up=mv(50, 9, 1.2, 12, 34),
         down=mv(50, 10, 1.4, 10, 36),
         neutral=spec("Ram Rush", "rush", 70, frames=24, speed=10, dmg=11, kb=1.3, reach=56),
         up_sp=upsp("Vault Dash", "vault", vy=9, k=1.2, frames=14, dmg=8, kb=1.1, reach=50)),
    dict(name="ICE", desc="Freezer", trait="Chills foes; shards may freeze", color=(170, 225, 255),
         w=36, h=58, accel=0.95, run=5.8, jump=12.5, jumps=2, gravity=0.56, weight=0.90,
         side=mv(50, 5, 0.8, 8, 20, chill=150), up=mv(52, 5, 0.85, 8, 22, chill=150),
         down=mv(48, 6, 1.0, 10, 28, chill=150),
         neutral=proj("Ice Shard", 9, 30, 18, 4, 0.2, 70, 55, (170, 225, 255), freeze=True, chill=180),
         up_sp=upsp("Ice Stairs", "stairs", vy=7, life=170, cd=240)),
    # ---------------- ここから v7 の新キャラ ----------------
    dict(name="LIME", desc="Boomerang Kid", trait="Reach jabs", color=(170, 235, 60),
         w=36, h=58, accel=0.95, run=6.0, jump=12.5, jumps=2, gravity=0.58, weight=0.95,
         side=mv(58, 6, 1.0, 10, 26, gap=8), up=mv(56, 6, 1.0, 10, 28),
         down=mv(52, 7, 1.1, 10, 32),
         neutral=proj("Boomerang", 14, 36, 24, 5, 0.9, 72, 60, (190, 245, 90),
                      pierce=True, boomerang=70),
         up_sp=upsp("Leaf Copter", "copter", frames=60, rise=3.4, glide=25, dmg=2, kb=0.6,
                    hits=6, every=9)),
    dict(name="INDIGO", desc="Gravity Mage", trait="Pull-in tug attack", color=(90, 70, 190),
         w=38, h=62, accel=0.8, run=5.4, jump=12.0, jumps=2, gravity=0.55, weight=1.00,
         side=mv(56, 6, 1.0, 10, 30, pull=True), up=mv(58, 7, 1.2, 10, 32),
         down=mv(54, 8, 1.4, 10, 36),
         neutral=proj("Black Hole", 3, 60, 60, 1, 0.9, 110, 85, (120, 90, 220),
                      pierce=True, rehit=12, pull=True),
         up_sp=upsp("Rift Step", "rift", range=650, delay=26)),
    dict(name="NAVY", desc="Storm Caller", trait="Double zap jabs", color=(50, 70, 150),
         w=40, h=62, accel=0.85, run=5.6, jump=12.0, jumps=2, gravity=0.60, weight=1.00,
         side=mv(46, 3, 0.7, 8, 16, hits=2, every=3), up=mv(48, 5, 1.0, 10, 24),
         down=mv(48, 7, 1.2, 10, 30),
         neutral=proj("Thunder Bolt", 16, 28, 130, 8, 1.1, 40, 75, (255, 235, 90),
                      drop=(170, 340)),
         up_sp=upsp("Volt Dash", "quick", speed=14, seg=8, wait=5, dmg=6, kb=0.9)),
    dict(name="TEAL", desc="Whip Dancer", trait="Very long whip", color=(30, 150, 140),
         w=38, h=60, accel=0.9, run=5.8, jump=12.0, jumps=2, gravity=0.60, weight=0.95,
         side=mv(104, 6, 0.9, 10, 36, gap=8, delay=5), up=mv(86, 6, 1.0, 10, 34, gap=4, delay=4),
         down=mv(66, 7, 1.1, 12, 36),
         neutral=proj("Lasso", 12, 40, 16, 3, 2.2, 28, 55, (60, 200, 190), pull=True),
         up_sp=upsp("Whip Swing", "swing", range=420, speed=20, amp=90)),
    # ---------------- ここから v9 の新キャラ ----------------
    dict(name="GOLD", desc="Lucky Gambler", trait="20% JACKPOT: x3 dmg, huge KB, heal", color=(215, 170, 30),
         w=40, h=60, accel=0.9, run=6.0, jump=12.0, jumps=2, gravity=0.60, weight=1.05,
         crit=0.2,
         side=mv(50, 6, 1.0, 10, 26), up=mv(52, 6, 1.0, 10, 28), down=mv(48, 7, 1.1, 10, 32),
         neutral=proj("Coin Toss", 9, 24, 24, 5, 0.9, 60, 35, (255, 215, 70), vy=-4, grav=0.25),
         up_sp=upsp("Lucky Leap", "gamble", big=20, mid=15, small=9, side=9, dmg=12, kb=1.2)),
    dict(name="PEACH", desc="Balloon Clown", trait="Plain pops; floaty body", color=(255, 175, 130),
         w=36, h=58, accel=0.9, run=5.8, jump=12.0, jumps=2, gravity=0.50, weight=0.85,
         side=mv(48, 6, 1.0, 10, 24), up=mv(52, 6, 1.1, 10, 26), down=mv(48, 7, 1.1, 10, 30),
         neutral=proj("Confetti", 9, 14, 14, 2, 0.45, 16, 40, (255, 120, 170),
                      spread=(-2.5, -1.0, 1.0, 2.5)),
         up_sp=upsp("Balloon Pop", "balloon", frames=70, rise=3.2, dmg=9, kb=1.2)),
    # ---------------- ここから v10 の新キャラ ----------------
    dict(name="OLIVE", desc="Gunner", trait="Long, thin pokes", color=(125, 140, 55),
         w=38, h=60, accel=0.9, run=5.8, jump=12.0, jumps=2, gravity=0.60, weight=0.95,
         side=mv(76, 4, 0.7, 6, 18, tall=16), up=mv(52, 5, 0.9, 8, 22),
         down=mv(48, 7, 1.0, 10, 30),
         neutral=proj("Burst Fire", 16, 20, 9, 2, 0.4, 40, 14, (255, 225, 120), recoil=2.0),
         up_sp=upsp("Jet Pack", "jet", frames=28, rise=6.4, dmg=2, kb=0.7, hits=4, every=6,
                    glide=18)),
    dict(name="LILAC", desc="Trickster", trait="Lunging quick jabs", color=(205, 165, 245),
         w=36, h=58, accel=1.0, run=6.2, jump=12.5, jumps=2, gravity=0.56, weight=0.85,
         side=mv(48, 5, 0.9, 8, 18, lunge=4.0), up=mv(50, 5, 0.95, 8, 20),
         down=mv(46, 6, 1.0, 10, 24),
         neutral=proj("Swap Orb", 6.5, 32, 32, 3, 0.2, 90, 80, (215, 170, 255), swap=True),
         up_sp=upsp("Blink Step", "blink", dist=210, glide=24)),
    dict(name="SAND", desc="Time Mage", trait="Delayed, spaced swings", color=(225, 200, 140),
         w=38, h=60, accel=0.85, run=5.4, jump=12.0, jumps=2, gravity=0.58, weight=1.0,
         side=mv(52, 6, 1.0, 10, 26, gap=6, delay=4), up=mv(52, 6, 1.05, 10, 28),
         down=mv(48, 7, 1.1, 10, 32),
         neutral=proj("Time Field", 0, 230, 130, 0, 0.0, 200, 180, (235, 210, 150),
                      kind="zone", ahead=130),
         up_sp=upsp("Rewind", "rewind", delay=22)),
    dict(name="RUST", desc="Berserker", trait="More dmg taken = harder hits", color=(200, 85, 45),
         w=44, h=62, accel=0.85, run=5.6, jump=11.5, jumps=2, gravity=0.62, weight=1.15,
         rage=0.06,
         side=mv(50, 8, 1.1, 10, 30, lunge=2.0), up=mv(52, 8, 1.15, 10, 32),
         down=mv(50, 9, 1.3, 10, 36),
         neutral=spec("Whirlwind", "rush", 85, frames=40, speed=2.6, dmg=3, kb=0.9,
                      hit="spin", hits=4, every=9),
         up_sp=upsp("Rage Dive", "homing", speed=12, frames=22, dmg=9, kb=1.1)),   # v14: 速さ15→12、時間26→22(最大飛距離 約390→約265)
    # ---------------- ここから v10 の追加キャラ(後半) ----------------
    dict(name="EMBER", desc="Pyromancer", trait="Fireballs burn foes", color=(255, 60, 0),
         w=40, h=60, accel=0.95, run=6.2, jump=12.0, jumps=2, gravity=0.60, weight=0.95,
         side=mv(48, 5, 0.9, 8, 18), up=mv(50, 5, 0.9, 8, 20), down=mv(46, 6, 1.0, 10, 26),
         neutral=proj("Fireball", 8.5, 26, 26, 4, 0.5, 70, 42, (255, 120, 30), vy=-2.0,
                      grav=0.12, burn=240),
         up_sp=upsp("Phoenix Burst", "phoenix", frames=13, vx=5.5, vy=9.5, dmg=6, kb=0.9,
                    pop=7, burst_dmg=8, burst_kb=1.2, glide=20)),
    dict(name="UMBER", desc="Golem", trait="Armored heavy swings", color=(95, 70, 55),
         w=48, h=66, accel=0.70, run=4.4, jump=10.8, jumps=2, gravity=0.72, weight=1.40,
         side=mv(52, 10, 1.3, 12, 40, armor=True), up=mv(54, 9, 1.3, 12, 38),
         down=mv(52, 10, 1.4, 12, 40, armor=True),
         neutral=proj("Shockwave", 7, 64, 60, 8, 1.1, 60, 75, (150, 115, 90), low=True, both=True),
         up_sp=upsp("Stone Pillar", "pillar", frames=22, rise=5.0, life=120, dmg=10, kb=1.1)),
    dict(name="SILVER", desc="Speedster", trait="Fast triple jabs", color=(175, 180, 195),
         w=34, h=58, accel=1.40, run=8.0, jump=13.0, jumps=2, gravity=0.55, weight=0.72,
         side=mv(44, 2, 0.7, 10, 14, hits=3, every=3), up=mv(46, 4, 0.9, 8, 16),
         down=mv(44, 4, 0.9, 8, 18),
         neutral=spec("Flash Step", "rush", 45, frames=11, speed=16, dmg=4, kb=0.9,
                      reach=50, phase=True, air_once=True),
         up_sp=upsp("Sky Steps", "airstep", speed=13, seg=6, steps=3)),
    dict(name="CORAL", desc="Totem Summoner", trait="Long trident pokes", color=(255, 120, 100),
         w=38, h=60, accel=0.90, run=5.6, jump=12.0, jumps=2, gravity=0.58, weight=1.00,
         side=mv(72, 5, 0.9, 10, 26, gap=8), up=mv(52, 6, 1.0, 10, 26),
         down=mv(50, 6, 1.0, 10, 30),
         neutral=proj("Totem", 0, 30, 48, 0, 0.0, 420, 150, (255, 130, 110),
                      kind="turret", ahead=90),
         up_sp=upsp("Tide Bubble", "bubble", frames=70, rise=2.8, glide=30)),
    # ---------------- ここから v10 の追加キャラ(さらに3体) ----------------
    dict(name="PLUM", desc="Jester", trait="Two-flick jabs", color=(125, 55, 125),
         w=36, h=58, accel=1.0, run=6.4, jump=12.5, jumps=2, gravity=0.56, weight=0.80,
         side=mv(46, 4, 0.8, 9, 16, hits=2, every=4), up=mv(50, 5, 1.0, 8, 20),
         down=mv(46, 6, 1.0, 10, 24),
         neutral=proj("Joker Dart", 11, 22, 14, 3, 0.4, 60, 60, (190, 70, 220), vy=-1.5,
                      grav=0.08, confuse=110, confuse_chance=0.4),
         up_sp=upsp("Jack Hop", "pogo", frames=45, hop=9.0, every=15, glide=20)),
    dict(name="ONYX", desc="Grappler", trait="Slow heavy hooks", color=(62, 62, 78),
         w=46, h=64, accel=0.80, run=5.2, jump=11.0, jumps=2, gravity=0.66, weight=1.20,
         side=mv(48, 9, 1.2, 10, 34), up=mv(50, 8, 1.2, 10, 32), down=mv(46, 9, 1.3, 10, 36),
         neutral=spec("Command Grab", "grab", 70, frames=10, dmg=11, kb=1.5, reach=62),
         up_sp=upsp("Grapple Reel", "reel", range=560, speed=17, frames=24)),
    dict(name="TOPAZ", desc="Spring Acrobat", trait="Light quick pokes", color=(255, 205, 70),
         w=36, h=58, accel=1.0, run=6.0, jump=12.0, jumps=2, gravity=0.58, weight=0.90,
         side=mv(50, 5, 0.9, 8, 16), up=mv(50, 5, 0.95, 8, 18), down=mv(46, 6, 1.0, 10, 24),
         neutral=proj("Coil Ball", 6.5, 26, 26, 5, 0.8, 130, 50, (255, 205, 70), vy=-3.0,
                      grav=0.45, kind="ball"),
         up_sp=upsp("Spring Kick", "springhop", life=110, kick_frames=22, kick_dmg=7, kick_kb=1.1)),
    # ---------------- ここから v14 の新キャラ(6体) ----------------
    dict(name="AMBER", desc="Slugger", trait="Big swing reflects shots", color=(235, 150, 20),
         w=44, h=64, accel=0.80, run=5.4, jump=11.8, jumps=2, gravity=0.62, weight=1.10,
         side=mv(66, 11, 1.45, 8, 46, delay=9, tall=76, reflect=True),
         up=mv(54, 9, 1.25, 10, 40, delay=6, reflect=True),
         down=mv(56, 8, 1.2, 10, 36),
         neutral=proj("Rising Fastball", 6, 24, 24, 5, 0.9, 80, 55, (255, 245, 225),
                      accel=0.35, ramp=9),
         up_sp=upsp("Slugger Swing", "cannon", aim=36, speed=15, frames=18, dmg=11, kb=1.3)),
    dict(name="JADE", desc="Monk", trait="Short 3-hit combo chains", color=(40, 175, 115),
         w=36, h=60, accel=0.95, run=5.8, jump=12.2, jumps=2, gravity=0.58, weight=0.95,
         side=mv(46, 4, 0.55, 8, 22, hits=2, every=3, lunge=2.0, stun=14),   # v15: 硬直18→14 / 隙18→22
         up=mv(52, 5, 0.7, 8, 24, stun=12),                                  # v15: 硬直16→12 / 隙20→24
         down=mv(46, 6, 0.9, 8, 26, stun=10),                                # v15: 硬直12→10 / 隙24→26
         neutral=spec("Meditate", "focus", 160, frames=55, heal=9),
         up_sp=upsp("Whirl Ascent", "spiral", frames=34, rise=7.0, rad=5.5, dmg=3, kb=0.8,
                    hits=4, every=7, glide=16)),
    dict(name="AZURE", desc="Tide Mage", trait="Tide slap pushes flat & far", color=(40, 150, 255),
         w=36, h=58, accel=0.90, run=5.6, jump=12.0, jumps=2, gravity=0.56, weight=0.90,
         side=mv(58, 5, 1.1, 10, 26, gap=8, flat=True),
         up=mv(84, 7, 1.3, 12, 36, delay=6, gap=4),
         down=mv(50, 6, 1.0, 10, 28),
         neutral=proj("Geyser", 0, 56, 180, 9, 1.1, 70, 95, (90, 190, 255),
                      kind="geyser", ahead=150),
         up_sp=upsp("Tidal Surf", "surf", rise_t=8, rise_vx=5.0, rise_vy=10.0,
                    glide_t=24, glide_vx=10.0, glide_vy=2.0, dmg=5, kb=0.9)),
    dict(name="SCARLET", desc="Shadow Ninja", trait="Backstabs hit 1.6x harder",
         color=(255, 35, 60), w=34, h=56, accel=1.20, run=7.2, jump=12.8, jumps=2,
         gravity=0.56, weight=0.78, backstab=1.6,
         side=mv(46, 5, 0.85, 7, 14, lunge=3.0), up=mv(50, 5, 0.95, 8, 18),
         down=mv(46, 6, 1.0, 8, 22),
         neutral=spec("Shadow Strike", "tele", 150, range=340, dmg=8, kb=1.1, frames=8, windup=22),   # v15: 予告22F / 射程340 / 待ち150
         up_sp=upsp("Kunai Zip", "kunai", range=270, delay=5)),
    dict(name="MOSS", desc="Vine Gardener", trait="Vines root foes in place", color=(85, 125, 75),
         w=40, h=62, accel=0.80, run=5.2, jump=11.5, jumps=2, gravity=0.60, weight=1.15,
         side=mv(62, 6, 0.8, 10, 30, gap=6, root=55),
         up=mv(56, 6, 0.9, 10, 28, root=40),
         down=mv(50, 7, 1.0, 10, 32, root=40),
         neutral=proj("Thorn Snare", 0, 58, 22, 5, 0.5, 520, 110, (130, 190, 90),
                      kind="snare", ahead=130, arm=24),
         up_sp=upsp("Beanstalk", "stalk", n=4, step=62, life=170, cd=240, vy=8)),
    dict(name="COBALT", desc="Stance Master", trait="Swift jabs / Heavy armor smash",
         color=(25, 75, 190), w=40, h=64, accel=0.90, run=5.8, jump=12.0, jumps=2,
         gravity=0.60, weight=1.05, stance=True,
         side=mv(52, 7, 1.0, 10, 28, lunge=2.0), up=mv(54, 7, 1.0, 10, 28),
         down=mv(50, 8, 1.1, 10, 30),
         neutral=spec("Stance Switch", "stance", 36),
         up_sp=upsp("Stance Rise", "twin", speed=15, seg=10, vy=15, frames=16, dmg=11, kb=1.2)),
    # ---------------- ここから v15 の新キャラ ----------------
    dict(name="OPAL", desc="Copycat", trait="Balanced mid-range punches", color=(200, 235, 230),
         w=38, h=60, accel=0.90, run=5.8, jump=12.0, jumps=2, gravity=0.58, weight=0.95,
         mimic=True,
         side=mv(50, 6, 1.0, 10, 24), up=mv(52, 6, 1.0, 10, 26), down=mv(48, 7, 1.1, 10, 30),
         neutral=spec("Copy Cat", "mimic", 80,
                      fallback=proj("Echo Orb", 9, 26, 26, 5, 0.8, 70, 70, (210, 235, 235))),
         up_sp=upsp("Echo Leap", "echo", vy=11.5, gap=16, bursts=2, sx=7.0, sy=11.0, glide=14)),
    # ---------------- ここから v16 の新キャラ ----------------
    # IVORY: 「間合い」のキャラ。先端で当てれば強く、懐に入られると弱い。
    #        必殺技=後ろへバク転しながら撃つ / 復帰技=真上へ突き上げてから横へ突っ込む(上→横の2段)
    dict(name="IVORY", desc="Spacing Lancer", trait="Tip hits hard, close hits weak",
         color=(238, 226, 190), w=38, h=66, accel=0.85, run=5.6, jump=12.0, jumps=2,
         gravity=0.60, weight=0.95,
         sweet=dict(zone=0.35, dmg=1.7, kb=1.3, lo_dmg=0.6, lo_kb=0.8),
         side=mv(98, 7, 1.0, 8, 34, gap=4, delay=7),
         up=mv(66, 6, 1.0, 9, 26, delay=4),
         down=mv(60, 7, 1.1, 10, 30, delay=5),
         neutral=proj("Skip Shot", 14, 58, 10, 8, 1.1, 55, 60, (250, 240, 200),
                      vy=0.9, recoil=7.0, hop=8.0),
         up_sp=upsp("Sky Lance", "valk", rise_t=11, rise_vy=12.0, rise_dmg=7, rise_kb=1.0,
                    glide_t=22, glide_vx=11.5, glide_vy=-1.0, dmg=8, kb=1.2, reach=70, glide=10)),
    # ---------------- ここから v16.1 の新キャラ ----------------
    # BRONZE: 「コンボ」のキャラ。当てるたびにスタック(最大5)が貯まり、通常攻撃が強く・速くなる。
    #         必殺技=貯めたスタックを全部使う「フィニッシャー」(多いほどダメージ・ふっとびが跳ね上がり、3以上でアーマー)
    #         被弾するとスタックは全部消える。 → 攻めている間だけ強い、リスクとリターンの大きいキャラ
    dict(name="BRONZE", desc="Combo Boxer", trait="Fast jabs; each hit adds power",
         color=(205, 127, 50), w=36, h=60, accel=1.0, run=6.2, jump=12.2, jumps=2,
         gravity=0.58, weight=0.90, combo=True,
         side=mv(44, 3, 0.5, 6, 12), up=mv(46, 4, 0.7, 7, 16), down=mv(44, 5, 0.9, 8, 20),
         neutral=spec("Overdrive Finisher", "finisher", 50, frames=12, speed=9, dmg=4, kb=0.7,
                      reach=56, per_dmg=3, per_kb=0.25),
         up_sp=upsp("Uppercut Rush", "rise", vy=15, frames=14, dmg=6, kb=0.9, iframes=6)),
    # ---------------- ここから v16.2 の新キャラ ----------------
    # COMET: 「衛星(オーブ)」のキャラ。必殺技で3つのオーブが自分のまわりを回る。
    #        回っている間は、近づく相手にぶつかって攻撃 + 飛んでくる弾を1つずつ吸い込んでくれる(守り)。
    #        もう一度必殺技を押すと、残ったオーブが相手めがけて飛んでいく(攻め)。 → 守りと攻めを1つの技で切り替える
    dict(name="COMET", desc="Orbit Mage", trait="Mid-range punches",
         color=(150, 170, 255), w=36, h=60, accel=0.90, run=5.6, jump=12.4, jumps=2,
         gravity=0.52, weight=0.88,
         side=mv(54, 5, 0.9, 10, 26, gap=6), up=mv(52, 6, 1.0, 10, 28), down=mv(48, 6, 1.0, 10, 30),
         neutral=spec("Orbit Guard", "orbit", 200, count=3, rad=66, life=330, spin=0.11,
                      dmg=2, kb=0.6, rehit=20, launch_dmg=6, launch_kb=1.0, launch_speed=11),
         up_sp=upsp("Comet Glide", "boost", vy=12, vx=7, glide=40)),
    # ---------------- ここから v16.3 の新キャラ(2体) ----------------
    # HAZEL: 「印(マーク)」のキャラ。必殺技の矢が当たると、相手に印がつく(約6秒)。
    #        印がついている相手には、HAZELの攻撃(近接も矢も)が1.35倍のダメージ。 → 矢で印をつけて、近づいて仕留める
    dict(name="HAZEL", desc="Mark Archer", trait="Light pokes; fast hops back",
         color=(150, 120, 60), w=34, h=60, accel=1.0, run=6.2, jump=12.4, jumps=2,
         gravity=0.57, weight=0.85, hunter=dict(mult=1.35, frames=360),
         side=mv(56, 4, 0.8, 8, 20), up=mv(50, 5, 0.9, 8, 22), down=mv(46, 6, 1.0, 10, 26),
         neutral=proj("Hunter's Arrow", 17, 36, 8, 4, 0.5, 55, 48, (200, 225, 120), recoil=2.5),
         up_sp=upsp("Grapple Arrow", "reel", range=520, speed=17, frames=22)),
    # PEARL: 「加護(ウォード)」のキャラ。必殺技で光の膜をまとう(約6秒)。
    #        膜が残っている間に受けた最初の攻撃は、ダメージもふっとびも0になり、攻撃してきた相手が弾き飛ばされる。
    #        膜は1回で消え、張り直すまで長い待ち時間がある。 → 「次の1発」を無効にする、タイミング勝負の守りのキャラ
    dict(name="PEARL", desc="Ward Priest", trait="Steady medium punches",
         color=(250, 225, 235), w=38, h=62, accel=0.85, run=5.4, jump=12.0, jumps=2,
         gravity=0.60, weight=1.05,
         side=mv(52, 6, 1.0, 10, 26), up=mv(54, 6, 1.0, 10, 28), down=mv(48, 7, 1.1, 10, 30),
         neutral=spec("Holy Ward", "ward", 420, frames=360),
         up_sp=upsp("Holy Stair", "plat", life=200, cd=240)),
    # ---------------- ここから v18 の新キャラ(3体) ----------------
    # RAVEN: 「呪い」のキャラ。必殺技の弾が当たると、相手に呪い(頭の上に紫のカウントダウン)がつく。
    #        約4秒後に呪いが爆発して、相手は14%+強く打ち上げられる(ガード不可)。
    #        解く方法は1つだけ → 相手がRAVENに攻撃(近接でも飛び道具でも)を当てること。
    #        呪い中のRAVENは速くなる(逃げ回れる) / 呪われた側は、RAVENを追いかけるしかない。 → 追う/逃げるの駆け引き
    #        復帰技=ゴーストライズ：ステージも壁も通り抜けて上がる(真下からでも戻れる)
    dict(name="RAVEN", desc="Curse Caster", trait="Light jabs; Hex = time bomb on foe",
         color=(80, 30, 110), w=34, h=58, accel=1.05, run=6.6, jump=12.6, jumps=2,
         gravity=0.54, weight=0.82, hex=dict(frames=240, dmg=14, kb=1.5),
         side=mv(44, 4, 0.8, 7, 14, lunge=1.5), up=mv(48, 5, 0.95, 8, 18),
         down=mv(44, 5, 1.0, 8, 22),
         neutral=proj("Hex Orb", 7, 30, 30, 2, 0.3, 90, 70, (170, 70, 220), hex=True),
         up_sp=upsp("Ghost Rise", "phase", frames=30, rise=6.5, side=5.0, glide=14)),
    # NEBULA: 「ポータル」のキャラ。必殺技1回目=入口(青) / 2回目=出口(橙) / 3回目=全部消す。
    #         ポータルは約10秒残り、だれでも(相手も)・どんな弾でも通り抜けられる。
    #         自分の移動・相手の弾の逸らし・相手を引き込んで殴る、など使い方しだい。
    #         復帰技=ゲートジャンプ：近くの崖へ出入口を開いて移動する(ポータルは残るので、相手に追われることも)
    dict(name="NEBULA", desc="Portal Mage", trait="Mid-range punches",
         color=(190, 90, 255), w=36, h=60, accel=0.95, run=5.9, jump=12.4, jumps=2,
         gravity=0.56, weight=0.92,
         side=mv(50, 5, 0.9, 9, 22), up=mv(50, 6, 1.0, 9, 24), down=mv(46, 6, 1.0, 10, 28),
         neutral=spec("Portal Gun", "portal", 70, life=600, dist=110, gap=170),
         up_sp=upsp("Gate Jump", "gate", range=620, delay=12)),
    # GRANITE: 「溜め攻撃」のキャラ。横攻撃/上攻撃は、ボタンを押し続けるとためられて、離すと出る
    #          (最大約0.75秒。満タンで ダメージ約2.2倍 / ふっとび約1.9倍、満タン近くはアーマーつき)。
    #          溜めている間は動けず無防備(ガードボタンで中止)。 → 当てれば一撃、読まれると危険
    #          復帰技=ストーンランチ：必殺技ボタンを押している間ためて、離すと跳ぶ(長く押すほど高い)
    dict(name="GRANITE", desc="Charge Smasher", trait="Hold ATK to charge a huge smash",
         color=(135, 140, 150), w=46, h=66, accel=0.78, run=5.0, jump=11.2, jumps=2,
         gravity=0.66, weight=1.28, smash=dict(max=45, dmg=1.2, kb=0.9, armor_at=0.8),
         side=mv(58, 7, 1.15, 9, 36, tall=64), up=mv(56, 6, 1.1, 9, 34),
         down=mv(50, 7, 1.1, 10, 30),
         neutral=proj("Quake", 7, 60, 30, 7, 1.1, 55, 75, (150, 140, 120), low=True, pierce=True),
         up_sp=upsp("Boulder Launch", "chargejump", max=30, vy=10.0, per=0.3, frames=18,
                    dmg=10, kb=1.1)),
]


# ======================================================================
#  アイテム
# ======================================================================
ITEM_TYPES = {
    "heal": dict(label="H", color=(90, 220, 120)),
    "power": dict(label="P", color=(240, 90, 70)),
    "speed": dict(label="S", color=(90, 160, 255)),
    "star": dict(label="*", color=(255, 225, 80)),
    # ---- v10 ----
    "barrier": dict(label="B", color=(80, 210, 200)),    # ダメージ半分・飛ばされにくい・シールド全回復
    "wing": dict(label="W", color=(255, 205, 245)),      # ふわふわ + ジャンプ+2回
    "bomb": dict(label="!", color=(235, 70, 60)),        # 罠！ 取ると爆発して自分が飛ぶ
    "frost": dict(label="F", color=(150, 220, 255)),     # 相手を冷やして遅くする
}
ITEM_KINDS = list(ITEM_TYPES)
ITEM_WEIGHTS = {"heal": 3, "power": 3, "speed": 3, "star": 1.5,
                "barrier": 2, "wing": 2, "bomb": 2, "frost": 2}


class Item:
    SIZE = 28

    def __init__(self, kind, x, y):
        self.kind = kind
        self.x = float(x)
        self.y = float(y)
        self.vy = 0.0
        self.life = 1200
        self.dead = False

    @property
    def rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.SIZE, self.SIZE)

    def update(self):
        sz = self.SIZE
        prev_bottom = self.y + sz
        self.vy = min(self.vy + 0.35 * STAGE_GRAV, 6.0)
        self.y += self.vy
        for s in SOLID + THIN:
            if (self.vy >= 0 and self.x < s.right and s.left < self.x + sz
                    and self.y < s.bottom and s.top < self.y + sz
                    and prev_bottom <= s.top + 1):
                self.y = s.top - sz
                self.vy = 0.0
                break
        self.life -= 1
        if self.life <= 0 or self.y > BLAST.bottom:
            self.dead = True


class Inp:
    """1フレーム分のキー入力（人間もCPUも同じ形で扱う）"""
    def __init__(self, left=False, right=False, up=False, down=False, guard=False,
                 attack=False, special=False):
        self.attack = attack         # 攻撃ボタンを押している間 True(溜め攻撃用)
        self.special = special       # 必殺技ボタンを押している間 True(ためる復帰技用)
        self.left = left
        self.right = right
        self.up = up
        self.down = down
        self.guard = guard


def human_input(keys, pressed):
    return Inp(pressed[keys["left"]], pressed[keys["right"]],
               pressed[keys["jump"]], pressed[keys["down"]], pressed[keys["guard"]],
               pressed[keys["attack"]], pressed[keys["special"]])


# ======================================================================
#  カメラ（2人が離れるとズームアウトして、両方が見えるようにする）
# ======================================================================
class Camera:
    PAD_X, PAD_Y = 280, 220
    MIN_SCALE = 0.45

    def __init__(self, fighters):
        self.cx, self.cy, self.s = W / 2, H / 2, 1.0
        self.update(fighters, snap=True)

    def update(self, fighters, snap=False):
        xs = [MAIN.centerx]
        ys = [MAIN.top]
        for f in fighters:
            xs += [f.x, f.x + f.w]
            ys += [f.y, f.y + f.h]
        left, right, top, bottom = min(xs), max(xs), min(ys), max(ys)
        need_w = (right - left) + 2 * self.PAD_X
        need_h = (bottom - top) + 2 * self.PAD_Y
        target_s = max(self.MIN_SCALE, min(1.0, W / need_w, H / need_h))
        target_x = (left + right) / 2
        target_y = (top + bottom) / 2
        if snap:
            self.s, self.cx, self.cy = target_s, target_x, target_y
        else:
            self.s += (target_s - self.s) * 0.08
            self.cx += (target_x - self.cx) * 0.12
            self.cy += (target_y - self.cy) * 0.12

    def pt(self, x, y):
        return (int(round((x - self.cx) * self.s + W / 2)),
                int(round((y - self.cy) * self.s + H / 2)))

    def rect(self, r):
        x, y = self.pt(r.x, r.y)
        return pygame.Rect(x, y, max(1, int(round(r.w * self.s))),
                           max(1, int(round(r.h * self.s))))


def lum(col):
    return 0.299 * col[0] + 0.587 * col[1] + 0.114 * col[2]


def ui_color(col):
    """文字・目印用の色。暗い色(ONYXなど)は、読める明るさまで白に近づける"""
    l = lum(col)
    if l >= 85:                                       # ふつうの色はそのまま(極端に暗い色だけ明るくする)
        return col
    t = (155 - l) / (255 - l)
    return tuple(int(v + (255 - v) * t) for v in col)


def draw_body(screen, rect, color, facing, scale=1.0, flash=False, ghost=False):
    if ghost:                                         # 回避中・崖つかまり直後：半透明っぽく
        col = tuple(int(v * 0.35 + 45) for v in color)
    else:
        col = (255, 255, 255) if flash else color
    pygame.draw.rect(screen, col, rect, border_radius=max(2, int(8 * scale)))
    if ghost:
        pygame.draw.rect(screen, color, rect, width=2, border_radius=max(2, int(8 * scale)))
    elif lum(color) < 70:                             # 暗い体は、明るい縁取りで見やすく
        pygame.draw.rect(screen, (205, 205, 225), rect, width=2, border_radius=max(2, int(8 * scale)))
    eye_x = rect.centerx + int(8 * scale * facing)
    eye_y = rect.y + int(16 * scale)
    pygame.draw.circle(screen, (255, 255, 255), (eye_x, eye_y), max(2, int(7 * scale)))
    pygame.draw.circle(screen, (20, 20, 20), (eye_x + int(2 * scale * facing), eye_y),
                       max(1, int(3 * scale)))


# ======================================================================
#  飛び道具
# ======================================================================
class Projectile:
    def __init__(self, owner, cx, cy, vx, vy, w, h, damage, power, life,
                 gravity=0.0, color=(255, 255, 255), kind="normal", fuse=0, blast=0,
                 pierce=False, wave=0.0, freeze=False, persist=False, arm=0,
                 boomerang=0, pull=False, rehit=0, chill=0, swap=False, burn=0, confuse=0,
                 confuse_chance=1.0, accel=0.0, ramp=0):
        self.hex = False             # 当たると呪いをかける弾(RAVEN)
        self.mate = None             # ポータル：もう片方の出入口(NEBULA)
        self.pcd = 0                 # ポータルを通ったあと、しばらく通れない時間
        self.owner = owner
        self.x = cx - w / 2
        self.y = cy - h / 2
        self.by = self.y             # 波打つ前の基準の高さ
        self.vx = vx
        self.vy = vy
        self.w = w
        self.h = h
        self.damage = damage
        self.power = power
        self.life = life
        self.gravity = gravity
        self.color = color
        self.kind = kind
        self.fuse = fuse
        self.blast = blast
        self.pierce = pierce
        self.wave = wave
        self.freeze = freeze
        self.persist = persist
        self.arm = arm
        self.boomerang = boomerang   # 行って戻ってくるまでの時間（0ならふつうに飛ぶ）
        self.vx0 = vx
        self.bacc = (-2.0 * vx / boomerang) if boomerang else 0.0
        self.turned = False
        self.pull = pull             # 当たった相手を撃った人の方へ引っ張る
        self.rehit = rehit           # 貫通弾が当たり直すまでの間隔
        self.hit_cd = 0
        self.chill = chill
        self.swap = swap             # 当たった相手と位置が入れ替わる
        self.burn = burn             # 当てた相手を燃やす時間
        self.confuse = confuse       # 当てた相手を混乱させる時間(左右が逆になる)
        self.confuse_chance = confuse_chance    # 混乱する確率
        self.bounces = 0             # ボール：何回はずんだか
        self.launch_atk = False      # ばね：はね上がった持ち主に蹴り上げの攻撃判定をつける
        self.uses = 0                # ばね：何回はね上げたか
        self.max_uses = 4            # ばね：何回で壊れるか
        self.accel = accel           # 毎フレームの加速(ライジングファストボール)
        self.ramp = ramp             # この間隔ごとにダメージ+1
        self.base_damage = damage
        self.phase = 0.0             # オーブ(COMET)：回る角度のずらし
        self.rad = 0.0               # オーブ：持ち主からの距離
        self.spin = 0.0              # オーブ：1フレームで回る角度
        self.age = 0
        self.exploding = 0           # 爆発している残り時間（bombのみ）
        self.hit_done = False
        self.dead = False

    @property
    def rect(self):
        if self.exploding > 0:       # 爆発中は大きな四角
            cx = self.x + self.w / 2
            cy = self.y + self.h / 2
            b = self.blast
            return pygame.Rect(int(cx - b / 2), int(cy - b / 2), b, b)
        return pygame.Rect(int(self.x), int(self.y), self.w, self.h)

    def explode(self):
        if self.exploding == 0:
            self.exploding = 8
            self.vx = 0.0
            self.vy = 0.0

    def update(self):
        self.age += 1
        if self.pcd > 0:
            self.pcd -= 1
        if self.kind == "orbit":                 # オーブ：持ち主のまわりを回る。時間で消える
            self.life -= 1
            if self.life <= 0:
                self.dead = True
                return
            if self.hit_cd > 0:
                self.hit_cd -= 1
                if self.hit_cd == 0:
                    self.hit_done = False
            o = self.owner
            ang = self.phase + self.age * self.spin
            cx = o.x + o.w / 2 + math.cos(ang) * self.rad
            cy = o.y + o.h / 2 + math.sin(ang) * self.rad * 0.8
            self.x = cx - self.w / 2
            self.y = cy - self.h / 2
            self.by = self.y
            return
        if self.kind in STATIC_KINDS:            # 置いてある「場」/砲台/ばね/間欠泉/わな：動かず、時間で消える
            self.life -= 1
            if self.life <= 0:
                self.dead = True
            return
        if self.kind == "ball":                  # はずむ弾
            self.update_ball()
            return
        if self.kind == "bomb":
            self.update_bomb()
            return
        if self.hit_cd > 0:                      # 風/ブラックホール：一定間隔で当たり直す
            self.hit_cd -= 1
            if self.hit_cd == 0:
                self.hit_done = False
        if self.boomerang:                       # ブーメラン：だんだん減速して戻ってくる
            self.vx += self.bacc
            if not self.turned and self.vx * self.vx0 <= 0:
                self.turned = True
                self.hit_done = False            # 帰り道でもう一度当たる
                self.hit_cd = 0
        if self.accel and abs(self.vx) < 22:     # 加速する弾
            self.vx += math.copysign(self.accel, self.vx)
            self.vx0 = self.vx
        if self.ramp and self.age % self.ramp == 0 and self.damage < self.base_damage + 8:
            self.damage += 1                     # 飛ぶほど痛くなる弾
        self.vy += self.gravity * STAGE_GRAV
        self.x += self.vx
        self.by += self.vy
        self.y = self.by + (self.wave * math.sin(self.age * 0.35) if self.wave else 0.0)
        self.life -= 1
        r = self.rect
        if self.life <= 0 or not BLAST.colliderect(r):
            self.dead = True
        for s in SOLID:
            if r.colliderect(s):
                self.dead = True

    def update_ball(self):
        """床や足場ではずみ、壁ではね返る弾。時間か回数で消える"""
        self.life -= 1
        if self.life <= 0:
            self.dead = True
            return
        self.vy += self.gravity * STAGE_GRAV
        self.x += self.vx
        prev_bottom = self.y + self.h
        self.y += self.vy
        r = self.rect
        for s in SOLID:
            if r.colliderect(s):
                if self.vy >= 0 and prev_bottom <= s.top + 4:     # 床ではずむ
                    self.y = s.top - self.h
                    self.vy = -max(7.5, abs(self.vy) * 0.9)
                    self.bounces += 1
                else:                                             # 壁ではね返る
                    self.vx = -self.vx
                    self.x += self.vx * 2
                r = self.rect
        if self.vy >= 0:
            for s in THIN:
                if r.colliderect(s) and prev_bottom <= s.top + 4:
                    self.y = s.top - self.h
                    self.vy = -max(7.5, abs(self.vy) * 0.9)
                    self.bounces += 1
                    break
        if self.bounces > 5 or not BLAST.colliderect(self.rect):
            self.dead = True

    def update_bomb(self):
        if self.exploding > 0:
            self.exploding -= 1
            if self.exploding == 0:
                self.dead = True
            return
        self.vy += self.gravity * STAGE_GRAV
        self.x += self.vx
        prev_bottom = self.y + self.h
        self.y += self.vy
        r = self.rect
        for s in SOLID:
            if r.colliderect(s):
                if self.vy >= 0 and prev_bottom <= s.top + 2:     # 床に着地して止まる
                    self.y = s.top - self.h
                    self.vy = 0.0
                    self.vx = 0.0
                else:
                    self.explode()                                 # 壁にぶつかったら爆発
        if self.exploding == 0 and self.vy >= 0:
            for s in THIN:
                if r.colliderect(s) and prev_bottom <= s.top + 2:
                    self.y = s.top - self.h
                    self.vy = 0.0
                    self.vx = 0.0
        self.fuse -= 1
        if self.fuse <= 0:
            self.explode()
        if not BLAST.colliderect(self.rect):
            self.dead = True


# ======================================================================
#  ファイター
# ======================================================================
class Fighter:
    def __init__(self, tag, char, color, start_x, keys=None, cpu=None):
        self.tag = tag
        self.c = char
        self.color = color
        self.start_x = start_x
        self.keys = keys
        self.cpu = cpu
        self.w = char["w"]
        self.h = char["h"]
        self.stocks = STOCKS
        self.shots = []              # 撃った飛び道具（Matchが回収する）
        self.ledge = None
        self.foe = None              # 相手（Matchが入れる）
        self.respawn()

    def respawn(self):
        self.release_ledge()
        self.x = float(self.start_x)
        self.y = float(MAIN.top - 380)
        self.vx = 0.0
        self.vy = 0.0
        self.percent = 0
        self.jumps = self.c["jumps"]
        self.up_ready = True         # 復帰技が使えるか（着地・崖つかまりで回復）
        self.air_steps = 0           # スカイステップを空中で何回使ったか
        self.air_rush_used = False   # 空中でフラッシュステップを使ったか（着地で回復）
        self.facing = 1 if self.start_x < MAIN.centerx else -1
        self.on_ground = False
        # 通常攻撃
        self.startup = 0             # 攻撃の溜め（発生前）
        self.attack_timer = 0        # 攻撃判定が出ている残り時間
        self.atk_active = 0
        self.cooldown = 0
        self.hits_left = 0           # あと何回ヒットできるか
        self.hit_gap = 0
        self.hit_every = 3
        self.atk_dir = "side"
        self.atk_facing = self.facing
        self.atk_reach = 50
        self.atk_gap = 0
        self.atk_tall = 0
        self.atk_dmg = 1
        self.atk_kb = 1.0
        self.atk_armor = False
        self.atk_chill = 0           # この攻撃が相手に与える「冷え」の時間
        self.atk_burn = 0            # この攻撃が相手に与える「燃焼」の時間
        self.atk_grab = False        # つかみ攻撃（ガードを貫通する）
        self.atk_pull = False        # この攻撃は相手を引き寄せる
        self.atk_crit = False        # この攻撃は「大当たり」か
        self.atk_reflect = False     # この攻撃は飛び道具を打ち返す(AMBER)
        self.atk_stun = 0            # この攻撃で、相手の硬直が長くなる分(JADE)
        self.atk_flat = False        # この攻撃は相手を真横に押す(AZURE)
        self.atk_root = 0            # この攻撃で、相手の足をからめる時間(MOSS)
        # 必殺技
        self.sp_timer = 0            # 上必殺技などの攻撃判定の残り時間
        self.special_cd = 0          # 必殺技の再使用待ち
        self.charge_timer = 0        # ロケットの溜め
        self.hook = None             # ロープで引っ張られている行き先
        self.hook_start = None        # ムチ(swing)の出発点
        self.hook_t = 0.0             # ムチ(swing)の進み具合 0〜1
        self.rm = None                # 復帰技の特殊な動き(quick/launch/copter/rift)
        self.glide_timer = 0         # ふわふわ時間
        self.chute_timer = 0         # パラシュート時間
        self.flight_timer = 0        # 自由に飛べる時間
        self.counter_timer = 0       # カウンターの構え
        self.plat_cd = 0             # 足場を作る復帰技の再使用待ち
        self.mines_out = 0           # 場に出ている自分の地雷の数（Matchが数える）
        self.detonate = False        # 地雷を起爆する合図（Matchが処理する）
        self.det_cd = 0              # 起爆の連打防止
        self.rush_v = 0.0            # 突進の速さ
        self.cast_timer = 0          # 必殺技のエフェクト
        # 回避・崖
        self.dodge_timer = 0
        self.dodge_dir = 0
        self.dodge_cd = 0
        self.ghost_timer = 0         # 無敵の間、半透明で表示する
        self.ledge = None            # つかまっている崖 (key, side, px, py)
        self.ledge_cd = 0            # 崖から離れた直後は、つかまれない
        self.hang_age = 0
        self.hang_left = 0
        self.prev_toward = False
        self.climb_left = 0          # 崖のぼりの残り時間
        self.climb_total = 1
        self.climb_from = (0.0, 0.0)
        self.climb_to = (0.0, 0.0)
        self.climb_side = -1
        self.climb_attack = False
        # 状態
        self.meteor_timer = 0        # メテオで急降下中
        self.lock = 0                # ジャンプ・復帰技が使えない時間（メテオ後）
        self.stun = 0
        self.freeze_timer = 0        # 凍っている間
        self.chill_timer = 0         # 冷えている間（動きが遅い）
        self.burn_timer = 0          # 燃えている間（40フレームごとに%が増える）
        self.confuse_timer = 0       # 混乱している間（左右の操作が逆）
        self.root_timer = 0          # 足がからまっている間（地上で歩けない）
        self.focus_timer = 0         # 瞑想中（JADE）
        self.tele_wait = 0           # シャドウストライクで「消えている」残り時間（SCARLET）
        self.tele_dest = None        # その行き先 (x, y, 向き)
        self.stun_chain = 0          # 硬直ののびる攻撃(JADE)を、続けて何回受けたか
        self.chain_timer = 0         # この間に次を受けないと、上の回数は0に戻る
        self.stance = 0              # スタンス 0=SWIFT / 1=HEAVY（COBALT）
        self.combo = 0               # コンボスタック 0〜5（BRONZE）
        self.combo_timer = 0         # この間に次を当てないとスタックが消える
        self.fin_t = 0               # フィニッシャーを出している間(この間はスタックが貯まらない)
        self.orbs_out = 0            # 回っているオーブの数（COMET）
        self.mark_timer = 0          # 印がついている間(HAZELに1.35倍のダメージを受ける)
        self.ward = 0                # 加護の膜が残っている時間(PEARL)
        self.ward_pop = 0            # 膜が弾けた演出の残り時間
        self.launch_orbs = False     # オーブを撃ち出す合図（COMET）
        self.hex_timer = 0           # 呪われている残り時間(0になると爆発)(RAVEN)
        self.hex_by = None           # 呪いをかけた人
        self.hex_pop = 0             # 呪いの爆発/解除の演出
        self.chg = None              # 溜め攻撃中 dict(dir, t)(GRANITE)
        self.portal_req = False      # ポータルを置く合図(NEBULA)(Matchが処理する)
        self.gate_req = None         # ゲートジャンプの出入口を開く合図
        self.portal_cd = 0           # ポータルを通ったあと、しばらく通れない時間
        self.portals_out = 0         # 場に出ている自分のポータルの数(Matchが数える)
        self.invincible = 120        # 復活直後は無敵
        self.guarding = False
        self.shield = 100.0
        # アイテム効果
        self.power_timer = 0
        self.speed_timer = 0
        self.barrier_timer = 0       # バリア：ダメージ半分
        self.wing_timer = 0          # ウィング：ふわふわ + ジャンプ+2
        self.last_ground = None      # 最後に立っていた場所（SANDの巻き戻し用）
        self.shots.clear()

    @property
    def rect(self):
        return pygame.Rect(int(self.x), int(self.y), self.w, self.h)

    def overlaps(self, r):
        """小数のまま重なりを判定する（着地判定のチラつき防止）"""
        return (self.x < r.right and r.left < self.x + self.w and
                self.y < r.bottom and r.top < self.y + self.h)

    def land(self, top, refresh=True):
        self.rm = None
        self.hook_start = None
        self.y = top - self.h
        self.vy = 0
        self.on_ground = True
        self.jumps = self.max_jumps()
        if refresh:                                  # 作り出した足場(石柱)では、復帰技は回復しない
            self.up_ready = True
        self.chute_timer = 0
        self.flight_timer = 0

    def pmult(self):
        return 1.5 if self.power_timer > 0 else 1.0

    def max_jumps(self):
        return self.c["jumps"] + (2 if self.wing_timer > 0 else 0)

    def eff_weight(self):
        """飛ばされにくさ（バリア中は重くなる）"""
        return self.c["weight"] * (1.4 if self.barrier_timer > 0 else 1.0)

    def gain(self, dmg):
        """%を増やす（バリア中は半分）"""
        if self.barrier_timer > 0:
            dmg *= 0.5
        self.percent += max(1, int(round(dmg)))

    def pop_ward(self, att):
        """加護の膜が攻撃を無効にして弾ける。近接の攻撃者は弾き飛ばされる（PEARL）"""
        self.ward = 0
        self.ward_pop = 18
        self.invincible = max(self.invincible, 24)
        if att is not None:
            away = 1 if att.rect.centerx >= self.rect.centerx else -1
            att.gain(5)
            att._hurt(16)
            att.vx = away * 9.0
            att.vy = -5.0

    def out_dmg(self):
        """この攻撃で相手に与えるダメージ（パワーアイテム込み）"""
        return max(1, int(round(self.atk_dmg * self.pmult())))

    def apply_item(self, kind, foe=None):
        if kind == "heal":
            self.percent = max(0, self.percent - 35)
        elif kind == "power":
            self.power_timer = 600
        elif kind == "speed":
            self.speed_timer = 600
        elif kind == "star":
            self.invincible = max(self.invincible, 300)
        elif kind == "barrier":                   # ダメージ半分 + 重くなる + シールド全回復
            self.barrier_timer = 540
            self.shield = 100.0
            self.cast_timer = 12
        elif kind == "wing":                      # ふわふわ + ジャンプ+2回
            self.wing_timer = 720
            self.jumps += 2
            self.cast_timer = 12
        elif kind == "bomb":                      # 罠：無敵・ガード中は無効。それ以外は爆発！
            if self.invincible > 0 or self.guarding:
                return
            self.gain(12)
            self._hurt(22)
            self.vy = -11.0
            self.vx = random.choice((-1, 1)) * 4.0
            self.cast_timer = 12
        elif kind == "frost":                     # 相手を冷やす
            if foe is not None:
                foe.chill_timer = max(foe.chill_timer, 360)
            self.cast_timer = 12

    # ---------- 状態 ----------
    def acting(self):
        """攻撃・必殺技・回避・崖の途中か"""
        return (self.attack_timer > 0 or self.startup > 0 or self.sp_timer > 0
                or self.charge_timer > 0 or self.hook is not None
                or self.dodge_timer > 0 or self.counter_timer > 0
                or self.ledge is not None or self.climb_left > 0 or self.rm is not None
                or self.focus_timer > 0 or self.tele_wait > 0 or self.chg is not None)

    def busy(self):
        return self.stun > 0 or self.guarding or self.acting()

    def armored(self):
        """攻撃中の「怯まない」状態（スーパーアーマー）"""
        if self.rm is not None and self.rm.get("armor"):
            return True
        return self.atk_armor and (self.attack_timer > 0 or self.startup > 0
                                   or self.sp_timer > 0)

    # ---------- 回避 ----------
    def dodge(self, direction):
        """ガードからの回避。direction = -1/1 でロール、0 でその場回避"""
        if (not self.on_ground or self.stun > 0 or self.dodge_cd > 0 or self.acting()):
            return False
        if self.root_timer > 0 and direction != 0:       # 足がからまっていると、ロールはできない
            return False
        self.dodge_timer = DODGE_FRAMES
        self.dodge_dir = direction
        self.dodge_cd = DODGE_CD
        self.invincible = max(self.invincible, DODGE_FRAMES - 2)
        self.ghost_timer = max(self.ghost_timer, DODGE_FRAMES)
        self.guarding = False
        return True

    # ---------- 崖つかまり ----------
    def release_ledge(self):
        if self.ledge is not None:
            key = self.ledge[0]
            if LEDGE_OWNER.get(key) is self:
                del LEDGE_OWNER[key]
            self.ledge = None
            self.ledge_cd = 45

    def try_grab_ledge(self, inp):
        """空中で、落ちながらステージの端に近づいたら崖につかまる"""
        if (self.vy <= 0 or self.ledge_cd > 0 or self.stun > 0 or self.lock > 0
                or inp.down or self.acting() or self.flight_timer > 0):
            return
        for si, s in enumerate(SOLID):
            for side in (-1, 1):
                key = (si, side)
                owner = LEDGE_OWNER.get(key)
                if owner is not None and owner is not self:
                    continue                      # ほかの人がつかまっている崖は使えない
                if side == -1:                    # ステージの左の端（左側からつかまる）
                    px = s.left
                    ok_x = px - 25 <= self.x + self.w <= px + 8
                else:                             # ステージの右の端
                    px = s.right
                    ok_x = px - 8 <= self.x <= px + 25
                py = s.top
                if ok_x and py - 15 <= self.y <= py + 50:
                    self.grab_ledge(key, side, px, py)
                    return

    def grab_ledge(self, key, side, px, py):
        self.ledge = (key, side, px, py)
        LEDGE_OWNER[key] = self
        self.x = float(px - self.w) if side == -1 else float(px)
        self.y = float(py + 4)
        self.facing = 1 if side == -1 else -1
        self.vx = 0.0
        self.vy = 0.0
        self.on_ground = False
        self.jumps = self.max_jumps()             # つかまると、ジャンプも復帰技も回復
        self.up_ready = True
        self.glide_timer = 0
        self.chute_timer = 0
        self.rm = None
        self.hook_start = None
        self.meteor_timer = 0
        self.hang_age = 0
        self.hang_left = LEDGE_HANG
        self.prev_toward = True                   # ステージ側を押しっぱなしでも、すぐにはのぼらない
        self.ghost_timer = max(self.ghost_timer, 40)
        self.invincible = max(self.invincible, 40)

    def update_ledge(self, inp):
        self.vx = 0.0
        self.vy = 0.0
        self.hang_age += 1
        self.hang_left -= 1
        side = self.ledge[1]
        toward = bool(inp.right) if side == -1 else bool(inp.left)
        away = bool(inp.left) if side == -1 else bool(inp.right)
        pressed_toward = toward and not self.prev_toward
        self.prev_toward = toward
        if self.hang_age > 8:
            if pressed_toward:
                self.ledge_climb()
            elif inp.down or away or self.hang_left <= 0:
                self.ledge_drop()

    def ledge_climb(self, attack=False):
        """崖のぼり（のぼっている間は無敵）。attack=True なら、のぼった後に攻撃"""
        if self.ledge is None:
            return
        key, side, px, py = self.ledge
        self.release_ledge()
        tx = px + 6 if side == -1 else px - 6 - self.w
        self.climb_from = (self.x, self.y)
        self.climb_to = (float(tx), float(py - self.h))
        self.climb_total = 20
        self.climb_left = 20
        self.climb_side = side
        self.climb_attack = attack
        self.ghost_timer = max(self.ghost_timer, 22)
        self.invincible = max(self.invincible, 22)

    def ledge_attack(self):
        self.ledge_climb(attack=True)

    def ledge_jump(self):
        """崖ジャンプ：崖から大きくジャンプする"""
        if self.ledge is None:
            return
        side = self.ledge[1]
        self.release_ledge()
        self.facing = 1 if side == -1 else -1
        self.vy = -self.c["jump"] * 1.1
        self.vx = self.facing * 3.0
        self.jumps = max(0, self.max_jumps() - 1)
        self.on_ground = False

    def ledge_drop(self):
        if self.ledge is None:
            return
        side = self.ledge[1]
        self.release_ledge()
        self.vx = -side * 1.0
        self.vy = 0.0

    def update_climb(self):
        self.vx = 0.0
        self.vy = 0.0
        self.climb_left -= 1
        t = 1.0 - self.climb_left / self.climb_total
        fx, fy = self.climb_from
        tx, ty = self.climb_to
        self.x = fx + (tx - fx) * t
        self.y = fy + (ty - fy) * t
        if self.climb_left <= 0:
            self.x, self.y = tx, ty
            self.land(ty + self.h)
            self.facing = 1 if self.climb_side == -1 else -1
            if self.climb_attack:
                self.cooldown = 0
                self.attack("side")

    # ---------- 行動 ----------
    def jump(self):
        if self.ledge is not None:
            self.ledge_jump()
            return
        if (self.stun > 0 or self.lock > 0 or self.jumps <= 0 or self.charge_timer > 0
                or self.hook is not None or self.climb_left > 0 or self.dodge_timer > 0
                or self.flight_timer > 0 or self.counter_timer > 0 or self.rm is not None
                or self.focus_timer > 0 or self.tele_wait > 0 or self.chg is not None):
            return
        self.vy = -self.c["jump"]
        self.jumps -= 1
        self.on_ground = False

    def attack(self, direction="side", _ratio=None):
        """direction: 'side'(横) / 'up'(上) / 'down'(下)。崖につかまり中は崖のぼり攻撃"""
        if self.ledge is not None:
            self.ledge_attack()
            return
        if self.cooldown > 0 or self.busy():
            return
        c = self.c
        if c.get("smash") and direction in ("side", "up") and _ratio is None:
            self.chg = dict(dir=direction, t=0)      # 溜め攻撃(GRANITE)：ボタンを離すと出る
            self.vx *= 0.3
            return
        if direction == "up":
            m, kind, dm, km = c["up"], "up", 1.0, 1.0
        elif direction == "down":
            if self.on_ground:
                m, kind, dm, km = c["down"], "sweep", 0.8, 0.7   # 地上=足払い
            else:
                m, kind, dm, km = c["down"], "down", 1.0, 1.0    # 空中=メテオ
        else:
            m, kind, dm, km = c["side"], "side", 1.0, 1.0
        self.atk_dir = kind
        self.atk_facing = self.facing
        self.atk_reach = m["reach"]
        self.atk_gap = m["gap"]
        self.atk_tall = m["tall"]
        self.atk_dmg = max(1, int(round(m["dmg"] * dm)))
        self.atk_kb = m["kb"] * km
        self.atk_active = m["active"]
        self.atk_armor = m["armor"]
        self.atk_chill = m["chill"]
        self.atk_burn = m.get("burn", 0)
        self.atk_grab = False
        self.atk_pull = m["pull"]
        self.atk_reflect = m["reflect"]
        self.atk_stun = m["stun"]
        self.atk_flat = m["flat"]
        self.atk_root = m["root"]
        mom = c.get("momentum", 0)
        if mom and abs(self.vx) >= c["run"] * 0.75:      # 勢いボーナス：走りながらだと強い
            self.atk_dmg += mom
            self.atk_kb *= 1.15
        self.atk_crit = False
        rage = c.get("rage", 0)
        if rage:                                          # 自分の%が高いほど強い（RUST）
            self.atk_dmg += int(min(8, self.percent * rage))
            self.atk_kb *= 1.0 + min(0.4, self.percent / 400.0)
        crit = c.get("crit", 0)
        if crit and random.random() < crit:               # 運がよいと、強い一撃
            self.atk_dmg = self.atk_dmg * 3 + 3          # v16.2: 2倍 → 3倍+3
            self.atk_kb *= 2.0                           # v16.2: 1.4倍 → 2倍
            self.atk_crit = True
        self.hits_left = m["hits"]
        self.hit_every = m["every"]
        self.hit_gap = 0
        self.cooldown = m["cd"]
        if c.get("stance"):                               # COBALT：スタンスで攻撃の性質が変わる
            if self.stance == 0:                          # SWIFT：軽くて速い
                self.atk_dmg = max(1, int(round(self.atk_dmg * 0.85)))
                self.atk_kb *= 0.9
                self.cooldown = max(6, int(self.cooldown * 0.6))
            else:                                         # HEAVY：重くて遅い。横/上はアーマーつき
                self.atk_dmg = int(round(self.atk_dmg * 1.55))
                self.atk_kb *= 1.35
                self.cooldown = int(self.cooldown * 1.3)
                if kind in ("side", "up"):
                    self.atk_armor = True
        cb = self.combo if c.get("combo") else 0         # BRONZE：スタック1つにつき、ダメージ+12% / 隙-6%
        if cb:
            self.atk_dmg = max(1, int(round(self.atk_dmg * (1 + 0.12 * cb))))
            self.cooldown = max(5, int(self.cooldown * (1 - 0.06 * cb)))
        if _ratio is not None:                            # 溜めた分だけ強く・ふっとぶ(満タンの近くはアーマーつき)
            sm = c["smash"]
            self.atk_dmg = max(1, int(round(self.atk_dmg * (1 + sm["dmg"] * _ratio))))
            self.atk_kb *= 1 + sm["kb"] * _ratio
            if _ratio >= sm.get("armor_at", 0.8):
                self.atk_armor = True
        if m["lunge"]:
            self.vx += self.facing * m["lunge"]          # 前に踏み込む
        if m["delay"] > 0:
            self.startup = m["delay"]
            self.attack_timer = 0
        else:
            self.startup = 0
            self.attack_timer = m["active"]

    def begin_active(self, kind, frames, dmg, kb, hits=1, every=3, armor=False, reach=55):
        """必殺技の攻撃判定を開始する"""
        self.atk_dir = kind
        self.atk_facing = self.facing
        self.atk_dmg = dmg
        self.atk_kb = kb
        self.atk_reach = reach
        self.atk_armor = armor
        self.atk_chill = 0
        self.atk_burn = 0
        self.atk_grab = False
        self.atk_pull = False
        self.atk_crit = False
        self.atk_reflect = False
        self.atk_stun = 0
        self.atk_flat = False
        self.atk_root = 0
        rage = self.c.get("rage", 0)
        if rage:
            self.atk_dmg += int(min(8, self.percent * rage))
            self.atk_kb *= 1.0 + min(0.4, self.percent / 400.0)
        self.sp_timer = frames
        self.attack_timer = 0
        self.startup = 0
        self.hits_left = hits
        self.hit_every = every
        self.hit_gap = 0

    def special_neutral(self):
        """必殺技：キャラごとに違う（飛び道具 / 罠 / カウンター / 突進）"""
        n = self.neutral_spec()
        if (n["mode"] == "shoot" and n["persist"] and self.mines_out >= 2
                and self.det_cd == 0 and not self.busy()):
            self.detonate = True                          # 地雷が2個出ている → 全部起爆！
            self.det_cd = 20
            self.special_cd = max(self.special_cd, 30)
            self.cast_timer = 12
            return
        if n["mode"] == "orbit" and self.orbs_out > 0 and self.det_cd == 0 and not self.busy():
            self.launch_orbs = True                       # オーブが回っている間にもう一度 → 撃ち出す(COMET)
            self.det_cd = 20
            self.special_cd = min(self.special_cd, 90)
            self.cast_timer = 12
            return
        if self.special_cd > 0 or self.busy():
            return
        f = self.facing
        mode = n["mode"]
        if mode == "rush" and n.get("air_once") and not self.on_ground:
            if self.air_rush_used:                    # 空中では、着地するまで1回だけ
                return
            self.air_rush_used = True
        if mode == "counter":                     # 構えている間に攻撃を受けると、反撃する
            self.counter_timer = n["frames"]
            self.vx *= 0.3
        elif mode == "focus":                     # 瞑想：動かずに集中。最後までいくと%が減る（JADE）
            if not self.on_ground:
                return
            self.focus_timer = int(n["frames"])
            self.vx *= 0.3
        elif mode == "stance":                    # スタンス切替：SWIFT ⇔ HEAVY（COBALT）
            self.stance ^= 1
        elif mode == "portal":                    # ポータル：1回目=入口 / 2回目=出口 / 3回目=全部消す（NEBULA）
            self.portal_req = True
            self.cooldown = max(self.cooldown, 10)
        elif mode == "tele":                      # 相手の背後へ瞬間移動して、斬る（SCARLET）
            tgt = self.tele_target()
            if tgt is None:                       # 行き先がない時は不発(待ち時間も消費しない)
                return
            # v15: すぐには飛ばない。消えている間は無防備で、行き先に赤い枠が出る(=相手は見てかわせる)
            self.tele_wait = int(n.get("windup", 22))
            self.tele_dest = tgt                  # 行き先は撃った瞬間に決まる
            self.vx *= 0.2
            self.cooldown = max(self.cooldown, self.tele_wait + int(n["frames"]) + 30)   # 出現後の隙も長い
        elif mode == "ward":                      # 加護：次に受ける攻撃を1回無効にして弾き返す（PEARL）
            if self.ward > 0:
                return
            self.ward = int(n["frames"])
            self.cooldown = max(self.cooldown, 10)
        elif mode == "orbit":                     # 衛星：3つのオーブが自分のまわりを回る（COMET）
            for i in range(int(n["count"])):
                pr = Projectile(self, self.x + self.w / 2, self.y + self.h / 2, 0.0, 0.0, 22, 22,
                                n["dmg"], n["kb"], int(n["life"]), color=(170, 200, 255),
                                kind="orbit", pierce=True, rehit=int(n["rehit"]))
                pr.phase = i * 6.2832 / n["count"]
                pr.rad = float(n["rad"])
                pr.spin = float(n["spin"])
                self.shots.append(pr)
            self.cooldown = max(self.cooldown, 14)
        elif mode == "finisher":                  # フィニッシャー：スタックを全部使って突進（BRONZE）
            cb = self.combo
            self.rush_v = f * float(n["speed"])
            self.vx = self.rush_v
            self.begin_active("charge", n["frames"], n["dmg"] + n["per_dmg"] * cb,
                              n["kb"] + n["per_kb"] * cb, armor=cb >= 3,
                              reach=n["reach"] + cb * 6)
            self.fin_t = int(n["frames"]) + 4
            self.combo = 0
            self.combo_timer = 0
            self.cooldown = max(self.cooldown, 24)
        elif mode == "grab":                      # つかみ：ガードを貫通。空振りすると隙が大きい
            self.vx *= 0.2
            self.begin_active("charge", n["frames"], n["dmg"], n["kb"], reach=n["reach"])
            self.atk_grab = True
            self.cooldown = max(self.cooldown, 26)
        elif mode == "rush":                      # 前に突進（突進中は攻撃判定つき）
            self.rush_v = f * float(n["speed"])
            self.vx = self.rush_v
            self.begin_active(n.get("hit", "charge"), n["frames"], n["dmg"], n["kb"],
                              hits=n.get("hits", 1), every=n.get("every", 3),
                              armor=n.get("armor", False), reach=n.get("reach", 55))
            if n.get("phase"):                            # すり抜けダッシュ：突進中は無敵
                self.invincible = max(self.invincible, int(n["frames"]))
                self.ghost_timer = max(self.ghost_timer, int(n["frames"]))
        else:
            cx = self.x + self.w / 2 + f * (self.w / 2 + 6)
            cy = self.y + self.h * 0.4
            drop = n.get("drop")
            dirs = (f, -f) if n.get("both") else (f,)
            for sdir, vy in [(d, v) for d in dirs for v in n["spread"]]:
                if n["kind"] in STATIC_KINDS:   # 前方の地面に置いておく「場」/砲台/ばね/間欠泉/わな
                    px = self.x + self.w / 2 + f * n.get("ahead", 130)
                    py = self.y + self.h - n["h"] / 2 - 2
                    if n["kind"] in ("turret", "spring", "geyser", "snare"):   # 置く場所の真下の床に立たせる
                        fl = self.floor_below(px)
                        if fl is not None:
                            py = fl - n["h"] / 2 - 1
                    pvx, pvy = 0.0, 0.0
                elif drop:                                # 前方の上空から真下に落ちる（雷）
                    px, py = self.x + self.w / 2 + f * drop[0], self.y - drop[1]
                    pvx, pvy = 0.0, float(n["speed"])
                else:
                    # 背の高い弾が足元の床にめり込んで、撃った瞬間に消えないように位置を上げる
                    py = min(cy, self.y + self.h - 3 - n["h"] / 2)
                    if n.get("low"):                      # 地面を這う（衝撃波）
                        py = self.y + self.h - n["h"] / 2 - 2
                    px = self.x + self.w / 2 + sdir * (self.w / 2 + 6)
                    pvx, pvy = sdir * n["speed"], vy
                self.shots.append(Projectile(
                    self, px, py, pvx, pvy, n["w"], n["h"], n["dmg"], n["kb"],
                    n["life"], gravity=n["grav"], color=n["color"], kind=n["kind"],
                    fuse=n["fuse"], blast=n["blast"], pierce=n["pierce"], wave=n["wave"],
                    freeze=n["freeze"], persist=n["persist"], arm=n["arm"],
                    boomerang=n.get("boomerang", 0), pull=n.get("pull", False),
                    rehit=n.get("rehit", 0), chill=n.get("chill", 0),
                    swap=n.get("swap", False), burn=n.get("burn", 0),
                    confuse=n.get("confuse", 0),
                    confuse_chance=n.get("confuse_chance", 1.0),
                    accel=n.get("accel", 0.0), ramp=n.get("ramp", 0)))
                self.shots[-1].hex = bool(n.get("hex", False))     # 呪いの弾(RAVEN)
            self.cooldown = max(self.cooldown, 14)
            if n.get("recoil"):                       # 撃った反動で後ろへ下がる
                self.vx -= f * float(n["recoil"])
            if n.get("hop"):                          # バク転：後ろへ跳びながら撃つ(IVORY)
                self.vy = -float(n["hop"]) * (1.0 if self.on_ground else 0.45)
                self.on_ground = False
        self.special_cd = max(n["cd"], 80) if self.c["neutral"]["mode"] == "mimic" else n["cd"]
        self.cast_timer = 12

    def neutral_spec(self):
        """いま使う必殺技のデータ。OPAL は、相手の必殺技(コピーできるもの)をそのまま使う"""
        n = self.c["neutral"]
        if n["mode"] != "mimic":
            return n
        fo = self.foe
        if fo is not None:
            fn = fo.c["neutral"]
            if fn["mode"] in ("shoot", "rush", "counter", "grab", "focus"):
                return fn
        return n["fallback"]                          # コピーできない相手の時は、ふつうの弾

    def arrive_tele(self):
        """シャドウストライク(SCARLET)：消えていた時間が終わって、行き先に現れて斬る"""
        tx, ty, side = self.tele_dest
        self.tele_dest = None
        box = pygame.Rect(int(tx), int(ty), self.w, self.h)
        if any(box.colliderect(o) for o in SOLID):
            return                                    # 行き先がふさがれた：不発
        n = self.c["neutral"]
        self.x, self.y, self.facing = tx, ty, side
        self.vx = self.vy = 0.0
        self.on_ground = False
        self.invincible = max(self.invincible, 3)     # 出現した瞬間だけ短い無敵(10→3フレーム)
        self.ghost_timer = max(self.ghost_timer, 3)
        self.begin_active("charge", int(n["frames"]), n["dmg"], n["kb"], reach=52)
        self.cast_timer = 12

    def support_below(self, px, y):
        """(px, y) の真下 420px 以内に、足場の上面があるか"""
        for s in SOLID + THIN:
            if s.left <= px <= s.right and 0 <= s.top - y <= 420:
                return True
        return False

    def tele_target(self):
        """シャドウストライクの行き先 (x, y, 向き)。使えない時は None"""
        fo = self.foe
        n = self.c["neutral"]
        if fo is None or fo.stocks <= 0 or fo.is_out():
            return None
        cx = self.x + self.w / 2
        if not self.on_ground and (cx < MAIN.left or cx > MAIN.right or self.y + self.h > MAIN.top):
            return None                           # ステージの外では、復帰には使えない
        fcx = fo.x + fo.w / 2
        dx, dy = fcx - cx, (fo.y + fo.h) - (self.y + self.h)
        if abs(dx) > n["range"] or abs(dy) > 220:
            return None
        side = 1 if cx >= fcx else -1             # 自分がいる側。反対側(=背後)へ回り込む
        tx = fcx - side * (fo.w / 2 + self.w / 2 + 8) - self.w / 2
        ty = fo.y + fo.h - self.h
        box = pygame.Rect(int(tx), int(ty), self.w, self.h)
        if any(box.colliderect(o) for o in SOLID):
            return None
        if not self.support_below(tx + self.w / 2, ty + self.h):
            return None
        return (float(tx), float(ty), side)

    def kunai_dest(self, d, rng):
        """クナイジップの行き先：方向 d にまっすぐ進み、固い壁・床にぶつかる手前で止まる"""
        best = (self.x, self.y)
        for i in range(1, int(rng // 8) + 1):
            nx, ny = self.x + d[0] * 8 * i, self.y + d[1] * 8 * i
            box = pygame.Rect(int(nx), int(ny), self.w, self.h)
            if any(box.colliderect(o) for o in SOLID):
                break
            best = (nx, ny)
        return best

    def floor_below(self, px):
        """px の真下にある、いちばん近い足場の上面（足元より下）。なければ None"""
        best = None
        for s in SOLID + THIN:
            if s.left <= px <= s.right and s.top >= self.y + self.h - 4:
                if best is None or s.top < best:
                    best = s.top
        return best

    def hook_target(self):
        """ロープが届くステージの端（届かなければ None）"""
        rng = self.c["up_sp"]["range"]
        best, best_d = None, rng
        for tx, ty in ((MAIN.left + 6, MAIN.top - self.h),
                       (MAIN.right - 6 - self.w, MAIN.top - self.h)):
            d = ((tx - self.x) ** 2 + (ty - self.y) ** 2) ** 0.5
            if d <= best_d:
                best, best_d = (float(tx), float(ty)), d
        return best

    def aim(self, inp, default):
        """方向キーから8方向の向き(単位ベクトル)を作る。何も押していなければ default"""
        dx = int(inp.right) - int(inp.left)
        dy = int(inp.down) - int(inp.up)
        if dx == 0 and dy == 0:
            return default
        n = (dx * dx + dy * dy) ** 0.5
        return (dx / n, dy / n)

    def rift_target(self):
        """ワープ先：いちばん近いステージの端の上（遠すぎれば None）"""
        rng = self.c["up_sp"]["range"]
        best, best_d = None, rng
        for tx, ty in ((MAIN.left + 40, MAIN.top - self.h),
                       (MAIN.right - 40 - self.w, MAIN.top - self.h)):
            d = ((tx - self.x) ** 2 + (ty - self.y) ** 2) ** 0.5
            if d <= best_d:
                best, best_d = (float(tx), float(ty)), d
        return best

    def rewind_target(self):
        """巻き戻し先：最後に立っていた場所（遠くなければ None）"""
        lg = self.last_ground
        if lg is None:
            return None
        if ((lg[0] - self.x) ** 2 + (lg[1] - self.y) ** 2) ** 0.5 < 40:
            return None
        return (float(lg[0]), float(lg[1]))

    def homing_target(self):
        """ホーミング突進の行き先。ステージの上なら相手へ、落ちかけならいちばん近い崖の上へ"""
        cx = self.x + self.w / 2
        safe = MAIN.left < cx < MAIN.right and self.y + self.h <= MAIN.top + 4
        if safe:
            fo = self.foe
            if (fo is not None and MAIN.left < fo.x + fo.w / 2 < MAIN.right
                    and fo.y + fo.h <= MAIN.top + 30):
                return (fo.x + fo.w / 2 - self.w / 2, fo.y + fo.h / 2 - self.h / 2)
            return (self.x + self.facing * 150, self.y - 30)
        best, best_d = None, 1e18
        # 崖の「外側の斜め上」を狙う（角を狙うと、ステージの裏側にぶつかって止まるため）
        cands = []
        for blk in SOLID:                          # 壁や島も含め、固い足場すべての外側
            cands.append((blk.left - self.w - 12, blk.top - self.h - 14))
            cands.append((blk.right + 12, blk.top - self.h - 14))
        for tx, ty in cands:
            box = pygame.Rect(int(tx), int(ty), self.w, self.h)
            if any(box.colliderect(o) for o in SOLID):          # 他のブロックに埋まる点は除外
                continue
            d = (tx - self.x) ** 2 + (ty - self.y) ** 2
            if d < best_d:
                best, best_d = (float(tx), float(ty)), d
        if best is None:
            best = (float(MAIN.left + 40), float(MAIN.top - self.h))
        return best

    def reel_target(self):
        """グラップルリールの行き先。ステージの外なら崖の外側、届かなければ近くの相手。なければ None"""
        rng = float(self.c["up_sp"]["range"])
        cx = self.x + self.w / 2
        safe = MAIN.left < cx < MAIN.right and self.y + self.h <= MAIN.top + 4
        if not safe:
            t = self.homing_target()
            if t is not None and ((t[0] - self.x) ** 2 + (t[1] - self.y) ** 2) ** 0.5 <= rng:
                return t
        fo = self.foe
        if fo is not None:
            d = ((fo.x - self.x) ** 2 + (fo.y - self.y) ** 2) ** 0.5
            if d <= rng and fo.y + fo.h <= MAIN.top + 40:     # 場外に落ちた相手には飛ばない
                return (fo.x, fo.y)
        return None

    def special_up(self, inp):
        """上必殺技：復帰技（空中で1回だけ。着地か崖つかまりで回復）。キャラごとに全部ちがう"""
        if self.rm is not None and self.rm.get("k") == "cannon" and self.rm.get("ph") == "aim":
            self.rm["t"] = 1                  # スラッガースイング：狙っている間にもう一度押すと、その角度で発射
            return
        if (not self.up_ready or self.stun > 0 or self.guarding or self.lock > 0
                or self.sp_timer > 0 or self.charge_timer > 0 or self.hook is not None
                or self.ledge is not None or self.climb_left > 0 or self.dodge_timer > 0
                or self.counter_timer > 0 or self.rm is not None or self.focus_timer > 0
                or self.tele_wait > 0 or self.chg is not None):
            return
        u = self.c["up_sp"]
        k = u["kind"]
        dirx = int(inp.right) - int(inp.left)

        if k in ("hook", "swing"):       # 崖にロープ/ムチ（届く時だけ発動）
            target = self.hook_target()
            if target is None or self.on_ground:
                return
        if k in ("rift", "gate"):         # 近くに崖がある時だけ発動
            target = self.rift_target()
            if target is None:
                return
        if k == "rewind":                # 戻る場所がある時だけ発動
            target = self.rewind_target()
            if target is None:
                return
        if k == "reel":                  # ロープが届く時だけ発動
            target = self.reel_target()
            if target is None:
                return
        if k in ("plat", "stairs", "stalk") and self.plat_cd > 0:
            return
        # --- ここから発動確定。出ている通常攻撃はキャンセル ---
        self.attack_timer = 0
        self.startup = 0
        self.hits_left = 0
        self.atk_armor = False

        if k == "rise":                  # 上昇パンチ（真上に強い・攻撃判定つき）
            self.vy = -float(u["vy"])
            self.vx += self.facing * 2
            self.begin_active("rise", u["frames"], u["dmg"], u["kb"])
            if u.get("iframes"):         # 出だしは無敵（昇龍拳みたいに）
                self.invincible = max(self.invincible, u["iframes"])
                self.ghost_timer = max(self.ghost_timer, u["iframes"])
        elif k == "spin":                # 回転しながら上昇（多段/アーマーをデータで指定）
            self.vy = -float(u["vy"])
            self.begin_active("spin", u["frames"], u["dmg"], u["kb"],
                              hits=u["hits"], every=u["every"], armor=u["armor"])
        elif k == "dash":                # ほぼ真横に長く飛ぶ。ダッシュ中は無敵
            if dirx:
                self.facing = dirx
                self.vx = dirx * float(u["vx"])
                self.vy = -float(u["vy"])
            else:
                self.vx = 0.0
                self.vy = -float(u["vyup"])
            self.invincible = max(self.invincible, u["iframes"])
            self.ghost_timer = max(self.ghost_timer, u["iframes"])
        elif k == "boost":               # ふわっと上昇して滑空
            self.vy = -float(u["vy"])
            self.vx = dirx * float(u["vx"])
            self.glide_timer = u["glide"]
        elif k == "warp":                # ワープ（短い無敵つき）
            dist = u["dist"]
            if dirx:
                self.facing = dirx
                self.x += dirx * dist
                self.y -= dist * 0.35
            else:
                self.y -= dist
            self.vx = 0.0
            self.vy = 0.0
            self.invincible = max(self.invincible, 20)
            self.ghost_timer = max(self.ghost_timer, 20)
            for s in SOLID:
                if self.overlaps(s):
                    self.y = s.top - self.h   # ステージにめり込んだら上に乗る
        elif k == "charge":              # 斜め前に突進（前に攻撃判定つき）
            d = dirx or self.facing
            self.facing = d
            self.vx = d * float(u["vx"])
            self.vy = -float(u["vy"])
            self.begin_active("charge", u["frames"], u["dmg"], u["kb"], reach=u["reach"])
        elif k == "chute":               # パラシュートでゆっくり降りながら横に移動
            self.vy = -float(u["vy"])
            self.vx = dirx * 3.0
            self.chute_timer = u["glide"]
        elif k == "rocket":              # 一瞬止まって溜めてから、高く打ち上がる
            self.charge_timer = u["charge"]
            self.vx *= 0.3
            self.vy = 0.0
        elif k == "hook":
            self.hook = target
            self.hook_start = None
            self.vx = 0.0
            self.vy = 0.0
        elif k == "swing":               # ムチを崖にかけて、弧を描いて飛び移る
            self.hook = target
            self.hook_start = (self.x, self.y)
            self.hook_t = 0.0
            self.vx = 0.0
            self.vy = 0.0
        elif k == "quick":               # 8方向ダッシュを2連続（2回目は向きを変えられる）
            d = self.aim(inp, (0.0, -1.0))
            if d[0]:
                self.facing = 1 if d[0] > 0 else -1
            self.rm = dict(k="quick", ph="go", n=1, t=u["seg"], d=d)
            self.invincible = max(self.invincible, 3)
        elif k == "launch":              # 溜めながら方向キーで狙い、離すと突進（溜め中もアーマー）
            self.rm = dict(k="launch", ph="charge", t=u["charge"], armor=True,
                           d=(self.facing * 0.7071, -0.7071))
            self.vx *= 0.3
            self.vy = 0.0
        elif k == "vault":               # 走ってきた勢いがそのまま高さと距離になる
            d = dirx or self.facing
            self.facing = d
            sp = abs(self.vx)
            self.vy = -(float(u["vy"]) + sp * float(u["k"]))
            self.vx = d * max(sp * 1.25, 6.0)
            self.begin_active("charge", u["frames"], u["dmg"], u["kb"], reach=u["reach"])
        elif k == "stairs":              # 氷の階段を3段（着地するとジャンプが回復 → 跳んで登る）
            d = dirx or self.facing
            fx = self.x + self.w / 2
            fy = self.y + self.h
            for n in range(3):
                rect = pygame.Rect(int(fx + d * (n * 80 + 20) - 40), int(fy + 14 - n * 60), 80, 12)
                THIN.append(rect)
                TEMPS.append([rect, u["life"] + n * 10])
            self.plat_cd = u["cd"]
            self.vy = -float(u["vy"])
            self.vx *= 0.5
        elif k == "copter":              # プロペラ：ゆっくり上昇しつつ横に動け、回転で多段ヒット
            self.rm = dict(k="copter", t=u["frames"])
            self.vy = -float(u["rise"])
            self.begin_active("spin", u["frames"], u["dmg"], u["kb"],
                              hits=u["hits"], every=u["every"])
        elif k == "rift":                # 少し溜めてから、近い崖の上へワープ（溜め中は無防備）
            self.rm = dict(k="rift", t=u["delay"], tgt=target)
            self.vx = 0.0
            self.vy = 0.0
        elif k == "gamble":              # ギャンブル：運しだいで高さが変わる
            d = dirx or self.facing
            self.facing = d
            r = random.random()
            if r < 0.12:                 # ジャックポット！ 超高く飛んで、攻撃判定もつく
                self.vy = -float(u["big"]) * 1.15
                self.vx = d * 2.0
                self.begin_active("rise", 16, u["dmg"], u["kb"])
                self.invincible = max(self.invincible, 12)
                self.ghost_timer = max(self.ghost_timer, 12)
            elif r < 0.50:               # 大成功
                self.vy = -float(u["big"])
                self.vx = d * 2.0
            elif r < 0.85:               # まあまあ：斜めに飛ぶ
                self.vy = -float(u["mid"])
                self.vx = d * float(u["side"])
            else:                        # ハズレ…ちょっとだけ
                self.vy = -float(u["small"])
                self.vx = d * 3.0
        elif k == "balloon":             # 風船でゆっくり上昇 → 最後に破裂して攻撃
            self.rm = dict(k="balloon", t=u["frames"])
            self.vy = -float(u["rise"])
        elif k == "phoenix":             # フェニックス：炎をまとって斜め上へ → 最後に爆発
            d = dirx or self.facing
            self.facing = d
            self.rm = dict(k="phoenix", t=int(u["frames"]), dx=d)
            self.vx = d * float(u["vx"])
            self.vy = -float(u["vy"])
            self.begin_active("rise", u["frames"], u["dmg"], u["kb"])
        elif k == "pillar":              # 石柱：アーマーつきで上昇し、最後に足場として残る
            self.rm = dict(k="pillar", t=int(u["frames"]), armor=True)
            self.vx *= 0.3
            self.vy = -float(u["rise"])
            self.begin_active("spin", u["frames"], u["dmg"], u["kb"], hits=1, every=3, armor=True)
        elif k == "airstep":             # スカイステップ：短い8方向ダッシュ（空中で何回か使える）
            d = self.aim(inp, (self.facing * 0.7, -0.7))
            if d[0]:
                self.facing = 1 if d[0] > 0 else -1
            self.rm = dict(k="airstep", t=int(u["seg"]), d=d)
            self.invincible = max(self.invincible, 3)
            self.air_steps += 1
        elif k == "pogo":                # ジャックホップ：何度かはねながら上昇
            self.rm = dict(k="pogo", t=int(u["frames"]))
            self.vy = -float(u["hop"])
        elif k == "reel":                # リール：ロープで目標の所まで一直線
            self.facing = 1 if target[0] >= self.x else -1
            self.rm = dict(k="homing", t=int(u["frames"]), tgt=target, armor=True,
                           rope=(target[0] + self.w / 2, target[1] + self.h / 2))
            self.invincible = max(self.invincible, 4)
        elif k == "springhop":           # 空中にばねを出して、はねて戻る
            pad = Projectile(self, self.x + self.w / 2, self.y + self.h + 36, 0.0, 0.0, 60, 14,
                             0, 0.0, int(u["life"]), color=(255, 205, 70), kind="spring")
            pad.max_uses = 2
            pad.launch_atk = True                    # はね上がった時、持ち主は蹴り上げの攻撃判定を得る
            self.shots.append(pad)
            self.vy = max(self.vy, 2.0)
            self.vx *= 0.6
        elif k == "bubble":              # 泡：無敵のままゆっくり浮かぶ（攻撃はできない）
            self.rm = dict(k="bubble", t=u["frames"])
            self.vy = -float(u["rise"])
            self.invincible = max(self.invincible, int(u["frames"]))
        elif k == "jet":                 # ジェットパック：下向きの炎で攻撃しながら上昇（横にも動ける）
            self.rm = dict(k="jet", t=u["frames"])
            self.vy = -float(u["rise"])
            self.begin_active("blast", u["frames"], u["dmg"], u["kb"],
                              hits=u["hits"], every=u["every"])
        elif k == "blink":               # ブリンク：斜め上 / 真上へ一瞬で移動（短い無敵つき）
            dist = float(u["dist"])
            if dirx:
                self.facing = dirx
                self.x += dirx * dist * 0.866
                self.y -= dist * 0.5
            else:
                self.y -= dist
            self.vx = 0.0
            self.vy = 0.0
            self.glide_timer = u["glide"]
            self.invincible = max(self.invincible, 14)
            self.ghost_timer = max(self.ghost_timer, 14)
            for s in SOLID:
                if self.overlaps(s):
                    self.y = s.top - self.h
        elif k == "rewind":              # 巻き戻し：少し溜めてから、最後に立っていた場所へ戻る
            self.rm = dict(k="rift", t=u["delay"], tgt=target)
            self.vx = 0.0
            self.vy = 0.0
        elif k == "homing":              # ホーミング突進：ステージ上なら相手へ、落ちかけなら崖へ
            tgt = self.homing_target()
            self.facing = 1 if tgt[0] >= self.x else -1
            self.rm = dict(k="homing", t=u["frames"], tgt=tgt, armor=True)
            self.begin_active("charge", u["frames"], u["dmg"], u["kb"], armor=True, reach=60)
            self.invincible = max(self.invincible, 4)
        elif k == "flight":              # しばらく、上下左右に自由に飛べる
            self.flight_timer = u["frames"]
            self.vy = -3.0
        elif k == "wings":               # ジャンプ回数が増える（その場でもう一回跳ぶ）
            self.jumps += u["jumps"]
            self.vy = -float(u["vy"])
            self.vx = dirx * float(u["vx"])
        elif k == "cannon":              # スラッガースイング：角度が往復する → もう一度押すと発射
            d = dirx or self.facing
            self.facing = d
            self.rm = dict(k="cannon", ph="aim", t=int(u["aim"]), dx=d, a=-1.5708)
            self.vx = self.vy = 0.0
        elif k == "spiral":              # ワールアセント：らせんを描いて上昇
            self.rm = dict(k="spiral", t=int(u["frames"]))
            self.vy = -float(u["rise"])
            self.begin_active("spin", int(u["frames"]), u["dmg"], u["kb"],
                              hits=u["hits"], every=u["every"])
        elif k == "surf":                # タイダルサーフ：少し浮いて → 波に乗って横へ長く
            d = dirx or self.facing
            self.facing = d
            self.rm = dict(k="surf", ph="up", t=int(u["rise_t"]), dx=d)
            self.vx = d * float(u["rise_vx"])
            self.vy = -float(u["rise_vy"])
        elif k == "kunai":               # クナイジップ：方向を決めて投げ、壁や足場の手前まで瞬間移動
            d = self.aim(inp, (self.facing * 0.7071, -0.7071))
            if d[0]:
                self.facing = 1 if d[0] > 0 else -1
            dest = self.kunai_dest(d, float(u["range"]))
            self.rm = dict(k="rift", t=int(u["delay"]), tgt=dest, line=True)
            self.vx = self.vy = 0.0
            self.invincible = max(self.invincible, int(u["delay"]) + 4)
        elif k == "stalk":               # ビーンスターク：真上に豆の木の足場を何段かのばす
            fx = self.x + self.w / 2
            fy = self.y + self.h
            for i in range(int(u["n"])):
                rect = pygame.Rect(int(fx - 35), int(fy + 14 - i * int(u["step"])), 70, 12)
                THIN.append(rect)
                TEMPS.append([rect, int(u["life"]) + i * 10])
            self.plat_cd = u["cd"]
            self.vy = -float(u["vy"])
            self.vx *= 0.5
        elif k == "echo":                # OPAL: 少しあとに、もう一度ふき上がる(2回目は向きを選べる)
            self.rm = dict(k="echo", t=int(u["gap"]), n=1)
            self.vy = -float(u["vy"])
            self.vx += dirx * 3.0
        elif k == "valk":               # スカイランス(IVORY)：真上へ突き上げ → 横へ槍で突っ込む
            d = dirx or self.facing
            self.facing = d
            self.rm = dict(k="valk", ph=0, t=int(u["rise_t"]), dx=d)
            self.vx = 0.0
            self.vy = -float(u["rise_vy"])
            self.begin_active("rise", int(u["rise_t"]), u["rise_dmg"], u["rise_kb"])
        elif k == "twin":                # スタンスライズ：SWIFT=無敵ダッシュ / HEAVY=アーマー上昇パンチ
            if self.stance == 0:
                d = self.aim(inp, (self.facing * 0.7, -0.7))
                if d[0]:
                    self.facing = 1 if d[0] > 0 else -1
                self.rm = dict(k="airstep", t=int(u["seg"]), d=d)
                self.invincible = max(self.invincible, 3)
            else:
                self.vy = -float(u["vy"])
                self.vx += self.facing * 2
                self.begin_active("rise", int(u["frames"]), u["dmg"], u["kb"], armor=True)
        elif k == "phase":               # ステージを通り抜けながら上昇する（RAVEN）
            self.rm = dict(k="phase", t=int(u["frames"]))
            self.vy = -float(u["rise"])
            self.vx = dirx * float(u["side"])
            self.invincible = max(self.invincible, int(u["frames"]))
            self.ghost_timer = max(self.ghost_timer, int(u["frames"]))
        elif k == "gate":                # 出入口のポータルを開いて、近くの崖へ（ポータルは残る）（NEBULA）
            self.rm = dict(k="gate", t=int(u["delay"]), tgt=target)
            self.gate_req = (self.x + self.w / 2, self.y + self.h / 2,
                             target[0] + self.w / 2, target[1] + self.h / 2)
            self.portal_cd = int(u["delay"]) + PORTAL_CD
            self.vx = 0.0
            self.vy = 0.0
        elif k == "chargejump":          # ボタンを押している間ためる → 離すと跳ぶ（GRANITE）
            self.rm = dict(k="chargejump", t=0)
            self.vx *= 0.3
            self.vy = 0.0
        elif k == "plat":                # 足元に一時的な足場を作る（相手も乗れる）
            rect = pygame.Rect(int(self.x + self.w / 2 - 70), int(self.y + self.h + 10), 140, 12)
            THIN.append(rect)
            TEMPS.append([rect, u["life"]])
            self.plat_cd = u["cd"]
            self.vy = 0.0
            self.vx *= 0.5

        self.up_ready = False
        if k == "airstep" and self.air_steps < int(u["steps"]):
            self.up_ready = True         # スカイステップは、回数が残っている間は何度でも使える
        self.on_ground = False
        self.cast_timer = 12

    # ---------- 当たり判定 ----------
    def hitbox(self, preview=False):
        """攻撃判定。preview=True なら、溜め中の「これから出る判定」も返す"""
        x, y, w, h = int(self.x), int(self.y), self.w, self.h
        if self.sp_timer > 0:
            d = self.atk_dir
            if d == "rise":
                return pygame.Rect(x - 8, y - 50, w + 16, 50 + int(h * 0.6))
            if d == "spin":
                return pygame.Rect(x - 40, y, w + 80, h)
            if d == "charge":
                reach = self.atk_reach
                bx = x + w if self.atk_facing > 0 else x - reach
                return pygame.Rect(bx, y + int(h * 0.1), reach, int(h * 0.8))
            if d == "blast":
                return pygame.Rect(x - 45, y + h - 40, w + 90, 80)
            return None
        if self.attack_timer <= 0 and not (preview and self.startup > 0):
            return None
        reach, gap, d = self.atk_reach, self.atk_gap, self.atk_dir
        if d == "up":
            return pygame.Rect(x - 8, y - reach - gap, w + 16, reach + 12)
        if d == "down":
            return pygame.Rect(x - 6, y + h - 12 + gap, w + 12, reach)
        if d == "sweep":
            side = int(reach * 0.75)
            return pygame.Rect(x - side, y + h - 26, w + 2 * side, 26)
        tall = self.atk_tall or int(h * 0.65)
        by = y + h // 2 - tall // 2
        bx = x + w + gap if self.atk_facing > 0 else x - gap - reach
        return pygame.Rect(bx, by, reach, tall)

    def _hurt(self, stun):
        self.combo = 0                           # 攻撃を受けたらコンボスタックは全部消える(BRONZE)
        self.combo_timer = 0
        self.chg = None                          # 溜め攻撃は、攻撃を受けると中断(GRANITE)
        self.release_ledge()
        self.stun = stun
        self.on_ground = False
        self.startup = 0
        self.attack_timer = 0
        self.sp_timer = 0
        self.charge_timer = 0
        self.hook = None
        self.hook_start = None
        self.rm = None
        self.hits_left = 0
        self.atk_armor = False
        self.glide_timer = 0
        self.chute_timer = 0
        self.flight_timer = 0
        self.counter_timer = 0
        self.dodge_timer = 0
        self.climb_left = 0
        self.rush_v = 0.0
        self.meteor_timer = 0
        self.lock = 0
        self.focus_timer = 0
        self.tele_wait = 0                       # 消えている途中で攻撃を受けると、ストライクは中断
        self.tele_dest = None
        self.guarding = False

    def take_light_hit(self, atk):
        """多段攻撃の途中のヒット（軽く怯むだけで、その場に留まる）"""
        self.gain(atk.out_dmg())
        if self.armored():
            return
        d = atk.atk_dir
        self.vx = atk.atk_facing * 1.2
        self.vy = -4.0 if d == "up" else -1.0
        if d == "spin":
            self.vx = (1 if self.rect.centerx >= atk.rect.centerx else -1) * 1.0
            self.vy = -2.0
        self._hurt(8)

    def take_hit(self, atk):
        d = atk.atk_dir
        self.gain(atk.out_dmg())
        if self.armored():                       # アーマー中は怯まない
            return
        # %が高いほど、攻撃側が強いほど、自分が軽いほど遠くへ飛ぶ
        base = ((5 + self.percent * 0.12) * atk.atk_kb * (1.15 if atk.power_timer > 0 else 1.0)
                / self.eff_weight())
        f = atk.atk_facing
        away = 1 if self.rect.centerx >= atk.rect.centerx else -1
        meteor = False
        if d == "up":
            self.vx = f * base * 0.25
            self.vy = -(5 + base * 0.85)
        elif d == "down":
            if self.on_ground:                    # 地上の相手は軽く浮くだけ
                self.vx = f * base * 0.3
                self.vy = -(4 + self.percent * 0.03)
            else:                                 # 空中の相手は…メテオ！
                self.vx = f * base * 0.15
                self.vy = 10 + base * 1.2
                meteor = True
        elif d == "sweep":
            self.vx = away * base * 0.7
            self.vy = -(3 + self.percent * 0.03)
        elif d == "rise":
            self.vx = f * base * 0.3
            self.vy = -(6 + base * 0.95)
        elif d == "spin":
            self.vx = away * base * 0.9
            self.vy = -(4 + self.percent * 0.04)
        elif d == "blast":
            self.vx = away * base * 0.7
            self.vy = -(6 + base * 0.8)
        elif atk.atk_pull and d == "side":        # 引き寄せ：相手を自分の方へ
            self.vx = -f * base * 0.4
            self.vy = -(3 + self.percent * 0.03)
        else:                                     # side / charge
            self.vx = f * base
            self.vy = -(4 + self.percent * 0.05)
            if atk.atk_flat and d == "side":      # 真横に強く押す（AZURE）
                self.vx = f * base * 1.3
                self.vy = -1.0

        if meteor:
            stun = min(60, 34 + int(self.percent * 0.12))
            self._hurt(stun)
            self.meteor_timer = stun + 12        # 急降下する
            self.lock = stun + 25                # 気絶が終わってもしばらくジャンプ不可
        else:
            bonus = 0
            if atk.atk_stun:                      # 硬直が長い攻撃(JADE)：続けて当たるほど、のびが減る
                bonus = max(0, atk.atk_stun - JADE_DECAY * self.stun_chain)
                self.stun_chain += 1
                self.chain_timer = 50
            self._hurt(14 + bonus)
            if atk.atk_stun and self.stun_chain >= 3:
                self.invincible = max(self.invincible, 20)    # 3発目以降：コンボから抜けられる

    def take_geyser(self, p):
        """間欠泉に当たった：真上へ高く打ち上げられる"""
        self.gain(p.damage * p.owner.pmult())
        if self.armored():
            return
        base = (3 + self.percent * 0.09) * p.power / self.eff_weight()
        self.vx = 0.0
        self.vy = -(8 + base)
        self._hurt(16)

    def take_proj(self, p, direction, explosion=False):
        self.gain(p.damage * p.owner.pmult())
        if self.armored():
            return
        if p.freeze:                             # 凍る：確率で。吹っ飛ばずに、しばらく動けない
            chance = 0.55 if self.chill_timer > 0 else 0.35      # 冷えていると凍りやすい
            if random.random() < chance:
                if self.on_ground:
                    dur = 60 if self.chill_timer > 0 else 42     # 冷えているともっと長く凍る
                else:
                    dur = 18                                     # 空中では一瞬だけ
                self._hurt(dur)
                self.freeze_timer = dur
                self.vx = 0.0
                self.vy = 0.0
                return
            # 凍らなかった時は、ふつうの飛び道具として当たる(冷えだけは別に付く)
        base = (3 + self.percent * 0.09) * p.power / self.eff_weight()
        if p.pull:                               # 引き寄せ：撃った人の方へ引っ張る
            self.vx = -direction * base
            self.vy = -2.0
            self._hurt(6 if p.rehit else 10)     # 当たり直す弾は硬直を短く（抜け出せる）
            return
        if explosion:                            # 爆発は中心から外へ、上向きに吹き飛ばす
            self.vx = direction * base * 0.8
            self.vy = -(6 + base * 0.7)
        else:
            self.vx = direction * base
            self.vy = -(3 + self.percent * 0.03)
        self._hurt(6 if p.rehit else 10)          # 風のように当たり直す弾は、硬直が短い

    def take_bolt(self, x):
        """落雷に当たった（無敵なら当たらない。ガードで防げる）"""
        if self.invincible > 0:
            return
        if self.guarding:
            self.block(8, x)
            return
        self.gain(8)
        if self.armored():
            return
        self._hurt(18)
        self.vy = -(8.0 + self.percent * 0.04)
        self.vx = (1 if self.rect.centerx >= x else -1) * 3.0

    def block(self, dmg, from_x):
        """ガードで防ぐ。シールドが削れて、0になるとガードブレイク"""
        self.shield -= (dmg * 2.5 + 2) * self.c.get("guard_taken", 1.0)
        d = 1 if self.rect.centerx >= from_x else -1
        self.vx += d * 2.5
        if self.shield <= 0:
            self.shield = 35.0
            self._hurt(100)                      # ガードブレイク！しばらく動けない
            self.vy = -5.0

    def do_counter(self, atk):
        """カウンター成功：攻撃を無効にして、相手を強く吹き飛ばす"""
        atk.percent += max(6, int(atk.out_dmg() * 1.2) + 4)
        d = 1 if atk.rect.centerx >= self.rect.centerx else -1
        base = (6 + atk.percent * 0.12) / atk.c["weight"]
        atk.vx = d * base * 1.1
        atk.vy = -(5 + atk.percent * 0.04)
        atk._hurt(18)
        self.counter_timer = 0
        self.cast_timer = 12
        self.invincible = max(self.invincible, 8)

    def hex_boom(self):
        """呪いが時間切れで爆発：ガードできない。真上へ強く打ち上げられる（RAVEN）"""
        src = self.hex_by
        self.hex_by = None
        if src is None:
            return
        hx = src.c.get("hex") or HEX_DEFAULT
        self.hex_pop = 18
        self.gain(hx["dmg"] * src.pmult())
        if self.armored():
            return
        d = 1 if self.rect.centerx >= src.rect.centerx else -1
        base = (3 + self.percent * 0.09) * hx["kb"] / self.eff_weight()
        self.vx = d * base * 0.6
        self.vy = -(7 + base * 0.8)
        self._hurt(18)

    def unstick(self):
        """壁やステージにめり込んでいたら、そのブロックの上へ出す（ゴーストライズの終わり）"""
        for _ in range(8):
            hit = next((b for b in SOLID if self.overlaps(b)), None)
            if hit is None:
                return
            self.y = float(hit.top - self.h)

    # ---------- 毎フレームの処理 ----------
    def _tick(self):
        if self.hex_timer > 0:                   # 呪いのカウントダウン（RAVEN）
            self.hex_timer -= 1
            if self.hex_timer == 0:
                self.hex_boom()
        if self.hex_pop > 0:
            self.hex_pop -= 1
        if self.startup > 0:                     # 溜めが終わったら攻撃判定が出る
            self.startup -= 1
            if self.startup == 0:
                self.attack_timer = self.atk_active
        was_dodging = self.dodge_timer > 0
        for name in ("attack_timer", "cooldown", "invincible", "sp_timer", "special_cd",
                     "glide_timer", "chute_timer", "flight_timer", "counter_timer",
                     "plat_cd", "cast_timer", "meteor_timer", "lock", "hit_gap",
                     "power_timer", "speed_timer", "dodge_timer", "dodge_cd",
                     "ghost_timer", "freeze_timer", "ledge_cd", "chill_timer", "det_cd",
                     "barrier_timer", "wing_timer", "burn_timer", "confuse_timer",
                     "root_timer", "chain_timer", "portal_cd"):
            v = getattr(self, name)
            if v > 0:
                setattr(self, name, v - 1)
        if self.chain_timer == 0 and self.stun_chain:
            self.stun_chain = 0                       # JADE のコンボ数えをリセット
        if self.burn_timer > 0 and self.burn_timer % 40 == 0 and self.invincible == 0:
            self.gain(1)                              # 燃焼ダメージ
        if was_dodging and self.dodge_timer == 0:
            self.vx *= 0.3
        if self.sp_timer == 0:
            self.rush_v = 0.0

    def update_rm(self, inp):
        """復帰技の特殊な動きを1フレーム進める。戻り値: 'hold' / 'free' / None"""
        rm = self.rm
        if rm is None:
            return None
        u = self.c["up_sp"]
        k = rm["k"]
        if k == "phoenix":                            # 斜め上へ一直線 → 最後に爆発して少し押し上がる
            self.vx = rm["dx"] * float(u["vx"])
            self.vy = -float(u["vy"])
            rm["t"] -= 1
            if rm["t"] <= 0:
                self.rm = None
                self.vx = rm["dx"] * 2.0
                self.vy = -float(u["pop"])
                self.begin_active("blast", 10, u["burst_dmg"], u["burst_kb"])
                self.glide_timer = u.get("glide", 0)
                return None
            return "hold"
        if k == "pillar":                             # 石柱で上昇 → 終わると足の下に足場が残る
            self.vy += (-float(u["rise"]) - self.vy) * 0.4
            rm["t"] -= 1
            if rm["t"] <= 0:
                rect = pygame.Rect(int(self.x + self.w / 2 - 60), int(self.y + self.h + 2), 120, 14)
                THIN.append(rect)
                NOREFRESH.append(rect)
                TEMPS.append([rect, int(u["life"])])
                self.rm = None
                self.vy = 0.0
                return None
            return "free"
        if k == "cannon":                             # スラッガースイング
            if rm["ph"] == "aim":                     # 狙っている間：角度が往復。バットは飛び道具を打ち返す
                self.vx = self.vy = 0.0
                rm["a"] += 0.30
                rm["t"] -= 1
                self.facing = rm["dx"]
                self.atk_dir = "side"
                self.atk_facing = rm["dx"]
                self.atk_reach = 60
                self.atk_gap = 0
                self.atk_tall = 84
                self.atk_reflect = True
                self.atk_armor = False
                self.hits_left = 0
                self.attack_timer = 2
                if rm["t"] <= 0:
                    th = math.radians(20 + 55 * (0.5 + 0.5 * math.sin(rm["a"])))
                    sp = float(u["speed"])
                    rm["v"] = (rm["dx"] * math.cos(th) * sp, -math.sin(th) * sp)
                    rm.update(ph="go", t=int(u["frames"]))
                    self.begin_active("charge", int(u["frames"]), u["dmg"], u["kb"], reach=60)
                return "hold"
            self.vx, self.vy = rm["v"]
            rm["t"] -= 1
            if rm["t"] <= 0:
                self.rm = None
                self.vx *= 0.3
                self.vy *= 0.3
                return None
            return "hold"
        if k == "spiral":                             # らせん上昇：横に円を描きながら昇る
            rm["t"] -= 1
            ph = (int(u["frames"]) - rm["t"]) * 0.42
            self.vx = float(u["rad"]) * math.cos(ph)
            self.vy += (-float(u["rise"]) - self.vy) * 0.35
            if rm["t"] <= 0:
                self.rm = None
                self.vx *= 0.3
                self.glide_timer = u.get("glide", 0)
                return None
            return "free"
        if k == "surf":                               # 波乗り：浮く → 横へ長く進む
            if rm["ph"] == "up":
                self.vx = rm["dx"] * float(u["rise_vx"])
                self.vy = -float(u["rise_vy"])
                rm["t"] -= 1
                if rm["t"] <= 0:
                    rm.update(ph="ride", t=int(u["glide_t"]))
                    self.begin_active("charge", int(u["glide_t"]), u["dmg"], u["kb"], reach=54)
            else:
                self.vx = rm["dx"] * float(u["glide_vx"])
                self.vy = -float(u["glide_vy"])
                rm["t"] -= 1
                if rm["t"] <= 0:
                    self.rm = None
                    self.vx *= 0.5
                    self.vy = 0.0
                    self.glide_timer = 20
                    return None
            return "hold"
        if k == "airstep":                            # 短いダッシュ（無敵）
            sp = float(u["speed"])
            self.vx, self.vy = rm["d"][0] * sp, rm["d"][1] * sp
            self.invincible = max(self.invincible, 2)
            self.ghost_timer = max(self.ghost_timer, 2)
            rm["t"] -= 1
            if rm["t"] <= 0:
                self.rm = None
                self.vx *= 0.35
                self.vy *= 0.35
                return None
            return "hold"
        if k == "pogo":                               # 一定間隔ではねる（重力は自前で）
            self.vy += self.c["gravity"] * STAGE_GRAV
            rm["t"] -= 1
            if rm["t"] <= 0:
                self.rm = None
                self.glide_timer = u.get("glide", 0)
                return None
            if rm["t"] % int(u["every"]) == 0:
                self.vy = -float(u["hop"])
            return "free"
        if k == "quick":                              # 8方向ダッシュ → 一瞬止まる → 向きを変えてもう一度
            self.invincible = max(self.invincible, 2)
            self.ghost_timer = max(self.ghost_timer, 2)
            if rm["ph"] == "go":
                sp = float(u["speed"])
                self.vx, self.vy = rm["d"][0] * sp, rm["d"][1] * sp
                rm["t"] -= 1
                if rm["t"] <= 0:
                    if rm["n"] == 1:
                        rm["ph"] = "wait"
                        rm["t"] = u["wait"]
                        self.vx = self.vy = 0.0
                    else:
                        self.rm = None
                        self.vx *= 0.4
                        self.vy *= 0.4
                        return None
            else:
                self.vx = self.vy = 0.0
                rm["t"] -= 1
                if rm["t"] <= 0:
                    d = self.aim(inp, rm["d"])
                    if d[0]:
                        self.facing = 1 if d[0] > 0 else -1
                    rm.update(ph="go", n=2, t=u["seg"], d=d)
                    self.begin_active("charge", u["seg"], u["dmg"], u["kb"], reach=50)
            return "hold"
        if k == "launch":                             # 溜め(狙う) → 突進
            if rm["ph"] == "charge":
                self.vx = self.vy = 0.0
                rm["d"] = self.aim(inp, rm["d"])
                if rm["d"][0]:
                    self.facing = 1 if rm["d"][0] > 0 else -1
                rm["t"] -= 1
                if rm["t"] <= 0:
                    rm.update(ph="go", t=u["frames"])
                    self.begin_active("charge", u["frames"], u["dmg"], u["kb"],
                                      armor=True, reach=60)
                return "hold"
            sp = float(u["speed"])
            self.vx, self.vy = rm["d"][0] * sp, rm["d"][1] * sp
            rm["t"] -= 1
            if rm["t"] <= 0:
                self.rm = None
                self.vx *= 0.3
                self.vy *= 0.3
                return None
            return "hold"
        if k == "homing":                             # 狙った場所へまっすぐ突進（アーマー）
            tx, ty = rm["tgt"]
            dx, dy = tx - self.x, ty - self.y
            dist = (dx * dx + dy * dy) ** 0.5
            sp = float(u["speed"])
            rm["t"] -= 1
            if dist <= sp:
                self.x, self.y = tx, ty
                self.vx = (3.0 if MAIN.centerx > tx else -3.0)   # ステージの方へ少し流れる
                self.vy = 0.0
                self.up_ready = False
                self.rm = None
                return None
            if rm["t"] <= 0:
                self.vx = dx / dist * sp * 0.3
                self.vy = dy / dist * sp * 0.3
                self.rm = None
                return None
            self.vx, self.vy = dx / dist * sp, dy / dist * sp
            if abs(dx) > 1:
                self.facing = 1 if dx > 0 else -1
            return "hold"
        if k in ("copter", "jet", "bubble"):          # プロペラ / ジェット / 泡の上昇
            self.vy += (-float(u["rise"]) - self.vy) * 0.3
            rm["t"] -= 1
            if rm["t"] <= 0:
                self.rm = None
                self.glide_timer = u.get("glide", 0)
                return None
            return "free"
        if k == "phase":                              # ゴーストライズ：壁もステージも通り抜けて上がる(RAVEN)
            d = int(inp.right) - int(inp.left)
            self.vx = d * float(u["side"])
            if d:
                self.facing = d
            self.vy = -float(u["rise"])
            self.invincible = max(self.invincible, 2)
            self.ghost_timer = max(self.ghost_timer, 2)
            rm["t"] -= 1
            if rm["t"] <= 0:
                self.rm = None
                self.unstick()
                self.vx *= 0.4
                self.vy = -2.0
                self.glide_timer = int(u.get("glide", 0))
                return None
            return "hold"
        if k == "chargejump":                         # ためジャンプ：ボタンを離す(か最大まで)と跳ぶ(GRANITE)
            rm["t"] += 1
            self.vx *= 0.8
            self.vy = 0.0
            if (not inp.special and rm["t"] >= 3) or rm["t"] >= int(u["max"]):
                t = rm["t"]
                self.rm = None
                dx = int(inp.right) - int(inp.left)
                if dx:
                    self.facing = dx
                self.vy = -(float(u["vy"]) + t * float(u["per"]))
                self.vx = dx * (3.0 + t * 0.1)
                self.begin_active("rise", int(u["frames"]), u["dmg"], u["kb"], armor=True)
                self.cast_timer = 12
                return None
            return "hold"
        if k in ("rift", "gate"):                       # ワープの溜め → 崖の上へ
            self.vx = self.vy = 0.0
            rm["t"] -= 1
            if rm["t"] <= 0:
                self.x, self.y = rm["tgt"]
                self.vx = self.vy = 0.0
                self.invincible = max(self.invincible, 24)
                self.ghost_timer = max(self.ghost_timer, 24)
                self.cast_timer = 12
                self.rm = None
                return None
            return "hold"
        if k == "valk":                               # IVORY: 上へ突き上げ(ph0) → 好きな横向きへ突進(ph1)
            if rm["ph"] == 0:
                self.vx = 0.0
                self.vy = -float(u["rise_vy"])
                rm["t"] -= 1
                if rm["t"] <= 0:
                    d = (int(inp.right) - int(inp.left)) or rm["dx"]
                    self.facing = d
                    rm["ph"], rm["t"], rm["dx"] = 1, int(u["glide_t"]), d
                    self.begin_active("charge", int(u["glide_t"]), u["dmg"], u["kb"],
                                      reach=int(u["reach"]))
                    self.cast_timer = 12
                return "hold"
            self.vx = rm["dx"] * float(u["glide_vx"])
            self.vy = float(u["glide_vy"])
            rm["t"] -= 1
            if rm["t"] <= 0:
                self.rm = None
                self.vx = rm["dx"] * 3.0
                self.glide_timer = int(u.get("glide", 0))
                return None
            return "hold"
        if k == "echo":                               # OPAL: 一定時間ごとに、もう一度ふき上がる
            rm["t"] -= 1
            if rm["t"] <= 0:
                if rm["n"] < int(u["bursts"]):
                    d = self.aim(inp, (0.0, -1.0))
                    if d[0]:
                        self.facing = 1 if d[0] > 0 else -1
                    self.vx = d[0] * float(u["sx"])
                    self.vy = d[1] * float(u["sy"])
                    rm["n"] += 1
                    rm["t"] = int(u["gap"])
                    self.cast_timer = 12
                else:
                    self.rm = None
                    self.glide_timer = int(u.get("glide", 0))
            return None                               # 重力も横の操作もふつうに効く
        if k == "balloon":                            # 風船：ゆっくり上昇、最後に破裂
            self.vy += (-float(u["rise"]) - self.vy) * 0.3
            rm["t"] -= 1
            if rm["t"] <= 0:
                self.rm = None
                self.glide_timer = 20
                self.begin_active("blast", 8, u["dmg"], u["kb"])
                self.cast_timer = 12
                return None
            return "free"
        self.rm = None
        return None

    def update(self, inp):
        c = self.c
        if self.on_ground or self.ledge is not None:      # 着地・崖つかまりで、空中の回数制限が回復
            self.air_steps = 0
            self.air_rush_used = False
        if self.confuse_timer > 0:                        # 混乱：左右の操作が逆になる
            inp = copy.copy(inp)
            inp.left, inp.right = inp.right, inp.left

        # --- 崖につかまっている間 / 崖をのぼっている間 ---
        if self.ledge is not None:
            self.update_ledge(inp)
            self._tick()
            return
        if self.climb_left > 0:
            self.update_climb()
            self._tick()
            return

        # --- ロープで引っ張られている間（DARKの復帰技） ---
        if self.hook is not None:
            tx, ty = self.hook
            dx, dy = tx - self.x, ty - self.y
            dist = (dx * dx + dy * dy) ** 0.5
            sp = float(c["up_sp"]["speed"])
            self.vx = 0.0
            self.vy = 0.0
            if self.hook_start is not None:           # ムチ：弧を描いて飛び移る
                sx, sy = self.hook_start
                total = max(1.0, ((tx - sx) ** 2 + (ty - sy) ** 2) ** 0.5)
                self.hook_t = min(1.0, self.hook_t + sp / total)
                t = self.hook_t
                self.x = sx + (tx - sx) * t
                self.y = sy + (ty - sy) * t - float(c["up_sp"]["amp"]) * math.sin(math.pi * t)
                if t >= 1.0:
                    self.x, self.y = tx, ty
                    self.hook = None
                    self.hook_start = None
                    self.land(MAIN.top)
            elif dist <= sp:
                self.x, self.y = tx, ty
                self.hook = None
                self.land(MAIN.top)
            else:
                self.x += dx / dist * sp
                self.y += dy / dist * sp
            self._tick()
            return

        if self.fin_t > 0:
            self.fin_t -= 1
        if self.mark_timer > 0:
            self.mark_timer -= 1
        if self.ward > 0:
            self.ward -= 1
        if self.ward_pop > 0:
            self.ward_pop -= 1
        if self.combo_timer > 0:                      # コンボスタック(BRONZE)：しばらく当てないと消える
            self.combo_timer -= 1
            if self.combo_timer == 0:
                self.combo = 0
        # --- 瞑想(JADE)：動かずに集中 → 最後までいくと%が減る。攻撃を受けると中断 ---
        if self.focus_timer > 0:
            self.focus_timer -= 1
            if self.focus_timer == 0:
                self.percent = max(0, self.percent - int(c["neutral"].get("heal", 8)))
                self.cast_timer = 12

        # --- シャドウストライク(SCARLET)：消えている間。終わると行き先に現れて斬る ---
        if self.tele_wait > 0:
            self.tele_wait -= 1
            if self.tele_wait == 0 and self.tele_dest is not None:
                self.arrive_tele()

        # --- ガード ---
        can_guard = (inp.guard and self.on_ground and self.stun == 0 and not self.acting())
        if can_guard and (self.guarding or self.shield > 5) and self.shield > 0:
            self.guarding = True
            self.shield = max(0.0, self.shield - c.get("guard_drain", 0.25))
        else:
            self.guarding = False
            self.shield = min(100.0, self.shield + c.get("shield_regen", 0.35))

        # --- 復帰技の特殊な動き（quick / launch / copter / rift） ---
        rm_mode = self.update_rm(inp)      # "hold"=完全に操作を奪う / "free"=横だけ動ける

        # --- ロケットの溜め（その場で止まって、終わると打ち上がる） ---
        charging = self.charge_timer > 0
        if charging:
            self.charge_timer -= 1
            self.vy = 0.0
            self.vx *= 0.8
            if self.charge_timer == 0:
                u = c["up_sp"]
                self.vy = -float(u["vy"])
                if u["dmg"] > 0:
                    self.begin_active("blast", u["frames"], u["dmg"], u["kb"])

        # --- 溜め攻撃(GRANITE)：ボタンを押している間ためて、離すと出る。ガードで中止 ---
        chg_hold = False
        if self.chg is not None:
            ch = self.chg
            if self.stun > 0 or inp.guard:
                self.chg = None
                if inp.guard:
                    self.cooldown = max(self.cooldown, 6)
            else:
                mv_ = int(inp.right) - int(inp.left)
                if mv_:
                    self.facing = mv_                 # 溜めながら向きを変えられる
                ch["t"] += 1
                smax = int(c["smash"]["max"])
                if (not inp.attack and ch["t"] >= 2) or ch["t"] >= smax + 12:
                    self.chg = None
                    self.attack(ch["dir"], min(1.0, ch["t"] / float(smax)))
                else:
                    chg_hold = True
        phasing = self.rm is not None and self.rm.get("k") == "phase"

        # --- 横の操作 ---
        flying = self.flight_timer > 0
        spd = 1.4 if self.speed_timer > 0 else 1.0
        if self.chill_timer > 0:                       # 冷えている間は動きが遅い
            spd *= 0.65
        if (c.get("hex") and self.foe is not None and self.foe.hex_timer > 0
                and self.foe.hex_by is self):          # RAVEN：獲物が呪われている間は速い(逃げ回れる)
            spd *= 1.2
        if c.get("stance"):                            # COBALT：SWIFTは速く、HEAVYは遅い
            spd *= 1.15 if self.stance == 0 else 0.85
        drift = 1.8 if self.chute_timer > 0 else (1.5 if flying else 1.0)
        if self.stun > 0:
            self.stun -= 1
            self.vx *= 0.985
        elif self.dodge_timer > 0:
            self.vx = self.dodge_dir * DODGE_SPEED    # ロール中は一定の速さで転がる
        elif self.rush_v and self.sp_timer > 0:
            self.vx = self.rush_v                      # 突進中は一定の速さ
        elif (self.guarding or self.counter_timer > 0 or self.focus_timer > 0 or self.tele_wait > 0
              or chg_hold):
            self.vx *= FRICTION
        elif charging or rm_mode == "hold":
            pass
        else:
            move = int(inp.right) - int(inp.left)
            if self.root_timer > 0 and self.on_ground:   # 足がからまっている：地上では歩けない
                if move:
                    self.facing = move
                move = 0
            if move:
                self.facing = move
                run = c["run"] * spd * drift
                if abs(self.vx) < run or self.vx * move < 0:
                    self.vx += move * c["accel"] * spd * drift
            else:
                self.vx *= FRICTION if self.on_ground else AIR_DRAG

        g0 = c["gravity"] * STAGE_GRAV * (0.7 if self.wing_timer > 0 else 1.0)
        grav = g0
        cap = MAX_FALL * min(1.0, 0.45 + 0.55 * STAGE_GRAV)
        if charging or rm_mode:
            grav = 0.0
        elif flying:                                   # 飛行中：上下キーで高さを操作
            grav = 0.0
            target = 0.0
            if self.stun == 0:
                target = (int(inp.down) - int(inp.up)) * float(c["up_sp"]["speed"])
            self.vy += (target - self.vy) * 0.25
        elif self.chute_timer > 0:
            grav = g0 * 0.12
            cap = CHUTE_FALL
        elif self.glide_timer > 0:
            grav = g0 * 0.3
        if self.meteor_timer > 0:
            cap = METEOR_FALL
        self.vy = min(self.vy + grav, cap)

        # --- 横移動：通れない四角は壁として扱う ---
        self.x += self.vx
        for s in (() if phasing else SOLID):
            if self.overlaps(s):
                self.x = s.left - self.w if self.vx > 0 else s.right
                self.vx = 0

        # --- 縦移動：床に乗る / 下から頭をぶつける ---
        prev_bottom = self.y + self.h
        self.y += self.vy
        self.on_ground = False
        for s in (() if phasing else SOLID):
            if self.overlaps(s):
                if prev_bottom <= s.top + 1:          # 上から着地
                    self.land(s.top)
                else:                                  # 下から頭ゴッチン
                    self.y = s.bottom
                    self.vy = max(self.vy, 0)

        # --- 浮き足場：下からすり抜け、上から乗れる（下キーで下りる） ---
        if self.vy >= 0 and not self.on_ground and not inp.down and not phasing:
            for p in THIN:
                if self.overlaps(p) and prev_bottom <= p.top + 1:
                    self.land(p.top, refresh=not any(p is q for q in NOREFRESH))
                    break

        # --- 崖つかまり ---
        if not self.on_ground:
            self.try_grab_ledge(inp)
        elif any(abs(self.y + self.h - s.top) < 2 and self.x < s.right and s.left < self.x + self.w
                 for s in SOLID):
            self.last_ground = (self.x, self.y)       # ステージ(動かない床)の上に立っていた場所

        self._tick()

    def is_out(self):
        cx = self.x + self.w / 2
        cy = self.y + self.h / 2
        return not (BLAST.left < cx < BLAST.right and BLAST.top < cy < BLAST.bottom)

    def draw(self, screen, cam, small):
        ghost = self.ghost_timer > 0 or self.tele_wait > 0
        if not ghost and self.invincible > 0 and (self.invincible // 4) % 2 == 0:
            return                                    # 復活直後の無敵は点滅
        s = cam.s
        r = cam.rect(self.rect)

        if self.hook is not None:                     # ロープ
            pygame.draw.line(screen, (210, 210, 255), r.center,
                             cam.pt(self.hook[0] + self.w / 2, self.hook[1] + self.h / 2), 3)

        flash = self.stun > 0 and (self.stun // 3) % 2 == 0
        color = (170, 225, 255) if self.freeze_timer > 0 else self.color   # 凍結は水色
        if self.c.get("mimic") and self.foe is not None and self.freeze_timer == 0:
            color = tuple(int(a * 0.45 + b * 0.55) for a, b in zip(self.color, self.foe.color))   # OPAL: 相手の色にそまる
        draw_body(screen, r, color, self.facing, s, flash=flash and self.freeze_timer == 0,
                  ghost=ghost)
        if self.freeze_timer > 0:
            pygame.draw.rect(screen, (230, 250, 255), r, width=3, border_radius=max(2, int(8 * s)))
        if self.tele_wait > 0 and self.tele_dest is not None:     # シャドウストライクの行き先(予告の影)
            dr = cam.rect(pygame.Rect(int(self.tele_dest[0]), int(self.tele_dest[1]), self.w, self.h))
            col = (255, 60, 80) if (self.tele_wait // 3) % 2 == 0 else (255, 210, 215)
            pygame.draw.rect(screen, col, dr, width=3, border_radius=max(2, int(8 * s)))
            pygame.draw.line(screen, col, r.center, dr.center, 1)

        if self.chill_timer > 0 and self.freeze_timer == 0:   # 冷え：水色の枠
            pygame.draw.rect(screen, (150, 215, 255), r, width=2, border_radius=max(2, int(8 * s)))
        if self.focus_timer > 0:                      # 瞑想：緑の光が集まる
            rad = int((self.h * 0.9 - (55 - self.focus_timer) * 0.5) * s)
            pygame.draw.circle(screen, (130, 255, 180), r.center, max(4, rad), 2)
        if self.root_timer > 0:                       # 足止め：足元にからまる緑のツル
            for q in range(4):
                x0 = r.x + int((q + 0.5) * r.w / 4)
                pygame.draw.line(screen, (90, 170, 80), (x0, r.bottom),
                                 (x0 + int(((q % 2) * 2 - 1) * 5 * s), r.bottom - int(14 * s)), 3)
        if self.mark_timer > 0 and (self.mark_timer > 60 or (self.mark_timer // 5) % 2 == 0):
            mc = (255, 70, 70)                            # 印：赤い照準
            pygame.draw.circle(screen, mc, r.center, int(max(r.w, r.h) * 0.75), 2)
            pygame.draw.circle(screen, mc, r.center, int(max(r.w, r.h) * 0.4), 1)
            pygame.draw.line(screen, mc, (r.centerx - int(r.w * 0.95), r.centery),
                             (r.centerx + int(r.w * 0.95), r.centery), 1)
            pygame.draw.line(screen, mc, (r.centerx, r.centery - int(r.h * 0.65)),
                             (r.centerx, r.centery + int(r.h * 0.65)), 1)
        if self.chg is not None:                      # 溜め(GRANITE)：ためるほど輪が大きく・赤くなる
            fr = min(1.0, self.chg["t"] / float(self.c["smash"]["max"]))
            rad = int((max(self.w, self.h) * 0.6 + 26 * fr) * s)
            pygame.draw.circle(screen, (255, int(230 - 130 * fr), int(110 - 80 * fr)), r.center,
                               rad, 3 if fr < 1.0 else 6)
            pygame.draw.rect(screen, (60, 60, 70), (r.x, r.y - int(14 * s), r.w, max(3, int(5 * s))))
            pygame.draw.rect(screen, (255, int(230 - 130 * fr), 80),
                             (r.x, r.y - int(14 * s), int(r.w * fr), max(3, int(5 * s))))
        if self.hex_timer > 0:                        # 呪い(RAVEN)：頭の上のカウントダウン
            hf = (self.hex_by.c.get("hex") or HEX_DEFAULT)["frames"] if self.hex_by else 240
            frac = self.hex_timer / float(max(1, hf))
            urgent = self.hex_timer < 60 and (self.hex_timer // 5) % 2 == 0
            hr = pygame.Rect(r.centerx - int(15 * s), r.y - int(46 * s), int(30 * s), int(30 * s))
            pygame.draw.circle(screen, (50, 20, 70), hr.center, int(16 * s))
            pygame.draw.arc(screen, (255, 70, 70) if urgent else (225, 100, 255), hr,
                            math.pi / 2, math.pi / 2 + 2 * math.pi * frac, max(2, int(5 * s)))
        if self.hex_pop > 0:                          # 呪いが爆発/解除された輪
            pygame.draw.circle(screen, (225, 100, 255), r.center,
                               int(max(r.w, r.h) * (0.6 + (18 - self.hex_pop) * 0.1)), 3)
        if self.ward > 0 and (self.ward > 60 or (self.ward // 4) % 2 == 0):
            wr = int(max(r.w, r.h) * (0.85 + 0.06 * math.sin(self.ward * 0.2)))   # 加護の膜：うすい光の玉
            ws = pygame.Surface((wr * 2 + 4, wr * 2 + 4), pygame.SRCALPHA)
            pygame.draw.circle(ws, (255, 245, 200, 60), (wr + 2, wr + 2), wr)
            pygame.draw.circle(ws, (255, 250, 220, 220), (wr + 2, wr + 2), wr, 3)
            screen.blit(ws, (r.centerx - wr - 2, r.centery - wr - 2))
        if self.ward_pop > 0:                             # 膜がはじけた輪
            pr_ = int(max(r.w, r.h) * (0.9 + (18 - self.ward_pop) * 0.12))
            pygame.draw.circle(screen, (255, 250, 200), r.center, pr_, 3)
        if self.c.get("combo") and (self.combo > 0 or self.fin_t > 0):   # BRONZE：頭の上にスタックの玉
            full = self.combo >= 5
            for q in range(5):
                pc = (255, 80, 50) if full else (255, 215, 80)
                pos = (r.centerx + int((q - 2) * 9 * s), r.y - int(24 * s))
                if q < self.combo:
                    pygame.draw.circle(screen, pc, pos, max(3, int(4 * s)))
                else:
                    pygame.draw.circle(screen, (120, 120, 130), pos, max(3, int(4 * s)), 1)
            if self.combo >= 3:                       # 3以上：フィニッシャーがアーマーつき(赤い枠)
                pygame.draw.rect(screen, (255, 120, 60), pygame.Rect(r.x - 2, r.y - 2, r.w + 4, r.h + 4),
                                 width=3 if full else 2, border_radius=max(2, int(9 * s)))
        if self.c.get("stance"):                      # COBALT：スタンスの色の枠(水色=SWIFT / だいだい=HEAVY)
            sc = (120, 230, 255) if self.stance == 0 else (255, 150, 60)
            pygame.draw.rect(screen, sc, pygame.Rect(r.x - 2, r.y - 2, r.w + 4, r.h + 4),
                             width=2 if self.stance == 0 else 4, border_radius=max(2, int(9 * s)))
        if self.confuse_timer > 0:                    # 混乱：頭の上をまわる紫の星
            for q in range(3):
                ang = self.confuse_timer * 0.25 + q * 2.094
                pygame.draw.circle(screen, (200, 90, 240),
                                   (r.centerx + int(math.cos(ang) * 16 * s),
                                    r.y - int(10 * s) + int(math.sin(ang) * 5 * s)),
                                   max(2, int(4 * s)))
        if self.burn_timer > 0:                       # 燃焼：オレンジの枠と炎
            pygame.draw.rect(screen, (255, 140, 40), r, width=2, border_radius=max(2, int(8 * s)))
            fh = int((10 + (self.burn_timer % 6)) * s)
            pygame.draw.polygon(screen, (255, 170, 50),
                                [(r.centerx - int(7 * s), r.y), (r.centerx + int(7 * s), r.y),
                                 (r.centerx, r.y - fh)])
        if self.chute_timer > 0:                      # パラシュート
            pygame.draw.ellipse(screen, (255, 190, 225),
                                pygame.Rect(r.x - int(10 * s), r.y - int(26 * s),
                                            r.w + int(20 * s), int(16 * s)), 3)
        if self.rm is not None:                       # 復帰技の目印
            rk = self.rm["k"]
            if rk == "launch" and self.rm["ph"] == "charge":      # 狙いの矢印
                dx, dy = self.rm["d"]
                pygame.draw.line(screen, (255, 220, 120), r.center,
                                 (r.centerx + dx * 90 * s, r.centery + dy * 90 * s), 4)
            elif rk == "rift" and self.rm.get("line"):            # クナイの軌跡
                tx, ty = self.rm["tgt"]
                pygame.draw.line(screen, (255, 90, 110), r.center,
                                 cam.pt(tx + self.w / 2, ty + self.h / 2), 3)
                pygame.draw.circle(screen, (255, 90, 110), cam.pt(tx + self.w / 2, ty + self.h / 2),
                                   int(8 * s), 2)
            elif rk == "cannon" and self.rm["ph"] == "aim":       # 狙いの矢印（角度が往復）
                th = math.radians(20 + 55 * (0.5 + 0.5 * math.sin(self.rm["a"])))
                ex = r.centerx + self.rm["dx"] * math.cos(th) * 110 * s
                ey = r.centery - math.sin(th) * 110 * s
                pygame.draw.line(screen, (255, 220, 120), r.center, (ex, ey), 5)
                pygame.draw.circle(screen, (255, 245, 200), (int(ex), int(ey)), max(3, int(7 * s)))
            elif rk == "spiral":                                  # らせんの輪
                ang = self.rm["t"] * 0.42
                for q in range(2):
                    a2 = ang + q * 3.14159
                    pygame.draw.circle(screen, (120, 240, 180),
                                       (r.centerx + int(math.cos(a2) * 30 * s), r.centery + int(math.sin(a2) * 18 * s)),
                                       max(3, int(6 * s)))
            elif rk == "surf":                                    # 波
                for q in range(3):
                    wx = r.centerx - self.rm["dx"] * int((16 + q * 14) * s)
                    pygame.draw.arc(screen, (130, 210, 255),
                                    pygame.Rect(wx - int(10 * s), r.bottom - int(14 * s), int(20 * s), int(18 * s)),
                                    0.2, 2.9, 3)
            elif rk == "chargejump":                              # ためジャンプ：足元の輪
                fr = min(1.0, self.rm["t"] / float(self.c["up_sp"]["max"]))
                pygame.draw.circle(screen, (255, int(230 - 130 * fr), 100), (r.centerx, r.bottom),
                                   int((16 + 34 * fr) * s), 3)
            elif rk in ("rift", "gate"):                           # ワープの入口と出口
                pygame.draw.circle(screen, (150, 110, 240), r.center,
                                   int((self.h * 0.5 + self.rm["t"]) * s), 3)
                tx, ty = self.rm["tgt"]
                pygame.draw.circle(screen, (150, 110, 240), cam.pt(tx + self.w / 2, ty + self.h / 2),
                                   int(self.h * 0.5 * s), 2)
            elif rk == "balloon":                                 # 風船（割れる直前は黄色く点滅）
                t = self.rm["t"]
                bc = (255, 230, 120) if (t < 15 and (t // 3) % 2 == 0) else (255, 120, 160)
                pygame.draw.line(screen, (230, 230, 240), (r.centerx, r.y),
                                 (r.centerx, r.y - int(14 * s)), 2)
                pygame.draw.ellipse(screen, bc, pygame.Rect(r.centerx - int(22 * s), r.y - int(62 * s),
                                                            int(44 * s), int(50 * s)))
            elif rk == "bubble":                                  # 泡
                pygame.draw.circle(screen, (190, 235, 255), r.center,
                                   int(max(self.w, self.h) * 0.85 * s), 3)
                pygame.draw.circle(screen, (255, 255, 255),
                                   (r.centerx - int(14 * s), r.centery - int(22 * s)),
                                   max(2, int(5 * s)))
            elif rk == "phoenix":                                 # 炎のオーラ
                pygame.draw.ellipse(screen, (255, 120, 30),
                                    r.inflate(int(26 * s), int(44 * s)), 3)
                pygame.draw.ellipse(screen, (255, 210, 90),
                                    r.inflate(int(10 * s), int(20 * s)), 2)
            elif rk == "pillar":                                  # 足元の石柱
                pygame.draw.rect(screen, (140, 115, 95),
                                 pygame.Rect(r.x - int(8 * s), r.bottom, r.w + int(16 * s), int(150 * s)))
                pygame.draw.rect(screen, (90, 70, 55),
                                 pygame.Rect(r.x - int(8 * s), r.bottom, r.w + int(16 * s), int(150 * s)), 2)
            elif rk == "pogo":                                    # ばね
                zx = r.centerx
                for q in range(4):
                    y0 = r.bottom + q * int(7 * s)
                    pygame.draw.line(screen, (220, 160, 240),
                                     (zx - int(9 * s), y0), (zx + int(9 * s), y0 + int(6 * s)), 3)
            elif rk == "homing" and self.rm.get("rope"):          # グラップルのロープ
                pygame.draw.line(screen, (200, 200, 215), r.center, cam.pt(*self.rm["rope"]), 3)
            elif rk == "jet":                                     # ジェットの炎
                fl = (22 + (self.rm["t"] % 4) * 5) * s
                pygame.draw.polygon(screen, (255, 170, 60),
                                    [(r.centerx - int(10 * s), r.bottom),
                                     (r.centerx + int(10 * s), r.bottom),
                                     (r.centerx, r.bottom + int(fl))])
            elif rk == "copter":                                  # プロペラ
                for sx in (-1, 1):
                    pygame.draw.line(screen, (200, 245, 110), (r.centerx, r.y - int(6 * s)),
                                     (r.centerx + sx * int(34 * s), r.y - int(6 * s)), 4)
        if self.flight_timer > 0:                     # 翼
            for sx in (-1, 1):
                wx = r.right if sx > 0 else r.x - int(22 * s)
                pygame.draw.ellipse(screen, (120, 30, 60),
                                    pygame.Rect(wx, r.y + int(6 * s), int(22 * s), int(14 * s)))

        if self.barrier_timer > 0 and (self.barrier_timer > 90 or (self.barrier_timer // 6) % 2 == 0):
            pygame.draw.circle(screen, (100, 235, 225), r.center,
                               int(max(self.w, self.h) * 0.8 * s), 2)       # バリア
        if self.wing_timer > 0:                       # ウィング
            for sx in (-1, 1):
                wx = r.right - int(4 * s) if sx > 0 else r.x - int(18 * s)
                pygame.draw.ellipse(screen, (255, 240, 255),
                                    pygame.Rect(wx, r.y + int(12 * s), int(22 * s), int(12 * s)), 2)
        if self.c.get("rage") and self.percent >= 50:  # RUST：怒っている時は赤い枠
            pygame.draw.rect(screen, (255, 80, 50),
                             pygame.Rect(r.x - 2, r.y - 2, r.w + 4, r.h + 4),
                             width=2, border_radius=max(2, int(9 * s)))

        hb = self.hitbox()
        if hb:
            if self.sp_timer > 0:
                col = (255, 150, 50)
            elif self.atk_dir == "down":
                col = (255, 70, 70)                   # メテオは赤
            elif self.atk_reflect:
                col = (120, 225, 255)                 # 打ち返しの判定は水色
            elif self.atk_crit:
                col = (255, 140, 255)                 # 大当たり(クリティカル)はピンク
            else:
                col = (255, 230, 80)
            pygame.draw.rect(screen, col, cam.rect(hb), border_radius=max(2, int(6 * s)))
            sw = self.c.get("sweet")
            if sw and self.atk_dir == "side" and self.sp_timer == 0:   # IVORY: 先端(強い所)を白く光らせる
                pygame.draw.rect(screen, (255, 255, 255),
                                 cam.rect(sweet_tip(hb, self.atk_facing, sw["zone"])),
                                 border_radius=max(2, int(6 * s)))
        elif self.startup > 0:                        # 溜め中は、これから出る判定を薄く表示
            pv = self.hitbox(preview=True)
            if pv:
                pygame.draw.rect(screen, (200, 200, 210), cam.rect(pv),
                                 width=2, border_radius=max(2, int(6 * s)))

        if self.armored():                            # アーマー中は金色の枠
            pygame.draw.rect(screen, (255, 200, 80),
                             pygame.Rect(r.x - 3, r.y - 3, r.w + 6, r.h + 6),
                             width=3, border_radius=max(2, int(10 * s)))
        if self.counter_timer > 0:                    # カウンター待機は金色のリング
            pygame.draw.circle(screen, (255, 215, 90), r.center,
                               int(max(self.w, self.h) * 0.9 * s), 4)

        if self.guarding:                             # シールド（小さくなると割れそう）
            rad = max(4, int(max(self.w, self.h) * 0.85 * (0.45 + 0.55 * self.shield / 100) * s))
            d = rad * 2 + 4
            bubble = pygame.Surface((d, d), pygame.SRCALPHA)
            pygame.draw.circle(bubble, (120, 200, 255, 90), (d // 2, d // 2), rad)
            pygame.draw.circle(bubble, (200, 235, 255, 210), (d // 2, d // 2), rad, 3)
            screen.blit(bubble, (r.centerx - d // 2, r.centery - d // 2))

        if self.cast_timer > 0 or self.charge_timer > 0:   # 必殺技の発動エフェクト
            rad = int((self.h * 0.7 + (12 - self.cast_timer) * 4) * s)
            pygame.draw.circle(screen, (255, 255, 255), r.center, max(3, rad), 2)

        # アイテム効果の目印（頭の上の小さい四角）
        mark = 0
        if self.power_timer > 0:
            pygame.draw.rect(screen, (240, 90, 70), pygame.Rect(r.x + mark, r.y - 8, 8, 8))
            mark += 11
        if self.speed_timer > 0:
            pygame.draw.rect(screen, (90, 160, 255), pygame.Rect(r.x + mark, r.y - 8, 8, 8))
            mark += 11
        if self.barrier_timer > 0:
            pygame.draw.rect(screen, (80, 210, 200), pygame.Rect(r.x + mark, r.y - 8, 8, 8))
            mark += 11
        if self.wing_timer > 0:
            pygame.draw.rect(screen, (255, 205, 245), pygame.Rect(r.x + mark, r.y - 8, 8, 8))

        tag = small.render(self.tag, True, ui_color(self.color))
        screen.blit(tag, tag.get_rect(center=(r.centerx, r.y - 22)))


# ======================================================================
#  CPU（コンピューター操作）
# ======================================================================
class CPU:
    NAMES = ["EASY", "NORMAL", "HARD"]

    def __init__(self, level):
        self.level = level                        # 0=EASY 1=NORMAL 2=HARD
        self.react = (22, 12, 6)[level]           # 判断の間隔(小さいほど反応が速い)
        self.atk_rate = (0.35, 0.6, 0.9)[level]   # 攻撃する確率
        self.idle_rate = (0.25, 0.1, 0.0)[level]  # ぼーっとする確率
        self.rec_rate = (0.6, 0.85, 1.0)[level]   # 復帰の成功率
        self.proj_rate = (0.1, 0.3, 0.5)[level]   # 必殺技を使う確率
        self.guard_rate = (0.0, 0.35, 0.65)[level]  # ガードする確率
        self.dodge_rate = (0.0, 0.25, 0.5)[level]   # ガードからの回避をする確率
        self.timer = 0
        self.jump_cd = 0
        self.guard_hold = 0
        self.guard_cd = 0
        self.pending_dodge = None
        self.hold_atk = 0                       # 溜め攻撃(GRANITE)：ボタンを押し続ける残りフレーム
        # STEELのカウンター：見てから構えるので、確率も低めで、構えるのが少し遅れる（v14）
        self.counter_rate = (0.15, 0.25, 0.35)[level]   # 攻撃が迫った時にカウンターを選ぶ確率
        self.counter_lag = (14, 11, 9)[level]           # 構えるまでの遅れ(2〜2+この値 フレーム)
        self.pending_counter = None
        # 混乱（PLUMのジョーカーダート）：左右が逆になっても、気づいたら逆向きに入力して打ち消す（v14）
        self.conf_comp = (0.5, 0.85, 1.0)[level]        # 打ち消せる確率(混乱のたびに決める)
        self.conf_lag = (30, 18, 8)[level]              # 気づくまでの遅れ(フレーム)
        self.conf_age = 0
        self.conf_fix = False
        self.stuck = 0
        self.last_x = 0.0
        self.inp = Inp()
        self.projs = []

    def mine_near_foe(self, me, foe):
        """自分の地雷の爆風が、相手に届く位置にあるか（起爆のタイミング）"""
        fr = foe.rect
        for p in self.projs:
            if p.owner is me and p.persist and p.exploding == 0 and not p.dead:
                b = p.blast
                r = pygame.Rect(int(p.x + p.w / 2 - b / 2), int(p.y + p.h / 2 - b / 2), b, b)
                if r.colliderect(fr):
                    return True
        return False

    def think(self, me, foe, projs, items=()):
        inp = self._think(me, foe, projs, items)
        if self.hold_atk > 0 and me.chg is not None:   # 溜め攻撃：決めたフレーム数だけ攻撃ボタンを押し続ける
            self.hold_atk -= 1
            inp = copy.copy(inp)
            inp.attack = True
        else:
            self.hold_atk = 0
        if me.confuse_timer > 0:                      # 混乱中：左右が逆になる
            if self.conf_age == 0:
                self.conf_fix = random.random() < self.conf_comp
            self.conf_age += 1
            if self.conf_fix and self.conf_age > self.conf_lag:
                inp = copy.copy(inp)                  # 先に逆にしておけば、混乱で戻って狙い通りに動く
                inp.left, inp.right = inp.right, inp.left
        else:
            self.conf_age = 0
            self.conf_fix = False
        return inp

    def _think(self, me, foe, projs, items=()):
        self.projs = projs
        if self.jump_cd > 0:
            self.jump_cd -= 1
        if self.guard_cd > 0:
            self.guard_cd -= 1

        # 崖につかまっている/のぼっている間は、専用の行動
        if me.ledge is not None or me.climb_left > 0:
            return self.on_ledge(me)

        mr = me.rect
        cx = mr.centerx
        # ステージから落ちそう/落ちた → 復帰を最優先（島や壁の上に立っている間は戦う）
        if (not me.on_ground) and (mr.bottom > MAIN.top + 8 or cx < MAIN.left - 15
                                   or cx > MAIN.right + 15):
            self.guard_hold = 0
            return self.recover(me)

        # 落雷の予告が足元に出たら、よける
        if self.level >= 1 and me.on_ground and me.stun == 0:
            for b in BOLTS:
                if b["t"] > 0 and abs(b["x"] - cx) < 80:
                    away = 1 if cx >= b["x"] else -1
                    if (away > 0 and mr.right > MAIN.right - 10) or (away < 0 and mr.left < MAIN.left + 10):
                        away = -away
                    self.guard_hold = 0
                    self.inp = Inp(left=away < 0, right=away > 0)
                    return self.inp

        # カウンターの構え（見てから出すので、少し遅れる。間に合わないこともある）
        if self.pending_counter is not None:
            self.pending_counter -= 1
            if me.stun > 0 or not me.on_ground:
                self.pending_counter = None
            elif self.pending_counter <= 0:
                self.pending_counter = None
                me.special_neutral()
            return Inp()

        # ガード（ときどき、ガードから回避する）
        if self.guard_hold > 0:
            self.guard_hold -= 1
            if self.pending_dodge is not None and me.guarding and self.guard_hold <= 16:
                d = self.pending_dodge
                self.pending_dodge = None
                if me.dodge(d):
                    self.guard_hold = 0
                    return Inp()
            return Inp(guard=True)
        if (self.guard_rate > 0 and self.guard_cd == 0 and me.on_ground
                and me.stun == 0 and self.threatened(me, foe, projs)):
            self.guard_cd = 25
            n = me.neutral_spec()
            if (n["mode"] == "counter" and me.special_cd == 0 and self.pending_counter is None
                    and random.random() < self.counter_rate):
                self.pending_counter = random.randint(2, 2 + self.counter_lag)   # 見てから構える
                return Inp()
            if random.random() < self.guard_rate:
                self.guard_hold = 20
                self.pending_dodge = None
                if random.random() < self.dodge_rate:
                    away = -1 if foe.x > me.x else 1
                    safe = MAIN.left + 120 < cx < MAIN.right - 120
                    self.pending_dodge = away if (safe and random.random() < 0.6) else 0
                return Inp(guard=True)

        self.timer -= 1
        if self.timer <= 0:
            self.timer = self.react + random.randint(0, 4)
            self.decide(me, foe, items)

        inp = self.inp
        # 自分から崖を踏み外さない
        if me.on_ground and abs(mr.bottom - MAIN.top) <= 2:
            if inp.left and mr.left < MAIN.left + 8:
                if self.jump_cd == 0 and self.gap_ahead(mr, -1):
                    me.jump()                       # すき間の向こうに足場があれば飛び越える
                    self.jump_cd = 25
                else:
                    inp.left = False
            if inp.right and mr.right > MAIN.right - 8:
                if self.jump_cd == 0 and self.gap_ahead(mr, 1):
                    me.jump()
                    self.jump_cd = 25
                else:
                    inp.right = False
        elif me.on_ground and self.jump_cd == 0 and (inp.left or inp.right):
            d = 1 if inp.right else -1                # 島の端：向こうに床があるなら飛び越える
            if self.edge_ahead(mr, d) and self.gap_ahead(mr, d):
                me.jump()
                self.jump_cd = 25
        # 壁にひっかかったらジャンプ
        if me.on_ground and (inp.left or inp.right) and abs(me.x - self.last_x) < 0.3:
            self.stuck += 1
        else:
            self.stuck = 0
        self.last_x = me.x
        if self.stuck > 12 and self.jump_cd == 0:
            me.jump()
            self.jump_cd = 20
            self.stuck = 0
        return inp

    def _swing(self, me, foe, direction):
        """通常攻撃。溜め攻撃(GRANITE)なら、どれだけ溜めるかも決める"""
        me.attack(direction)
        if me.chg is not None:
            smax = int(me.c["smash"]["max"])
            if foe.attack_timer > 0 or foe.startup > 0:     # 相手が攻撃中なら、溜めずに出す
                self.hold_atk = random.randint(0, 5)
            elif foe.stun > 0 or foe.guarding or foe.freeze_timer > 0:
                self.hold_atk = smax                       # 動けない相手には、満タンまで溜める
            elif self.level == 0:
                self.hold_atk = random.choice((3, 8, 14))
            else:
                self.hold_atk = random.choice((4, 12, 24, smax))

    def edge_ahead(self, mr, d):
        """進む先に床がない（端に来ている）か"""
        px = mr.right + 6 if d > 0 else mr.left - 6
        py = mr.bottom + 3
        return not any(s.collidepoint(px, py) for s in SOLID + THIN)

    def gap_ahead(self, mr, d):
        """すき間(20〜230px)の向こうに、飛び移れる動かない床があるか"""
        for s in SOLID:
            gap = (s.left - mr.right) if d > 0 else (mr.left - s.right)
            if 20 <= gap <= 230 and s.top <= mr.bottom + 60 and s.bottom > mr.top - 200:
                return True
        return False

    def on_ledge(self, me):
        """崖につかまった後の行動：のぼる / 崖ジャンプ / 崖のぼり攻撃"""
        inp = Inp()
        if me.ledge is None or me.hang_age < 18:
            return inp
        r = random.random()
        if self.level == 0 or r < 0.5:
            me.ledge_climb()
        elif r < 0.72:
            me.ledge_jump()
        elif r < 0.9 and self.level >= 1:
            me.ledge_attack()
        else:
            me.ledge_climb()
        return inp

    def threatened(self, me, foe, projs):
        """相手の攻撃や飛び道具が自分に迫っているか"""
        mr = me.rect
        if foe.tele_wait > 0 and foe.tele_dest is not None:       # SCARLET の予告の影が近い：身構える
            if abs(foe.tele_dest[0] + foe.w / 2 - mr.centerx) < 110:
                return True
        hb = foe.hitbox(preview=True)
        if hb:
            zone = pygame.Rect(hb.x - 25, hb.y - 15, hb.w + 50, hb.h + 30)
            if zone.colliderect(mr):
                return True
        for p in projs:
            if p.owner is me:
                continue
            if p.kind in ("zone", "turret", "spring", "portal"):   # 置いてある場・砲台・ばね・ポータルは避ける対象にしない
                continue
            if p.kind == "bomb":                  # 爆弾が足元にあって、もうすぐ爆発
                if p.fuse < 25 and abs(p.x - mr.centerx) < 110 and abs(p.y - mr.centery) < 110:
                    return True
                continue
            if p.vx == 0:                     # 真上から落ちてくる雷
                if abs(p.x + p.w / 2 - mr.centerx) < 70 and p.y < mr.bottom:
                    return True
                continue
            toward = (p.vx > 0 and p.x < mr.centerx) or (p.vx < 0 and p.x > mr.centerx)
            if toward and abs(p.x - mr.centerx) < 160 and abs(p.y - mr.centery) < 70:
                return True
        return False

    def recover(self, me):
        self.timer = 0
        inp = Inp()
        mr = me.rect
        cx = mr.centerx
        kind = me.c["up_sp"]["kind"]
        under = (mr.bottom > MAIN.top + 5
                 and MAIN.left + 20 <= cx <= MAIN.right - 20)
        if under:      # ステージの真下 → まず横へ逃げる
            target = MAIN.left - 40 if cx < MAIN.centerx else MAIN.right + 40
        else:          # 端に向かってから、上に乗る
            target = MAIN.left + 40 if cx < MAIN.centerx else MAIN.right - 40
        if cx < target - 8:
            inp.right = True
        elif cx > target + 8:
            inp.left = True
        if me.flight_timer > 0:                       # 飛行中は、ステージより高くなるまで上昇
            inp.up = mr.bottom > MAIN.top - 40
        if kind == "phase" and under:                 # ステージの真下なら、そのまま真上へ通り抜ける
            inp.left = inp.right = False
        if me.rm is not None and me.rm.get("k") == "chargejump":   # 必要な高さに足りるまで、ボタンを押し続ける
            u = me.c["up_sp"]
            depth = max(0.0, mr.bottom - (MAIN.top - 50))
            need_v = math.sqrt(2 * me.c["gravity"] * STAGE_GRAV * depth) + 2.0
            need_t = max(0.0, (need_v - float(u["vy"])) / float(u["per"]))
            inp.special = me.rm["t"] < min(float(u["max"]), need_t)
        if kind in ("quick", "launch", "airstep", "kunai", "twin", "echo", "valk"):   # 方向を狙う技：ステージより低いなら斜め上へ
            inp.up = mr.bottom > MAIN.top - 20

        if self.jump_cd == 0 and mr.bottom > MAIN.top - 10:
            if kind in ("hook", "swing") and me.up_ready:  # ロープは届くなら最優先（ジャンプを温存）
                if random.random() < self.rec_rate:
                    me.special_up(inp)
                self.jump_cd = 6
            elif me.vy > 0 and not under:
                if me.jumps > 0:                      # まずジャンプ
                    if random.random() < self.rec_rate:
                        me.jump()
                    self.jump_cd = 10
                elif me.up_ready:                     # ジャンプが尽きたら復帰技
                    if random.random() < self.rec_rate:
                        me.special_up(inp)
                    self.jump_cd = 12
            elif (under and kind in ("warp", "rift", "rewind", "homing", "airstep", "reel", "kunai", "phase", "gate")
                  and me.up_ready and me.jumps == 0):
                if random.random() < self.rec_rate:   # ワープなら真下からでも戻れる
                    me.special_up(inp)
                self.jump_cd = 12
        self.inp = inp
        return inp

    def decide(self, me, foe, items=()):
        inp = Inp()
        self.inp = inp
        if random.random() < self.idle_rate:
            return
        mr, fr = me.rect, foe.rect
        dx = fr.centerx - mr.centerx
        dy = fr.centery - mr.centery
        m = me.c["side"]
        half = (mr.w + fr.w) // 2
        side_hi = half + m["gap"] + m["reach"]            # この距離まで届く
        side_lo = half + m["gap"] - 10 if m["gap"] > 0 else 0   # 遠くに出る技は近すぎると当たらない
        near_x = half + 15
        up_reach = me.c["up"]["reach"] + me.c["up"]["gap"] + 60
        down_reach = me.c["down"]["reach"] + me.c["down"]["gap"] + 60

        # 呪い(RAVEN)：かけた側は逃げ回り、かけられた側は呪い主を追って攻撃する
        cursed = me.hex_timer > 0 and me.hex_by is foe
        if foe.hex_timer > 0 and foe.hex_by is me and self.level >= 1:
            away = -1 if dx > 0 else 1
            near_edge = ((away < 0 and mr.left < MAIN.left + 90)
                         or (away > 0 and mr.right > MAIN.right - 90))
            if not near_edge:
                inp.left, inp.right = away < 0, away > 0
                if abs(dx) < 220 and me.jumps > 0 and self.jump_cd == 0 and random.random() < 0.15:
                    me.jump()
                    self.jump_cd = 20
                return
        atk_rate = 1.0 if cursed else self.atk_rate

        # 近づく
        if abs(dx) > side_hi * (0.75 if m["gap"] > 0 else 0.6):
            if dx > 0:
                inp.right = True
            else:
                inp.left = True

        # アイテムが近くにあれば、取りに行く（ボムは罠なので取らない）
        items = [it for it in items if it.kind != "bomb"]
        if items and self.level >= 1:
            best = min(items, key=lambda it: abs(it.x + 14 - mr.centerx))
            ix = best.x + 14
            if abs(ix - mr.centerx) < 700 and (abs(dx) > 160 or random.random() < 0.3):
                inp.left = inp.right = False
                if ix > mr.centerx + 10:
                    inp.right = True
                elif ix < mr.centerx - 10:
                    inp.left = True
                if best.y < mr.y - 40 and me.on_ground and self.jump_cd == 0:
                    me.jump()
                    self.jump_cd = 15
                if best.y > mr.bottom + 60 and me.on_ground and mr.bottom < MAIN.top - 10:
                    inp.down = True

        # 相手が上にいたらジャンプ（復帰用に1回分は残しておく）
        if dy < -70 and abs(dx) < 220 and self.jump_cd == 0:
            if me.on_ground:
                me.jump()
                self.jump_cd = 15
            elif me.jumps > 1 and me.vy > 0 and random.random() < 0.4:
                me.jump()
                self.jump_cd = 15

        # 相手が下の足場にいたら、足場から下りる
        if dy > 90 and me.on_ground and mr.bottom < MAIN.top - 10:
            inp.down = True

        n = me.neutral_spec()
        mode = n["mode"]
        if mode == "stance" and me.special_cd == 0 and random.random() < 0.25:
            want = 1 if (abs(dx) < 120 and abs(dy) < 80) else 0   # 近いならHEAVY、遠いならSWIFT
            if me.stance != want:
                me.special_neutral()
                return
        if (mode == "focus" and me.special_cd == 0 and me.on_ground and abs(dx) > 260
                and me.percent >= 12 and foe.stun == 0 and random.random() < 0.4):
            me.special_neutral()                      # 相手が遠い時に、瞑想で回復
            return

        if (cursed and mode == "shoot" and not n["persist"] and n["kind"] not in STATIC_KINDS
                and me.special_cd == 0 and abs(dx) > 140 and abs(dy) < 110
                and random.random() < 0.35):
            me.facing = 1 if dx > 0 else -1           # 呪われたら、飛び道具でも呪い主に当てて解く
            me.special_neutral()
            return
        if mode == "portal" and me.special_cd == 0:   # ポータル(NEBULA)：入口を置いて、少し離れて出口を置く
            mine = [p for p in self.projs if p.owner is me and p.kind == "portal" and not p.dead]
            if not mine and 150 < abs(dx) < 520 and random.random() < 0.1:
                me.facing = 1 if dx > 0 else -1
                me.special_neutral()
                return
            if (len(mine) == 1 and 130 < abs(mine[0].x - mr.x) < 460 and abs(dx) < 450
                    and random.random() < 0.1):
                me.facing = 1 if dx > 0 else -1
                me.special_neutral()
                return

        if foe.invincible > 0:
            return
        if mode == "ward" and me.ward == 0 and me.special_cd == 0 and abs(dx) < 320 and random.random() < 0.05:
            me.special_neutral()                      # 相手が近くに来たら加護を張る
            return
        if mode == "orbit":
            if me.orbs_out == 0 and me.special_cd == 0 and abs(dx) < 480 and random.random() < 0.06:
                me.special_neutral()                  # 相手が近づいてきたらオーブを張る
                return
            if (me.orbs_out > 0 and me.det_cd == 0 and 90 < abs(dx) < 520 and abs(dy) < 150
                    and random.random() < 0.05):
                me.special_neutral()                  # 相手が中距離にいる時に撃ち出す
                return
        if (mode == "finisher" and me.special_cd == 0 and me.combo >= 2 and abs(dy) < 70
                and (me.combo >= 3 or me.combo_timer < 30)
                and abs(dx) < 60 + me.combo * 10 + n["speed"] * 6):
            me.facing = 1 if dx > 0 else -1           # スタックが貯まったら、近い相手にフィニッシャー
            me.special_neutral()
            return

        # 必殺技（飛び道具 / 罠 / 突進）
        if (mode == "tele" and me.special_cd == 0 and 100 < abs(dx) < n["range"] and abs(dy) < 100
                and random.random() < self.proj_rate * 1.5 and me.tele_target() is not None):
            me.special_neutral()                      # 相手の背後へ回り込む
            return
        if (mode == "shoot" and n["persist"] and me.mines_out >= 2 and me.det_cd == 0
                and self.mine_near_foe(me, foe) and random.random() < (0.5, 0.8, 1.0)[self.level]):
            me.special_neutral()                      # 地雷の爆風に相手が入った → 起爆！
            return
        if me.special_cd == 0 and random.random() < self.proj_rate:
            if mode == "shoot" and n.get("drop"):     # 雷は、落ちる場所に相手がいるとき
                if abs(abs(dx) - n["drop"][0]) < 70 and abs(dy) < 130:
                    me.facing = 1 if dx > 0 else -1
                    me.special_neutral()
                    return
            elif mode == "shoot" and n["kind"] == "geyser":    # 間欠泉は、噴き出す場所に相手がいる時
                if abs(abs(dx) - n["ahead"]) < 70 and abs(dy) < 90:
                    me.facing = 1 if dx > 0 else -1
                    me.special_neutral()
                    return
            elif mode == "shoot" and n["kind"] in STATIC_KINDS:   # 場/砲台/ばね/わなは、相手の前に置く
                if 60 < abs(dx) < 380 and abs(dy) < 100:
                    me.facing = 1 if dx > 0 else -1
                    me.special_neutral()
                    return
            elif mode == "shoot" and not n["persist"] and abs(dx) > 200 and abs(dy) < 120:
                me.facing = 1 if dx > 0 else -1
                me.special_neutral()
                return
            if mode == "shoot" and n["persist"] and me.mines_out < 2 and 60 < abs(dx) < 320 and abs(dy) < 100:
                me.facing = 1 if dx > 0 else -1       # 罠は、近づいてくる相手の前に置く
                me.special_neutral()
                return
            if mode == "rush" and n.get("hit") == "spin":    # 回転技は、近くにいる時に
                if abs(dx) < 100 and abs(dy) < 70:
                    me.facing = 1 if dx > 0 else -1
                    me.special_neutral()
                    return
            elif mode == "rush" and 140 < abs(dx) < 420 and abs(dy) < 60:
                me.facing = 1 if dx > 0 else -1
                me.special_neutral()
                return
            elif mode == "grab" and abs(dx) < 90 and abs(dy) < 60:   # つかみは、すぐ近くの相手に
                me.facing = 1 if dx > 0 else -1
                me.special_neutral()
                return

        # 相手がガード中は攻撃を控えめに
        if foe.guarding and random.random() < 0.6:
            return

        # 攻撃
        if random.random() < atk_rate:
            if (self.level >= 2 and me.on_ground and me.up_ready
                    and me.c["up_sp"]["kind"] in ("rise", "spin")
                    and abs(dx) < 60 and -170 < dy < -30 and random.random() < 0.3):
                me.special_up(inp)                    # 上必殺技で攻撃
            elif self.level >= 1 and abs(dx) < near_x and -up_reach < dy < -25:
                self._swing(me, foe, "up")
            elif (self.level >= 2 and not me.on_ground
                  and abs(dx) < near_x and 25 < dy < down_reach):
                me.attack("down")                     # 空中の下攻撃=メテオ
            elif side_lo <= abs(dx) <= side_hi and abs(dy) < 50:
                me.facing = 1 if dx > 0 else -1
                self._swing(me, foe, "side")


# ======================================================================
#  対戦
# ======================================================================
def make_fighters(i1, i2, cpu_level):
    c1, c2 = CHARS[i1], CHARS[i2]
    col2 = c2["color"]
    if i1 == i2:                                  # 同キャラなら P2 は暗い色
        col2 = tuple(int(v * 0.6) for v in col2)
    off = min(180, MAIN.w // 4)
    x1 = MAIN.centerx - off - c1["w"] // 2
    x2 = MAIN.centerx + off - c2["w"] // 2
    p1 = Fighter("P1", c1, c1["color"], x1, P1_KEYS)
    if cpu_level is None:
        p2 = Fighter("P2", c2, col2, x2, P2_KEYS)
    else:
        p2 = Fighter("CPU", c2, col2, x2, None, CPU(cpu_level))
    return [p1, p2]


class Match:
    def __init__(self, i1, i2, cpu_level, stage_idx=0, use_items=False):
        set_stage(STAGES[stage_idx])
        self.fighters = make_fighters(i1, i2, cpu_level)
        self.fighters[0].foe = self.fighters[1]
        self.fighters[1].foe = self.fighters[0]
        self.hz_timer = random.randint(150, 260)    # 落雷までの時間
        self.bolts = BOLTS
        self.projs = []
        self.items = []
        self.use_items = use_items
        self.item_timer = random.randint(300, 480)
        self.tick = 0
        self.winner = None
        self.cam = Camera(self.fighters)

    def move_platforms(self):
        """動く足場を動かす（上に乗っている人も一緒に運ぶ）。一時的な足場の寿命も数える"""
        self.tick += 1
        for mvr in MOVERS:
            r = mvr["rect"]
            off = mvr["amp"] * math.sin(self.tick * mvr["spd"] + mvr["ph"])
            nx = mvr["bx"] + (off if mvr["ax"] == "x" else 0)
            ny = mvr["by"] + (off if mvr["ax"] == "y" else 0)
            nx, ny = int(round(nx)), int(round(ny))
            dx, dy = nx - r.x, ny - r.y
            if dx or dy:
                for f in self.fighters:
                    if (f.on_ground and abs((f.y + f.h) - r.top) < 1.5
                            and f.x < r.right and r.left < f.x + f.w):
                        f.x += dx
                        f.y += dy
                r.x, r.y = nx, ny
        if BELT:                                     # ベルトコンベア：床の上の人を運ぶ
            bdir = 1 if (self.tick // BELT["period"]) % 2 == 0 else -1
            for f in self.fighters:
                if (f.on_ground and f.ledge is None and f.climb_left == 0
                        and abs((f.y + f.h) - MAIN.top) < 1.5
                        and f.x < MAIN.right and MAIN.left < f.x + f.w):
                    f.x += bdir * BELT["speed"]
        for tp in TEMPS[:]:
            tp[1] -= 1
            if tp[1] <= 0:
                TEMPS.remove(tp)
                if tp[0] in THIN:
                    THIN.remove(tp[0])

    def update_hazard(self):
        """落雷：予告の線が出て、少し後に落ちる"""
        if not HAZARD:
            return
        self.hz_timer -= 1
        if self.hz_timer <= 0:
            lo, hi = HAZARD["every"]
            self.hz_timer = random.randint(lo, hi)
            tgt = random.choice(self.fighters)
            if random.random() < 0.6:                 # 6割は、だれかを狙う
                x = tgt.x + tgt.w / 2 + random.randint(-50, 50)
            else:
                x = random.randint(MAIN.left + 20, MAIN.right - 20)
            x = max(MAIN.left - 40, min(MAIN.right + 40, x))
            self.bolts.append(dict(x=x, t=HAZARD["warn"], hit=[]))
        for b in self.bolts[:]:
            b["t"] -= 1
            if b["t"] < -10:
                self.bolts.remove(b)
                continue
            if b["t"] <= 0:
                zone = pygame.Rect(int(b["x"]) - 36, MAIN.top - 1000, 72, 1040)
                for f in self.fighters:
                    if f not in b["hit"] and f.rect.colliderect(zone):
                        b["hit"].append(f)
                        f.take_bolt(b["x"])

    def swap_positions(self, a, b):
        """aとbの場所を入れ替える（足の位置をそろえる）。bは少し怯み、aは短い無敵"""
        ac = (a.x + a.w / 2, a.y + a.h)
        bc = (b.x + b.w / 2, b.y + b.h)
        a.release_ledge()
        a.x, a.y = bc[0] - a.w / 2, bc[1] - a.h
        b._hurt(10)
        b.x, b.y = ac[0] - b.w / 2, ac[1] - b.h
        for f in (a, b):
            f.vx = f.vy = 0.0
            f.on_ground = False
        a.invincible = max(a.invincible, 20)
        a.ghost_timer = max(a.ghost_timer, 20)
        a.cast_timer = 12

    def make_portals(self, owner, a, b, life):
        """出入口のポータルを2つ作る。古い自分のポータルは消える"""
        for p in self.projs:
            if p.owner is owner and p.kind == "portal":
                p.dead = True
        pa = Projectile(owner, a[0], a[1], 0.0, 0.0, 36, 76, 0, 0.0, life,
                        color=(90, 170, 255), kind="portal")
        pb = Projectile(owner, b[0], b[1], 0.0, 0.0, 36, 76, 0, 0.0, life,
                        color=(255, 150, 60), kind="portal")
        pb.phase = 1.0
        pa.mate, pb.mate = pb, pa
        self.projs.extend([pa, pb])

    def place_portal(self, f):
        """NEBULA：1回目=入口 / 2回目=出口 / 3回目=全部消す。床の上にしか置けない"""
        n = f.c["neutral"]
        mine = [p for p in self.projs if p.owner is f and p.kind == "portal" and not p.dead]
        if len(mine) >= 2:
            for p in mine:
                p.dead = True
            f.special_cd = 40
            return
        side = 1 if f.facing > 0 else -1
        px = f.x + f.w / 2 + side * n["dist"]
        if mine:                                      # 出口は、入口から離れた所に置く
            ax = mine[0].x + mine[0].w / 2
            if abs(px - ax) < n["gap"]:
                px = ax + (1 if px >= ax else -1) * n["gap"]
        fl = f.floor_below(px)
        if fl is None:                                # 足場がない所には置けない(待ち時間もなし)
            f.special_cd = 0
            return
        pr = Projectile(f, px, fl - 38, 0.0, 0.0, 36, 76, 0, 0.0, int(n["life"]),
                        color=(90, 170, 255), kind="portal")
        if mine:
            pr.phase = 1.0
            pr.color = (255, 150, 60)
            pr.mate = mine[0]
            mine[0].mate = pr
        self.projs.append(pr)

    def use_portal(self, pr, m):
        """ポータルpr に触れた人・飛び道具を、もう片方 m の位置へ送る（だれでも通れる）"""
        pc = pr.rect
        for f in self.fighters:
            if (f.portal_cd == 0 and f.ledge is None and f.climb_left == 0
                    and f.rect.colliderect(pc)):
                dy = f.rect.centery - pc.centery
                f.x = m.x + m.w / 2 - f.w / 2
                f.y = m.y + m.h / 2 + dy - f.h / 2
                f.portal_cd = PORTAL_CD
                f.cast_timer = 8
        for q in self.projs:
            if (q.kind in ("normal", "ball") and not q.dead and q.pcd == 0 and q.exploding == 0
                    and q.rect.colliderect(pc)):
                d = 1 if q.vx >= 0 else -1
                q.x = m.x + m.w / 2 - q.w / 2 + d * 26
                q.y = m.y + m.h / 2 - q.h / 2
                q.by = q.y
                q.pcd = 30

    def mine_triggers(self):
        """置いてある地雷は、相手の飛び道具・爆発・近接攻撃に触れると爆発する（MAGENTA）"""
        if not (MINE_SHOT_DETONATE or MINE_MELEE_DETONATE):
            return
        p1, p2 = self.fighters
        for m in self.projs:
            if m.kind != "bomb" or not m.persist or m.exploding > 0 or m.dead or m.age < m.arm:
                continue
            hit = False
            if MINE_SHOT_DETONATE:
                for pr in self.projs:
                    if pr is m or pr.owner is m.owner or pr.dead:
                        continue
                    if pr.kind in STATIC_KINDS or pr.kind == "orbit":
                        continue
                    if pr.kind == "bomb" and pr.exploding == 0:      # 置いてあるだけの爆弾は無視
                        continue
                    if pr.rect.colliderect(m.rect):
                        hit = True
                        if pr.kind != "bomb" and not pr.pierce:
                            pr.dead = True                           # ふつうの弾は、地雷に当たって消える
                        break
            if not hit and MINE_MELEE_DETONATE:
                foe = p2 if m.owner is p1 else p1
                hb = foe.hitbox()
                if hb is not None and hb.colliderect(m.rect):
                    hit = True
            if hit:
                m.explode()

    def separate_fighters(self):
        """2人の体が重なっていたら、横にお互いを押し出して離す(めり込み防止)。
        壁やステージにめり込む方向へは押さず、その分は相手側へ回す。
        すり抜けダッシュ中(ghost)・崖つかまり中・ワープで消えている間は、すり抜けたままにする"""
        a, b = self.fighters
        for f in (a, b):
            if f.ghost_timer > 0 or f.ledge is not None or f.tele_wait > 0:
                return
        ox = min(a.x + a.w, b.x + b.w) - max(a.x, b.x)
        oy = min(a.y + a.h, b.y + b.h) - max(a.y, b.y)
        if ox <= 0 or oy <= 4:                        # 重なっていない / 上を足がかすっただけ
            return
        ca, cb = a.x + a.w / 2, b.x + b.w / 2
        d = 1 if ca > cb else -1 if ca < cb else (1 if a.start_x > b.start_x else -1)
        push = min(ox, 40.0)                          # 一気に大きく動かさない(生まれた直後などの対策)
        half = push / 2 + 0.01

        def blocked(f):
            return any(f.overlaps(s) for s in SOLID)

        a.x += d * half
        b.x -= d * half
        ba, bb = blocked(a), blocked(b)
        if ba and not bb:                             # aが壁にめり込む → aは戻して、bに全部押してもらう
            a.x -= d * half
            b.x -= d * half
            if blocked(b):
                b.x += d * half * 2
        elif bb and not ba:
            b.x += d * half
            a.x += d * half
            if blocked(a):
                a.x -= d * half * 2
        elif ba and bb:                               # 両方ふさがれている(壁と壁の間)：動かさない
            a.x -= d * half
            b.x += d * half

    def step(self):
        """1フレーム進める。"""
        p1, p2 = self.fighters
        self.move_platforms()
        self.update_hazard()
        pressed = pygame.key.get_pressed()
        for f in self.fighters:
            foe = p2 if f is p1 else p1
            if f.cpu:
                inp = f.cpu.think(f, foe, self.projs, self.items)
            else:
                inp = human_input(f.keys, pressed)
            f.mines_out = sum(1 for p in self.projs
                              if p.owner is f and p.persist and not p.dead and p.exploding == 0)
            f.portals_out = sum(1 for p in self.projs
                                if p.owner is f and p.kind == "portal" and not p.dead)
            f.update(inp)
            f.orbs_out = sum(1 for p in self.projs if p.owner is f and p.kind == "orbit" and not p.dead)
            if f.launch_orbs:                         # オーブを相手めがけて撃ち出す(COMET)
                f.launch_orbs = False
                nn = f.c["neutral"]
                for p in self.projs:
                    if p.owner is f and p.kind == "orbit" and not p.dead:
                        cx, cy = p.rect.center
                        ddx, ddy = foe.rect.centerx - cx, foe.rect.centery - cy
                        dd = max(1.0, math.hypot(ddx, ddy))
                        p.kind = "normal"
                        p.vx = ddx / dd * nn["launch_speed"]
                        p.vy = ddy / dd * nn["launch_speed"]
                        p.vx0 = p.vx
                        p.by = p.y
                        p.gravity = 0.0
                        p.damage = nn["launch_dmg"]
                        p.power = nn["launch_kb"]
                        p.pierce = False
                        p.rehit = 0
                        p.hit_cd = 0
                        p.hit_done = False
                        p.life = 70
            if f.portal_req:                          # ポータルを置く(NEBULA)
                f.portal_req = False
                self.place_portal(f)
            if f.gate_req:                            # ゲートジャンプの出入口(NEBULA)
                ax, ay, bx, by = f.gate_req
                f.gate_req = None
                self.make_portals(f, (ax, ay), (bx, by), 260)
            if f.detonate:                            # 地雷を全部起爆
                f.detonate = False
                for p in self.projs:
                    if p.owner is f and p.persist and p.exploding == 0 and not p.dead:
                        p.explode()
            if f.shots:
                for sh in f.shots:                    # 砲台は、1人につき1つだけ(置き直すと古い方が消える)
                    if sh.kind in ("turret", "snare", "orbit"):
                        self.projs = [q for q in self.projs
                                      if not (q.kind == sh.kind and q.owner is f)]
                self.projs.extend(f.shots)
                f.shots.clear()
                mines = [p for p in self.projs if p.owner is f and p.persist and not p.dead]
                while len(mines) > 2:                 # 罠は最大2個。古いものから消える
                    mines.pop(0).dead = True

        # アイテム
        if self.use_items:
            self.item_timer -= 1
            if self.item_timer <= 0:
                self.item_timer = random.randint(600, 900)
                if len(self.items) < 3:
                    x = random.randint(MAIN.left + 30, MAIN.right - 60)
                    kind = random.choices(ITEM_KINDS, weights=[ITEM_WEIGHTS[k] for k in ITEM_KINDS])[0]
                    self.items.append(Item(kind, x, MAIN.top - 450))
            for it in self.items[:]:
                it.update()
                if it.dead:
                    self.items.remove(it)
                    continue
                for f in self.fighters:
                    if f.rect.colliderect(it.rect):
                        f.apply_item(it.kind, p2 if f is p1 else p1)
                        self.items.remove(it)
                        break

        self.separate_fighters()                      # キャラ同士はめり込まない（押し合う）

        # 近接攻撃の当たり判定（多段攻撃は間隔をあけて何度も当たる）
        for a, b in ((p1, p2), (p2, p1)):
            hb = a.hitbox()
            if (hb and a.hits_left > 0 and a.hit_gap == 0
                    and b.invincible == 0 and hb.colliderect(b.rect)):
                a.hits_left -= 1
                a.hit_gap = a.hit_every
                if a.hex_timer > 0 and a.hex_by is b:     # 呪い主に攻撃を当てれば、呪いは解ける(RAVEN)
                    a.hex_timer = 0
                    a.hex_by = None
                    a.hex_pop = 18
                if b.counter_timer > 0:
                    b.do_counter(a)                   # カウンター！
                    continue
                if b.ward > 0 and (not b.guarding or a.atk_grab):
                    b.pop_ward(a)                     # 加護(PEARL)：この攻撃は無効。攻撃した側が弾かれる
                    continue
                if b.guarding and a.atk_grab:
                    b.guarding = False                # つかみはガードを貫通する
                    b.shield = max(0.0, b.shield - 25)
                elif b.guarding:
                    b.block(a.out_dmg(), a.rect.centerx)
                    continue
                if a.hits_left == 0:
                    dm, km = 1.0, 1.0
                    hk = a.c.get("hunter")
                    if hk and b.mark_timer > 0:           # 印がついた相手(HAZEL)：強く当たる
                        dm, km = dm * hk["mult"], km * 1.1
                    bs = a.c.get("backstab", 0)
                    if bs and b.facing == a.atk_facing:   # 背後からの一撃(SCARLET)：強い
                        dm, km = dm * bs, km * 1.2
                    sw = a.c.get("sweet")
                    if sw and a.atk_dir == "side" and a.sp_timer == 0:   # 先端の当たり(IVORY)：先は強く、懐は弱い
                        tip = sweet_tip(hb, a.atk_facing, sw["zone"])
                        if tip.colliderect(b.rect):
                            dm, km = dm * sw["dmg"], km * sw["kb"]
                        else:
                            dm, km = dm * sw["lo_dmg"], km * sw["lo_kb"]
                    o_dmg, o_kb = a.atk_dmg, a.atk_kb
                    a.atk_dmg = max(1, int(round(a.atk_dmg * dm)))
                    a.atk_kb *= km
                    b.take_hit(a)                     # 最後の1発で吹っ飛ばす
                    a.atk_dmg, a.atk_kb = o_dmg, o_kb
                else:
                    b.take_light_hit(a)
                if a.atk_root:                        # 足をからめる(MOSS)
                    b.root_timer = max(b.root_timer, a.atk_root)
                if a.atk_chill:                       # 冷え：しばらく動きが遅くなる
                    b.chill_timer = max(b.chill_timer, a.atk_chill)
                if a.atk_burn:                        # 燃焼：しばらく%がじわじわ増える
                    b.burn_timer = max(b.burn_timer, a.atk_burn)
                leech = a.c.get("leech", 0)
                if leech:                             # 吸血：当てたぶん回復
                    a.percent = max(0, a.percent - max(1, int(round(a.out_dmg() * leech))))
                if a.atk_crit and a.hits_left == 0:   # 大当たり(GOLD)：当てると自分の%も回復
                    a.percent = max(0, a.percent - 6)
                if a.c.get("combo") and a.fin_t == 0: # コンボ(BRONZE)：当てるたびにスタック+1
                    a.combo = min(5, a.combo + 1)
                    a.combo_timer = 150

        # 打ち返し(AMBER)：バットの判定に触れた相手の飛び道具は、持ち主が変わって飛んでいく
        for a, b in ((p1, p2), (p2, p1)):
            if not a.atk_reflect:
                continue
            hb = a.hitbox()
            if hb is None:
                continue
            for pr in self.projs:
                if pr.owner is not b or pr.dead or pr.kind in STATIC_KINDS or pr.kind == "orbit":
                    continue
                if pr.kind == "bomb" or pr.exploding > 0 or not pr.rect.colliderect(hb):
                    continue
                pr.owner = a
                pr.vx = a.atk_facing * max(abs(pr.vx), 9.0) * 1.25
                pr.vx0 = pr.vx
                pr.vy = 0.0
                pr.by = pr.y
                if pr.kind != "ball":
                    pr.gravity = 0.0
                if pr.boomerang:
                    pr.bacc = -2.0 * pr.vx / pr.boomerang
                    pr.turned = False
                pr.damage = int(pr.damage * 1.3) + 1
                pr.life = max(pr.life, 50)
                pr.hit_done = False
                pr.hit_cd = 0

        self.mine_triggers()

        # 飛び道具
        for pr in self.projs[:]:
            pr.update()
            target = p2 if pr.owner is p1 else p1
            if pr.dead:
                self.projs.remove(pr)
                continue
            if pr.kind == "portal":               # ポータル：片方がなくなったら、もう片方も消える
                m = pr.mate
                if m is not None and m.dead:
                    self.projs.remove(pr)
                elif m is not None:
                    self.use_portal(pr, m)
                continue
            if pr.kind == "orbit":                # オーブ：相手の飛び道具を1つ吸い込んで消える
                for q in self.projs:
                    if (q.owner is not pr.owner and not q.dead and q.kind not in STATIC_KINDS
                            and q.kind not in ("bomb", "orbit") and q.rect.colliderect(pr.rect)):
                        q.dead = True
                        pr.dead = True
                        break
                if pr.dead:
                    continue
            if pr.kind == "spring":               # ばね：上から乗ると高くはね上げる(だれでも)
                for f in self.fighters:
                    if (f.rm is None and f.ledge is None and f.vy >= 0
                            and f.rect.colliderect(pr.rect) and f.rect.bottom <= pr.rect.bottom + 4):
                        f.vy = -17.0
                        f.on_ground = False
                        f.glide_timer = 0
                        pr.uses += 1
                        if pr.launch_atk and pr.owner is f:      # スプリングキック：上昇中は攻撃判定つき
                            ku = f.c["up_sp"]
                            f.begin_active("rise", int(ku["kick_frames"]), ku["kick_dmg"], ku["kick_kb"])
                if pr.uses >= pr.max_uses:
                    self.projs.remove(pr)
                continue
            if pr.kind == "geyser":               # 間欠泉：予告のあと噴き上げて、真上へ打ち上げる
                if (22 <= pr.age <= 48 and not pr.hit_done and target.invincible == 0
                        and pr.rect.colliderect(target.rect)):
                    pr.hit_done = True
                    if target.counter_timer > 0:
                        continue
                    if target.guarding:
                        target.block(int(pr.damage * pr.owner.pmult()), pr.rect.centerx)
                    else:
                        target.take_geyser(pr)
                continue
            if pr.kind == "snare":                # イバラのわな：踏むと、しばらく地上で動けない
                if (pr.age >= pr.arm and target.invincible == 0
                        and pr.rect.colliderect(target.rect)):
                    self.projs.remove(pr)
                    target.root_timer = max(target.root_timer, 90)
                    if not target.guarding and target.counter_timer == 0:
                        target.gain(pr.damage * pr.owner.pmult())
                        if not target.armored():
                            target._hurt(14)
                            target.vx = 0.0
                            target.vy = -2.0
                continue
            if pr.kind == "turret":               # 砲台：自動で撃つ。相手の攻撃判定が触れると壊れる
                hb = target.hitbox()
                if hb is not None and hb.colliderect(pr.rect):
                    self.projs.remove(pr)
                    continue
                tdx = target.rect.centerx - pr.rect.centerx
                tdy = target.rect.centery - pr.rect.centery
                if pr.age % 50 == 30 and abs(tdx) < 650 and abs(tdy) < 230:
                    d = 1 if tdx >= 0 else -1
                    self.projs.append(Projectile(pr.owner, pr.rect.centerx + d * 18,
                                                 pr.rect.y + 10, d * 9.0, 0.0, 18, 10, 3, 0.5, 55,
                                                 color=pr.color))
                continue
            if pr.kind == "zone":                 # タイムフィールド：相手は遅く、持ち主は速くなる
                if target.rect.colliderect(pr.rect):
                    target.chill_timer = max(target.chill_timer, 25)
                if pr.owner.rect.colliderect(pr.rect):
                    pr.owner.speed_timer = max(pr.owner.speed_timer, 3)
                continue
            if pr.kind == "bomb":                 # 爆弾/罠：触れると爆発、爆発は1回だけ当たる
                if (pr.exploding == 0 and pr.age >= pr.arm and target.invincible == 0
                        and pr.rect.colliderect(target.rect)):
                    pr.explode()
                if (pr.exploding > 0 and not pr.hit_done and target.invincible == 0
                        and pr.rect.colliderect(target.rect)):
                    pr.hit_done = True
                    d = 1 if target.rect.centerx >= pr.rect.centerx else -1
                    if target.counter_timer > 0:
                        continue
                    if target.guarding:
                        target.block(int(pr.damage * pr.owner.pmult()), pr.rect.centerx)
                    else:
                        target.take_proj(pr, d, explosion=True)
                continue
            if pr.hit_done or not pr.rect.colliderect(target.rect):
                continue
            if target.counter_timer > 0:          # カウンター構えは、飛び道具を跳ね返す
                pr.owner = target
                pr.vx = -pr.vx
                pr.vx0 = -pr.vx0                  # ブーメランも向きを反転
                pr.bacc = -pr.bacc
                pr.damage = int(pr.damage * 1.3) + 1
                continue
            if target.invincible == 0:
                if pr.owner.hex_timer > 0 and pr.owner.hex_by is target:   # 飛び道具でも解ける
                    pr.owner.hex_timer = 0
                    pr.owner.hex_by = None
                    pr.owner.hex_pop = 18
                if target.guarding:
                    target.block(int(pr.damage * pr.owner.pmult()), pr.x)
                elif target.ward > 0:
                    target.pop_ward(None)                 # 加護(PEARL)：飛び道具も1回無効
                elif pr.swap:                         # 入れ替えオーブ：位置が入れ替わる
                    target.gain(pr.damage)
                    self.swap_positions(pr.owner, target)
                else:
                    if pr.vx:
                        dirn = 1 if pr.vx > 0 else -1
                    else:                             # 真上から落ちる雷は、中心から外へ
                        dirn = 1 if target.rect.centerx >= pr.rect.centerx else -1
                    hk = pr.owner.c.get("hunter")
                    od = pr.damage
                    if hk and target.mark_timer > 0:      # 印がついた相手(HAZEL)：矢も強く当たる
                        pr.damage = max(pr.damage + 1, int(round(pr.damage * hk["mult"])))
                    target.take_proj(pr, dirn)
                    pr.damage = od
                    if pr.hex and target.hex_timer == 0:      # 呪いの弾(RAVEN)：当たると呪われる
                        hx = pr.owner.c.get("hex") or HEX_DEFAULT
                        target.hex_timer = int(hx["frames"])
                        target.hex_by = pr.owner
                    if hk:
                        target.mark_timer = hk["frames"]  # 矢が当たると印がつく(つけ直すと時間が戻る)
                    if pr.chill:
                        target.chill_timer = max(target.chill_timer, pr.chill)
                    if pr.burn:
                        target.burn_timer = max(target.burn_timer, pr.burn)
                    if pr.confuse and random.random() < pr.confuse_chance:
                        target.confuse_timer = max(target.confuse_timer, pr.confuse)
                    lk = pr.owner.c.get("leech", 0)
                    if lk:                            # 飛び道具でも吸血（近接の半分）
                        pr.owner.percent = max(0, pr.owner.percent
                                               - max(1, int(round(pr.damage * lk * 0.5))))
                if pr.pierce:
                    pr.hit_done = True                # 貫通する飛び道具は、突き抜ける
                    pr.hit_cd = pr.rehit              # (rehitがあれば一定時間後に当たり直す)
                else:
                    self.projs.remove(pr)

        # 場外判定
        for f in self.fighters:
            if f.is_out():
                self.projs = [q for q in self.projs if not (q.owner is f and q.kind == "orbit")]
                f.stocks -= 1
                if f.stocks <= 0:
                    self.winner = p2 if f is p1 else p1
                else:
                    f.respawn()
                o = p2 if f is p1 else p1
                if o.hex_by is f:                     # 呪い主がやられたら、呪いは消える
                    o.hex_timer = 0
                    o.hex_by = None
        self.cam.update(self.fighters)


# ======================================================================
#  描画
# ======================================================================
def draw_text(screen, font, text, color, center):
    surf = font.render(text, True, color)
    screen.blit(surf, surf.get_rect(center=center))


def draw_text_fit(screen, font, text, color, center, maxw):
    """maxw に収まらない時は、文字を縮めて表示する"""
    surf = font.render(text, True, color)
    if surf.get_width() > maxw:
        h = max(1, int(surf.get_height() * maxw / surf.get_width()))
        surf = pygame.transform.smoothscale(surf, (maxw, h))
    screen.blit(surf, surf.get_rect(center=center))


def sweet_tip(hb, facing, zone):
    """攻撃判定のうち、先端(スイートスポット)の部分の四角"""
    tw = max(1, int(hb.w * zone))
    return pygame.Rect(hb.right - tw if facing > 0 else hb.x, hb.y, tw, hb.h)


def draw_bar(screen, font, x, y, label, frac, width=120, label_w=66):
    screen.blit(font.render(label, True, (200, 200, 210)), (x, y - 3))
    pygame.draw.rect(screen, (60, 64, 85), (x + label_w, y, width, 7), border_radius=4)
    pygame.draw.rect(screen, (120, 200, 255),
                     (x + label_w, y, int(width * max(0.05, min(1, frac))), 7), border_radius=4)


def items_label(use_items):
    return "ITEMS: " + ("ON" if use_items else "OFF")


def draw_mode(screen, fonts, use_items):
    draw_text(screen, fonts["title"], "Pythonic Brothers in the Clouds", (255, 255, 255), (W // 2, 105))
    items = ["1   VS CPU  (EASY)", "2   VS CPU  (NORMAL)",
             "3   VS CPU  (HARD)", "4   2 PLAYERS"]
    for i, t in enumerate(items):
        draw_text(screen, fonts["big"], t, (255, 230, 120), (W // 2, 205 + i * 58))
    col = (120, 230, 140) if use_items else (230, 120, 120)
    draw_text(screen, fonts["mid"], "I   " + items_label(use_items), col, (W // 2, 450))
    draw_text(screen, fonts["small"], "Press a number key   /   I: items on/off   /   ESC: quit",
              (190, 190, 205), (W // 2, 488))
    hints = ["P1:  A D = move   W = jump   S = drop   F = attack   G = special   H = guard",
             "P2:  arrows = move/jump/drop   / = attack   . = special   , = guard",
             "Attack + Jump key = up attack      Attack + Down key = down attack "
             "(in the air = METEOR)",
             "Special + Jump key = recovery move (once per air time)      P = pause",
             "Hold Guard + Left/Right = ROLL      Guard + Down = SPOT DODGE   (invincible!)",
             "Ledge: fall near a stage edge to grab it.  Toward stage = climb   "
             "Jump = ledge jump   Attack = ledge attack   Down = let go"]
    for i, t in enumerate(hints):
        draw_text(screen, fonts["small"], t, (150, 150, 170), (W // 2, 535 + i * 25))


def grid_move(i, step, total, cols):
    """キャラ選択の上下移動。step=+1で下の段、-1で上の段。端まで行くと同じ列で反対側へ回り込む"""
    col = i % cols
    if step > 0:
        j = i + cols
        return j if j < total else col
    j = i - cols
    if j >= 0:
        return j
    last = col
    while last + cols < total:
        last += cols
    return last


def select_cols(total):
    """キャラ選択の1段あたりの数(RANDOMを含む総数 total を SELECT_ROWS 段に収める)"""
    return -(-total // SELECT_ROWS)


def pick_index(i, n):
    """RANDOM(= n番目)なら、ランダムに1つ選ぶ"""
    return i if i < n else random.randrange(n)


def draw_char_panel(screen, fonts, x, y, w, h, idx, label, color, locked):
    pygame.draw.rect(screen, (45, 50, 72), (x, y, w, h), border_radius=12)
    pygame.draw.rect(screen, color, (x, y, w, h), width=3, border_radius=12)
    draw_text(screen, fonts["mid"], label + ("  OK!" if locked else ""), color, (x + 80, y + 24))
    if idx >= len(CHARS):
        draw_text(screen, fonts["big"], "RANDOM", (255, 255, 255), (x + w // 2, y + 100))
        draw_text(screen, fonts["small"], "A surprise fighter is chosen for you!",
                  (200, 200, 215), (x + w // 2, y + 150))
        return
    c = CHARS[idx]
    base = y + 150
    body = pygame.Rect(x + 70 - c["w"] // 2, base - c["h"], c["w"], c["h"])
    draw_body(screen, body, c["color"], 1)
    tx = x + 150
    draw_text(screen, fonts["mid"], c["name"] + "  -  " + c["desc"], ui_color(c["color"]),
              (tx + 190, y + 24))
    lines = [("ATK: " + c["trait"], (170, 230, 170)),
             ("SP: " + c["neutral"]["name"], (255, 200, 120)),
             ("UP+SP: " + c["up_sp"]["name"], (255, 200, 120))]
    for j, (t, col) in enumerate(lines):
        draw_text(screen, fonts["small"], t, col, (tx + 130, y + 62 + j * 24))
    sd = c["side"]
    bars = [("SPEED", c["run"] / 8),
            ("POWER", sd["dmg"] * sd["hits"] * sd["kb"] / 17.6),
            ("REACH", (sd["reach"] + sd["gap"]) / 115),
            ("WEIGHT", c["weight"] / 1.45),
            ("JUMP", c["jump"] * c["jumps"] / 52)]
    for j, (lab, fr) in enumerate(bars):
        draw_bar(screen, fonts["small"], tx, y + 150 + j * 22, lab, fr, width=200, label_w=80)


def draw_select(screen, fonts, sel, locked, cpu_level):
    draw_text(screen, fonts["big"], "SELECT FIGHTER", (255, 255, 255), (W // 2, 34))
    p2_label = "CPU" if cpu_level is not None else "P2"
    sub = ("P1: A D W S choose, F confirm        " + p2_label
           + ": Arrow keys choose, / confirm        ESC: back")
    draw_text(screen, fonts["small"], sub, (190, 190, 205), (W // 2, 72))

    n = len(CHARS) + 1                                 # 最後はRANDOM
    cols, gap, ch = select_cols(n), 3, 138
    cw = min(64, (W - 40 - (cols - 1) * gap) // cols)   # 画面の幅に収まるようにタイルの幅を決める
    start = (W - (cols * cw + (cols - 1) * gap)) // 2
    colors = [(255, 120, 120), (120, 160, 255)]
    for i in range(n):
        row, col = divmod(i, cols)
        x = start + col * (cw + gap)
        top = 96 + row * (ch + 10)
        pygame.draw.rect(screen, (45, 50, 72), (x, top, cw, ch), border_radius=10)
        if i < len(CHARS):
            c = CHARS[i]
            body = pygame.Rect(x + cw // 2 - c["w"] // 2, top + 90 - c["h"], c["w"], c["h"])
            draw_body(screen, body, c["color"], 1)
            draw_text_fit(screen, fonts["tiny"], c["name"], ui_color(c["color"]),
                          (x + cw // 2, top + 108), cw - 6)
            draw_text_fit(screen, fonts["micro"], c["desc"], (190, 190, 205),
                          (x + cw // 2, top + 126), cw - 6)
        else:
            draw_text(screen, fonts["huge"], "?", (255, 255, 255), (x + cw // 2, top + 55))
            draw_text_fit(screen, fonts["tiny"], "RANDOM", (255, 230, 120),
                          (x + cw // 2, top + 108), cw - 6)
        for p in range(2):
            if sel[p] == i:
                off = p * 4
                pygame.draw.rect(screen, colors[p],
                                 (x - 3 - off, top - 3 - off, cw + 6 + 2 * off, ch + 6 + 2 * off),
                                 width=3, border_radius=12)

    py = 96 + 2 * (ch + 10) + 14
    pw = (W - 3 * 40) // 2
    draw_char_panel(screen, fonts, 40, py, pw, 270, sel[0], "P1", colors[0], locked[0])
    draw_char_panel(screen, fonts, 80 + pw, py, pw, 270, sel[1], p2_label, colors[1], locked[1])


def draw_stage_preview(screen, st, box):
    pygame.draw.rect(screen, (24, 27, 42), box, border_radius=6)
    sc = box.w / 1280.0

    def tr(r):
        return pygame.Rect(int(box.x + r.x * sc), int(box.y + (r.y - 80) * sc),
                           max(2, int(r.w * sc)), max(2, int(r.h * sc)))
    pygame.draw.rect(screen, (95, 150, 105), tr(st["main"]))
    for r in st.get("solids", []):
        pygame.draw.rect(screen, (120, 130, 150), tr(r))
    moving = set(m["i"] for m in st.get("movers", []))
    for i, t in enumerate(st["thin"]):
        pygame.draw.rect(screen, (130, 170, 235) if i in moving else (110, 190, 120), tr(t))


def draw_stage_select(screen, fonts, idx, use_items):
    draw_text(screen, fonts["big"], "SELECT STAGE", (255, 255, 255), (W // 2, 40))
    draw_text(screen, fonts["small"],
              "Arrow keys / WASD: choose     F or / : start     I: items on/off     ESC: back",
              (190, 190, 205), (W // 2, 76))
    n = len(STAGES) + 1                                # 最後はRANDOM
    cols, cw, gap, ch, top0 = 7, 164, 12, 186, 100
    start = (W - (cols * cw + (cols - 1) * gap)) // 2
    for i in range(n):
        row, col = divmod(i, cols)
        x = start + col * (cw + gap)
        top = top0 + row * (ch + 14)
        pygame.draw.rect(screen, (45, 50, 72), (x, top, cw, ch), border_radius=12)
        cxm = x + cw // 2
        if i < len(STAGES):
            st = STAGES[i]
            draw_stage_preview(screen, st, pygame.Rect(x + 10, top + 10, cw - 20, 74))
            draw_text_fit(screen, fonts["small"], st["name"], (255, 255, 255), (cxm, top + 100), cw - 8)
            draw_text_fit(screen, fonts["tiny"], st["desc"], (210, 210, 220), (cxm, top + 124), cw - 8)
            draw_text_fit(screen, fonts["tiny"], st["note"], (170, 230, 170), (cxm, top + 146), cw - 8)
            draw_text_fit(screen, fonts["tiny"], "Width %d  /  KO zone %d" % (st["main"].w, st["blast"].w),
                          (200, 180, 160), (cxm, top + 166), cw - 8)
        else:
            draw_text(screen, fonts["huge"], "?", (255, 255, 255), (cxm, top + 60))
            draw_text(screen, fonts["mid"], "RANDOM", (255, 230, 120), (cxm, top + 124))
            draw_text(screen, fonts["tiny"], "Any stage!", (210, 210, 220), (cxm, top + 156))
        if i == idx:
            pygame.draw.rect(screen, (255, 230, 120), (x - 4, top - 4, cw + 8, ch + 8),
                             width=4, border_radius=14)
    col = (120, 230, 140) if use_items else (230, 120, 120)
    draw_text(screen, fonts["big"], items_label(use_items), col, (W // 2, 560))
    draw_text(screen, fonts["small"], "(press I to toggle)", (170, 170, 190), (W // 2, 604))


def draw_hud(screen, f, x, fonts):
    g = max(0, 255 - f.percent * 2)
    screen.blit(fonts["small"].render(f"{f.tag}  {f.c['name']}", True, ui_color(f.color)), (x, H - 130))
    screen.blit(fonts["big"].render(f"{f.percent}%", True, (255, g, g)), (x, H - 105))
    for i in range(f.stocks):
        pygame.draw.circle(screen, ui_color(f.color), (x + 150 + i * 26, H - 82), 9)
    # シールドの残量
    pygame.draw.rect(screen, (60, 64, 85), (x, H - 45, 130, 8), border_radius=4)
    pygame.draw.rect(screen, (120, 200, 255), (x, H - 45, int(130 * f.shield / 100), 8),
                     border_radius=4)
    screen.blit(fonts["small"].render("SHIELD", True, (150, 150, 170)), (x + 140, H - 50))
    # アイテム効果の残り時間
    if f.power_timer > 0:
        pygame.draw.rect(screen, (240, 90, 70), (x, H - 32, int(130 * f.power_timer / 600), 6))
    if f.speed_timer > 0:
        pygame.draw.rect(screen, (90, 160, 255), (x, H - 24, int(130 * f.speed_timer / 600), 6))
    if f.barrier_timer > 0:
        pygame.draw.rect(screen, (80, 210, 200), (x, H - 16, int(130 * f.barrier_timer / 540), 6))
    if f.wing_timer > 0:
        pygame.draw.rect(screen, (255, 205, 245), (x, H - 8, int(130 * f.wing_timer / 720), 6))


def draw_game(screen, fonts, m):
    cam = m.cam
    s = cam.s
    screen.fill(STAGE_BG)
    pygame.draw.rect(screen, (95, 55, 70), cam.rect(BLAST), width=2)   # 死亡ライン
    r = cam.rect(MAIN)
    pygame.draw.rect(screen, (95, 150, 105), r, border_radius=4)
    pygame.draw.rect(screen, (130, 210, 140),
                     pygame.Rect(r.x, r.y, r.w, max(2, int(6 * s))), border_radius=4)
    if BELT:                                             # ベルトコンベアの矢印
        bdir = 1 if (m.tick // BELT["period"]) % 2 == 0 else -1
        phase = (m.tick * BELT["speed"] * bdir) % 60
        warn = (m.tick % BELT["period"]) > BELT["period"] - 45 and (m.tick // 6) % 2 == 0
        acol = (255, 220, 120) if warn else (40, 90, 55)
        for k in range(-1, MAIN.w // 60 + 2):
            ax = MAIN.left + k * 60 + phase
            if ax < MAIN.left + 10 or ax > MAIN.right - 10:
                continue
            pygame.draw.polygon(screen, acol, [cam.pt(ax + bdir * 10, MAIN.top + 16),
                                               cam.pt(ax - bdir * 6, MAIN.top + 9),
                                               cam.pt(ax - bdir * 6, MAIN.top + 23)])
    for blk in SOLID[1:]:                                # 塔・壁・天井
        pygame.draw.rect(screen, (110, 120, 140), cam.rect(blk), border_radius=4)
        pygame.draw.rect(screen, (150, 160, 180),
                         pygame.Rect(cam.rect(blk).x, cam.rect(blk).y, cam.rect(blk).w,
                                     max(2, int(5 * s))), border_radius=3)
    mover_rects = [mvr["rect"] for mvr in MOVERS]
    temp_rects = [tp[0] for tp in TEMPS]
    for p in THIN:
        col = (110, 190, 120)
        if any(p is q for q in mover_rects):
            col = (130, 170, 235)                        # 動く足場は青
        elif any(p is q for q in temp_rects):
            col = (240, 170, 220)                        # 作られた足場はピンク
        pygame.draw.rect(screen, col, cam.rect(p), border_radius=3)

    for it in m.items:                                   # アイテム
        if it.life < 180 and (it.life // 6) % 2 == 0:
            continue
        info = ITEM_TYPES[it.kind]
        ir = cam.rect(it.rect)
        pygame.draw.ellipse(screen, info["color"], ir)
        pygame.draw.ellipse(screen, (255, 255, 255), ir, 2)
        draw_text(screen, fonts["small"], info["label"], (20, 20, 30), ir.center)

    for pr in m.projs:                                   # 飛び道具
        pr_rect = cam.rect(pr.rect)
        if pr.kind == "turret":                  # トーテム（砲台）
            if pr.life > 60 or (pr.life // 4) % 2 == 0:
                pygame.draw.rect(screen, pr.color, pr_rect, border_radius=6)
                pygame.draw.rect(screen, (255, 255, 255), pr_rect, 2, border_radius=6)
                eye = max(2, pr_rect.w // 6)
                pygame.draw.circle(screen, (40, 30, 40), (pr_rect.centerx, pr_rect.y + pr_rect.h // 3), eye)
                pygame.draw.rect(screen, (40, 30, 40),
                                 pygame.Rect(pr_rect.x + 4, pr_rect.y + pr_rect.h * 2 // 3,
                                             pr_rect.w - 8, max(2, pr_rect.h // 10)))
        elif pr.kind == "portal":                # ポータル(NEBULA)：青=入口 / 橙=出口
            if pr.life > 50 or (pr.life // 4) % 2 == 0:
                col = (90, 170, 255) if pr.phase < 0.5 else (255, 150, 60)
                wob = int(3 * math.sin(pr.age * 0.2) * s)
                outer = pygame.Rect(pr_rect.x - wob, pr_rect.y, pr_rect.w + 2 * wob, pr_rect.h)
                pygame.draw.ellipse(screen, col, outer, 4 if pr.mate is not None else 2)
                inner = outer.inflate(-int(outer.w * 0.45), -int(outer.h * 0.3))
                pygame.draw.ellipse(screen, tuple(v // 2 for v in col), inner)
        elif pr.kind == "orbit":                 # オーブ(COMET)：光る玉（消える直前は点滅）
            if pr.life > 50 or (pr.life // 4) % 2 == 0:
                pygame.draw.ellipse(screen, pr.color, pr_rect)
                pygame.draw.ellipse(screen, (255, 255, 255), pr_rect, 2)
                pygame.draw.circle(screen, (255, 255, 255), pr_rect.center, max(2, pr_rect.w // 5))
        elif pr.kind == "spring":                # ばね
            pygame.draw.rect(screen, pr.color, pr_rect, border_radius=4)
            pygame.draw.rect(screen, (255, 255, 255), pr_rect, 2, border_radius=4)
            for zx in range(pr_rect.x + 6, pr_rect.right - 4, 10):
                pygame.draw.line(screen, (150, 100, 20), (zx, pr_rect.bottom - 2),
                                 (zx + 5, pr_rect.y + 2), 2)
        elif pr.kind == "geyser":                # 間欠泉：予告の波紋 → 水柱
            base_y = pr_rect.bottom
            if pr.age < 22:
                wd = int(pr_rect.w * (0.5 + pr.age / 30.0))
                pygame.draw.ellipse(screen, (120, 200, 255),
                                    pygame.Rect(pr_rect.centerx - wd, base_y - int(8 * s), wd * 2, int(16 * s)), 3)
            else:
                hh = pr_rect.h if pr.age <= 48 else int(pr_rect.h * max(0.0, (70 - pr.age) / 22.0))
                if hh > 2:
                    col_r = pygame.Rect(pr_rect.x, base_y - hh, pr_rect.w, hh)
                    pygame.draw.rect(screen, pr.color, col_r, border_radius=10)
                    pygame.draw.rect(screen, (235, 250, 255), col_r, 3, border_radius=10)
        elif pr.kind == "snare":                 # イバラのわな（準備できると明るくなる）
            armed = pr.age >= pr.arm
            gc = (130, 200, 90) if armed else (80, 110, 70)
            pygame.draw.ellipse(screen, gc, pr_rect)
            for zx in range(pr_rect.x + 4, pr_rect.right - 2, 9):
                pygame.draw.line(screen, (60, 100, 45), (zx, pr_rect.bottom - 2),
                                 (zx + 4, pr_rect.y - int(8 * s)), 3)
        elif pr.kind == "zone":                  # タイムフィールド（半透明の楕円）
            zs = pygame.Surface((max(2, pr_rect.w), max(2, pr_rect.h)), pygame.SRCALPHA)
            pygame.draw.ellipse(zs, (240, 215, 140, 70), zs.get_rect())
            pygame.draw.ellipse(zs, (255, 235, 170, 190), zs.get_rect(), 3)
            screen.blit(zs, pr_rect.topleft)
        elif pr.kind == "bomb":
            if pr.exploding > 0:
                pygame.draw.ellipse(screen, (255, 150, 50), pr_rect)
                pygame.draw.ellipse(screen, (255, 240, 160), pr_rect, 4)
            else:
                blink = (pr.fuse // 5) % 2 == 0 and pr.fuse < 30
                armed = pr.age >= pr.arm
                pygame.draw.ellipse(screen, (255, 70, 60) if blink else pr.color, pr_rect)
                pygame.draw.ellipse(screen, (255, 255, 255) if armed else (120, 120, 120),
                                    pr_rect, 2)
        elif pr.h > pr.w * 2:                     # 縦長（雷）
            pygame.draw.rect(screen, pr.color, pr_rect, border_radius=4)
            pygame.draw.rect(screen, (255, 255, 255), pr_rect, 2, border_radius=4)
        else:
            pygame.draw.ellipse(screen, pr.color, pr_rect)
            pygame.draw.ellipse(screen, (255, 255, 255), pr_rect, 2)

    for b in m.bolts:                                    # 落雷（予告 → 本番）
        x0, y0 = cam.pt(b["x"], MAIN.top - 1000)
        x1, y1 = cam.pt(b["x"], MAIN.top + 40)
        if b["t"] > 0:
            if (b["t"] // 4) % 2 == 0:
                pygame.draw.line(screen, (255, 240, 150), (x0, y0), (x1, y1), max(1, int(2 * s)))
            gy = cam.pt(b["x"], MAIN.top)[1]
            pygame.draw.circle(screen, (255, 240, 150), (x1, gy), max(3, int(12 * s)), 2)
        else:
            bw = max(3, int(72 * s))
            pygame.draw.rect(screen, (255, 250, 190), pygame.Rect(x0 - bw // 2, y0, bw, y1 - y0))
            pygame.draw.rect(screen, (255, 255, 255),
                             pygame.Rect(x0 - bw // 6, y0, max(1, bw // 3), y1 - y0))

    for f in m.fighters:
        f.draw(screen, cam, fonts["small"])
    draw_hud(screen, m.fighters[0], 100, fonts)
    draw_hud(screen, m.fighters[1], W - 400, fonts)
    if m.winner:
        draw_text(screen, fonts["big"], f"{m.winner.tag} WINS!", ui_color(m.winner.color), (W // 2, 220))
        draw_text(screen, fonts["small"], "R: rematch      ESC: menu",
                  (230, 230, 230), (W // 2, 270))


async def main():
    pygame.init()
    # ゲーム本来の解像度で描画する（pygame側で拡大しない）
    screen = pygame.display.set_mode((W, H))

    # Pygbagのwindow_resize()がCanvasのCSSを後から書き換えるため、
    # !important を付けて本来の1280x720px・中央配置を優先させる。
    web_canvas = None
    if sys.platform == "emscripten":
        try:
            import platform
            web_canvas = platform.window.canvas
            platform.document.body.style.margin = "0"
            platform.document.body.style.padding = "0"
            platform.document.body.style.overflow = "hidden"
        except Exception as exc:
            print("Canvas fixed-size setup failed:", exc)

    def fix_web_canvas():
        if web_canvas is None:
            return
        style = web_canvas.style
        style.setProperty("width", f"{W}px", "important")
        style.setProperty("height", f"{H}px", "important")
        style.setProperty("min-width", f"{W}px", "important")
        style.setProperty("min-height", f"{H}px", "important")
        style.setProperty("max-width", "none", "important")
        style.setProperty("max-height", "none", "important")
        style.setProperty("position", "fixed", "important")
        style.setProperty("left", "50%", "important")
        style.setProperty("top", "50%", "important")
        style.setProperty("right", "auto", "important")
        style.setProperty("bottom", "auto", "important")
        style.setProperty("margin", "0", "important")
        style.setProperty("padding", "0", "important")
        style.setProperty("border", "0", "important")
        style.setProperty("transform", "translate(-50%, -50%)", "important")
        style.setProperty("image-rendering", "pixelated", "important")

    fix_web_canvas()

    pygame.display.set_caption("Pythonic Brothers in the Clouds ver.18.0")
    clock = pygame.time.Clock()
    fonts = dict(huge=pygame.font.Font(None, 110), title=pygame.font.Font(None, 88),
                 big=pygame.font.Font(None, 60),
                 mid=pygame.font.Font(None, 38), small=pygame.font.Font(None, 26),
                 tiny=pygame.font.Font(None, 20), micro=pygame.font.Font(None, 16))

    state = "mode"            # mode -> select(キャラ) -> stage -> play
    cpu_level = None          # None=2人対戦 / 0,1,2=CPUの強さ
    use_items = True          # アイテムのON/OFF
    stage_sel = 0             # len(STAGES) = RANDOM
    sel = [0, 1]              # len(CHARS) = RANDOM
    locked = [False, False]
    match = None
    paused = False

    def new_match():
        i1 = pick_index(sel[0], len(CHARS))
        i2 = pick_index(sel[1], len(CHARS))
        st = pick_index(stage_sel, len(STAGES))
        return Match(i1, i2, cpu_level, st, use_items)

    while True:
        # Pygbag側のリサイズ処理に上書きされないよう、毎フレーム固定状態を維持
        fix_web_canvas()
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                return
            if e.type != pygame.KEYDOWN:
                continue

            if e.key == pygame.K_ESCAPE:
                if state == "mode":
                    return
                state = "mode"
                paused = False
                continue

            if e.key == ITEM_KEY and state in ("mode", "stage"):
                use_items = not use_items
                continue

            if state == "mode":
                levels = {pygame.K_1: 0, pygame.K_2: 1, pygame.K_3: 2, pygame.K_4: None}
                if e.key in levels:
                    cpu_level = levels[e.key]
                    sel = [0, 1]
                    locked = [False, False]
                    state = "select"

            elif state == "select":
                total = len(CHARS) + 1                 # +RANDOM
                for i, k in enumerate((P1_KEYS, P2_KEYS)):
                    if locked[i]:
                        continue
                    if e.key == k["left"]:
                        sel[i] = (sel[i] - 1) % total
                    elif e.key == k["right"]:
                        sel[i] = (sel[i] + 1) % total
                    elif e.key == k["jump"]:               # W / ↑ : 上の段へ
                        sel[i] = grid_move(sel[i], -1, total, select_cols(total))
                    elif e.key == k["down"]:               # S / ↓ : 下の段へ
                        sel[i] = grid_move(sel[i], 1, total, select_cols(total))
                    elif e.key == k["attack"]:
                        locked[i] = True
                if all(locked):
                    state = "stage"

            elif state == "stage":
                total = len(STAGES) + 1                # +RANDOM
                for k in (P1_KEYS, P2_KEYS):
                    if e.key == k["left"]:
                        stage_sel = (stage_sel - 1) % total
                    elif e.key == k["right"]:
                        stage_sel = (stage_sel + 1) % total
                    elif e.key == k["jump"]:                       # 上の段へ
                        stage_sel = grid_move(stage_sel, -1, total, 7)
                    elif e.key == k["down"]:                       # 下の段へ
                        stage_sel = grid_move(stage_sel, 1, total, 7)
                    elif e.key == k["attack"]:
                        match = new_match()
                        paused = False
                        state = "play"
                        break

            elif state == "play":
                if e.key == PAUSE_KEY and not match.winner:
                    paused = not paused
                    continue
                if paused:
                    continue
                if match.winner:
                    if e.key == pygame.K_r:
                        match = new_match()
                else:
                    pressed = pygame.key.get_pressed()
                    for f in match.fighters:
                        if f.cpu:
                            continue
                        inp = human_input(f.keys, pressed)
                        if inp.guard and f.on_ground and e.key in (
                                f.keys["left"], f.keys["right"], f.keys["down"]):
                            # ガードしながら 左右=ロール / 下=その場回避
                            if e.key == f.keys["left"]:
                                f.dodge(-1)
                            elif e.key == f.keys["right"]:
                                f.dodge(1)
                            else:
                                f.dodge(0)
                        elif e.key == f.keys["jump"]:
                            f.jump()
                        elif e.key == f.keys["attack"]:
                            if inp.up:
                                f.attack("up")
                            elif inp.down:
                                f.attack("down")
                            else:
                                f.attack("side")
                        elif e.key == f.keys["special"]:
                            if inp.up:
                                f.special_up(inp)
                            else:
                                f.special_neutral()

        if state == "play" and not match.winner and not paused:
            match.step()

        if state == "mode":
            screen.fill((30, 34, 50))
            draw_mode(screen, fonts, use_items)
        elif state == "select":
            screen.fill((30, 34, 50))
            draw_select(screen, fonts, sel, locked, cpu_level)
        elif state == "stage":
            screen.fill((30, 34, 50))
            draw_stage_select(screen, fonts, stage_sel, use_items)
        else:
            draw_game(screen, fonts, match)
            if paused:
                draw_text(screen, fonts["huge"], "PAUSED", (255, 255, 255), (W // 2, H // 2 - 40))
                draw_text(screen, fonts["small"], "P: resume      ESC: menu",
                          (220, 220, 230), (W // 2, H // 2 + 20))

        pygame.display.flip()
        clock.tick(FPS)
        await asyncio.sleep(0)


if __name__ == "__main__":
    asyncio.run(main())
